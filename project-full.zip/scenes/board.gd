extends Node2D

var S = 100.0
var PR = 18.0
var PIECE_R = 24.0
var O = Vector2.ZERO
var current = 1
var placed = 0
var first = 0
var phase = "place"
var debug_text = "BLACK - PLACE"
var selected = Vector2(-1, -1)
var valid_moves = []
var capture_options = []
var last_tap_ms = 0
var black_count = 0
var white_count = 0
var screen_size = Vector2.ZERO

var menu_rect: Rect2
var menu_open = false
var panel_rect: Rect2
var resume_rect: Rect2
var newgame_rect: Rect2
var sound_rect: Rect2
var music_rect: Rect2
var exit_to_main_rect: Rect2

# === متغیرهای پنجره ذخیره بازی (هنگام خروج) ===
var save_prompt_open = false
var save_prompt_panel_rect: Rect2
var save_prompt_yes_rect: Rect2
var save_prompt_no_rect: Rect2
var save_prompt_cancel_rect: Rect2
# ===============================================

# === متغیرهای پنجره لود بازی (هنگام شروع) ===
var load_prompt_open = false
var load_prompt_panel_rect: Rect2
var load_prompt_resume_rect: Rect2
var load_prompt_new_rect: Rect2
var load_prompt_cancel_rect: Rect2
# =============================================

# === تنظیمات ===
var settings_open = false
var vibration_enabled = true
var language = 0 # 0 = English, 1 = Persian
var settings_panel_rect: Rect2
var settings_close_rect: Rect2
var set_sound_rect: Rect2
var set_music_rect: Rect2
var set_vib_rect: Rect2
var set_lang_en_rect: Rect2
var set_lang_fa_rect: Rect2

var texts_en = {
	"play": "PLAY", "store": "STORE", "help": "HELP", "settings": "SETTINGS",
	"menu": "MENU", "resume": "RESUME", "new_game": "NEW GAME", "sound": "SOUND", "music": "MUSIC", "home": "HOME",
	"vibration": "VIBRATION", "language": "LANGUAGE", "english": "ENGLISH", "persian": "PERSIAN",
	"on": "ON", "off": "OFF", "back": "BACK", "close": "CLOSE", "coins": "COINS",
	"premium_store": "PREMIUM STORE", "piece_skins": "PIECE SKINS", "board_themes": "BOARD THEMES",
	"player_1": "PLAYER 1", "player_2": "PLAYER 2", "color_skins": "COLOR SKINS", "flag_skins": "FLAG SKINS",
	"equipped": "EQUIPPED", "owned": "OWNED", "choose_mode": "CHOOSE MODE", "two_players": "TWO PLAYERS",
	"play_ai": "PLAY WITH AI", "select_diff": "SELECT DIFFICULTY", "easy": "EASY", "medium": "MEDIUM", "hard": "HARD",
	"choose_side": "CHOOSE YOUR SIDE", "black": "BLACK", "white": "WHITE",
	"intro": "INTRO", "rules": "RULES", "copy": "COPY", "copied": "COPIED!",
	"black_place": "BLACK - PLACE", "white_place": "WHITE - PLACE", "choose_capture": "CHOOSE CAPTURE",
	"black_turn": "BLACK TURN", "white_turn": "WHITE TURN", "white_wins": "WHITE WINS!",
	"black_wins": "BLACK WINS!", "no_moves": "NO MORE MOVES", "open_menu": "OPEN MENU TO RESTART",
	"developer": "Developer: Kalat Group", "free": "FREE", "play_again": "PLAY AGAIN", "main_menu": "MAIN MENU",
	"c_black": "Black", "c_white": "White", "c_red": "Red", "c_orange": "Orange",
	"c_yellow": "Yellow", "c_green": "Green", "c_purple": "Purple", "c_blue": "Blue",
	"f_iri": "Iran", "f_yem": "Yemen", "f_pse": "Palestine", "f_lbn": "Lebanon",
	"f_irq": "Iraq", "f_rus": "Russia", "f_syr": "Syria", "f_chn": "China",
	"f_esp": "Spain", "f_bra": "Brazil", "f_ven": "Venezuela",
	"save_prompt": "SAVE GAME", "save_prompt_text": "Do you want to save the current game?", "yes": "YES", "no": "NO", "cancel": "CANCEL",
	"load_prompt": "SAVED GAME FOUND", "load_prompt_text": "Do you want to resume or start a new game?", "resume_game": "RESUME"
}

var texts_fa = {
	"play": "شروع بازی", "store": "فروشگاه", "help": "راهنما", "settings": "تنظیمات",
	"menu": "منو", "resume": "ادامه", "new_game": "بازی جدید", "sound": "صدا", "music": "موسیقی", "home": "منوی اصلی",
	"vibration": "لرزش", "language": "زبان", "english": "انگلیسی", "persian": "فارسی",
	"on": "روشن", "off": "خاموش", "back": "بازگشت", "close": "بستن", "coins": "سکه‌ها",
	"premium_store": "فروشگاه ویژه", "piece_skins": "اسکین مهره‌ها", "board_themes": "تم صفحه",
	"player_1": "بازیکن ۱", "player_2": "بازیکن ۲", "color_skins": "رنگ‌ها", "flag_skins": "پرچم‌ها",
	"equipped": "مجهز", "owned": "خریداری شده", "choose_mode": "انتخاب حالت", "two_players": "دو بازیکن",
	"play_ai": "با هوش مصنوعی", "select_diff": "انتخاب سختی", "easy": "آسان", "medium": "متوسط", "hard": "سخت",
	"choose_side": "انتخاب رنگ", "black": "سیاه", "white": "سفید",
	"intro": "معرفی", "rules": "قوانین", "copy": "کپی", "copied": "کپی شد!",
	"black_place": "چیدمان", "white_place": "چیدمان", "choose_capture": "انتخاب مهره",
	"black_turn": "نوبت", "white_turn": "نوبت", "white_wins": "برنده شد!",
	"black_wins": "برنده شد!", "no_moves": "حرکتی وجود ندارد", "open_menu": "برای شروع منو را باز کنید",
	"developer": "توسعه‌دهنده: گروه کلات", "free": "رایگان", "play_again": "بازی دوباره", "main_menu": "منوی اصلی",
	"c_black": "سیاه", "c_white": "سفید", "c_red": "قرمز", "c_orange": "نارنجی",
	"c_yellow": "زرد", "c_green": "سبز", "c_purple": "بنفش", "c_blue": "آبی",
	"f_iri": "ایران", "f_yem": "یمن", "f_pse": "فلسطین", "f_lbn": "لبنان",
	"f_irq": "عراق", "f_rus": "روسیه", "f_syr": "سوریه", "f_chn": "چین",
	"f_esp": "اسپانیا", "f_bra": "برزیل", "f_ven": "ونزوئلا",
	"save_prompt": "ذخیره بازی", "save_prompt_text": "آیا می‌خواهید بازی فعلی ذخیره شود؟", "yes": "بله", "no": "خیر", "cancel": "انصراف",
	"load_prompt": "بازی ذخیره شده یافت شد", "load_prompt_text": "آیا می‌خواهید بازی را ادامه دهید یا بازی جدیدی شروع کنید؟", "resume_game": "ادامه بازی"
}

func _t(key: String) -> String:
	return texts_fa.get(key, key) if language == 1 else texts_en.get(key, key)

func _get_skin_name(skin_id: int) -> String:
	var keys = ["c_black", "c_white", "c_red", "c_orange", "c_yellow", "c_green", "c_purple", "c_blue", "f_iri", "f_yem", "f_pse", "f_lbn", "f_irq", "f_rus", "f_syr", "f_chn", "f_esp", "f_bra", "f_ven"]
	return _t(keys[skin_id]) if skin_id >= 0 and skin_id < keys.size() else "?"

var black_counter_rect: Rect2
var black_tray_rect: Rect2
var white_tray_rect: Rect2
var white_counter_rect: Rect2
var side_open = true
var player_color = 1
var computer_color = 2
var side_panel_rect: Rect2
var side_black_rect: Rect2
var side_white_rect: Rect2
var vs_computer = false
var ai_delay = 1.0
var difficulty = 1
var turn_time = 60.0
const TURN_LIMIT = 60.0
const TOTAL_PIECES = 12
const TRAY_COLS = 6
const TRAY_ROWS = 2

const SAVE_PATH = "user://save_game.json"
const SHOP_PATH = "user://shop_data.json"

const SKIN_PRICES = [0, 0, 0, 0, 0, 0, 0, 0, 500, 400, 400, 400, 300, 300, 300, 250, 250, 250, 250]
const THEME_PRICES = [0, 100, 100, 100, 100, 150, 200]

var store_open = false
var store_tab = 0
var store_from_main = false
var store_scroll_y = 0.0
var store_panel_rect: Rect2
var store_close_rect: Rect2
var store_piece_tab_rect: Rect2
var store_theme_tab_rect: Rect2
var color_skin_rects = []
var flag_skin_rects = []
var theme_rects = []
var color_header_y = 0.0
var flag_header_y = 0.0

var store_active_player = 1
var store_p1_btn_rect: Rect2
var store_p2_btn_rect: Rect2

var help_open = false
var help_tab = 0
var help_panel_rect: Rect2
var help_close_rect: Rect2
var help_intro_tab_rect: Rect2
var help_rules_tab_rect: Rect2
var help_copy_rect: Rect2
var copy_flash = 0.0
var help_from_main = false

var is_main_menu_open = true
var is_mode_menu_open = false
var is_diff_menu_open = false
var last_tick_sec = -1

var start_2p_btn: Rect2
var start_ai_btn: Rect2
var mode_menu_rect: Rect2
var diff_easy_btn: Rect2
var diff_med_btn: Rect2
var diff_hard_btn: Rect2
var diff_menu_rect: Rect2
var gameover_panel_rect: Rect2
var gameover_play_again_rect: Rect2
var gameover_main_menu_rect: Rect2

const COLOR_PALETTE = [
	["#090909", "#1D1D1F", "#050505", "#F4F1EA", "#DAD8D3", "#756F68"], # Black
	["#202020", "#404040", "#FFFFFF", "#FFFFFF", "#FFFFFF", "#D0D0D0"], # White (Pure White)
	["#4A0505", "#7A0B0B", "#FF3333", "#FFD6D6", "#FF9999", "#CC0000"], # Red
	["#4A2005", "#7A350B", "#FF8800", "#FFE3D6", "#FFBC99", "#CC5500"], # Orange
	["#4A3F05", "#7A690B", "#FFD700", "#FFF7CC", "#FFE966", "#CCAA00"], # Yellow
	["#054A14", "#0B7A22", "#33FF55", "#D6FFE0", "#99FFBB", "#00CC33"], # Green
	["#2A054A", "#460B7A", "#9933FF", "#EAD6FF", "#CC99FF", "#7700CC"], # Purple
	["#051F4A", "#0B357A", "#3377FF", "#D6E8FF", "#99C2FF", "#0055CC"]  # Blue
]

const HELP_INTRO_TEXT = "Welcome to the world of RAH BI RAH!\n\nThis game is not just an ordinary game. It is a local treasure from the village of Charak Dashti in Bushehr Province, in our beloved Iran.\n\nFor generations, it has been played among the people of this region, in the warmth of Bushehr, together, with laughter and competition.\n\nNow it is your turn to become part of this story. Here, you compete with your opponent, place your pieces, move wisely, and trap your opponent's pieces. A game that demands thought, patience, and precision!\n\nAre you ready to keep this heritage alive?"
const HELP_RULES_TEXT = "GOAL\nRemove 11 of the opponent's pieces, leaving them with only 1 piece to win. No draws. Someone always wins.\n\nSETUP\n- 5x5 board with 25 points\n- 12 BLACK + 12 WHITE pieces\n- Two trays outside the board\n- The center point stays empty\n\nPLACEMENT PHASE\n- Players take turns placing pieces one by one on any empty blue point\n- BLACK places first\n- No captures during this phase\n- The player who places first moves second\n\nMOVEMENT PHASE\n- Move one piece to an adjacent empty point\n- All 8 directions allowed\n- Backward moves allowed\n\nCAPTURING\n- If your move places an enemy piece between two of your pieces, it is captured\n- You get a bonus move after each capture\n\nMULTIPLE CAPTURES\n- Choose one to remove\n\nCORNER SAFETY\n- Pieces in the 4 corners are safe\n\nTIMER\n- 60 seconds per turn\n\nWIN\n- Capture 11 pieces to win"

const HELP_INTRO_TEXT_FA = "به دنیای ره بی ره خوش آمدید!\n\nاین بازی فقط یک بازی معمولی نیست. این یک گنجینه محلی از روستای چارک دشتی در استان بوشهر، در ایران عزیز ماست.\n\nبرای نسل‌ها، این بازی در میان مردم این منطقه، در گرمای بوشهر، با هم و با خنده و رقابت انجام شده است.\n\nاکنون نوبت شماست که بخشی از این داستان شوید.\n\nآیا آماده‌اید این میراث را زنده نگه دارید؟"
const HELP_RULES_TEXT_FA = "هدف\nحذف ۱۱ مهره از حریف تا فقط ۱ مهره باقی بماند. مساوی وجود ندارد.\n\nراه‌اندازی\n- صفحه ۵x۵ با ۲۵ نقطه\n- ۱۲ مهره سیاه + ۱۲ مهره سفید\n- دو سینی در خارج از صفحه\n\nمرحله چیدمان\n- بازیکنان به نوبت مهره‌ها را قرار می‌دهند\n- سیاه ابتدا قرار می‌دهد\n\nمرحله حرکت\n- یک مهره را به یک نقطه خالی مجاور منتقل کنید\n- تمام ۸ جهت مجاز است\n\nکپچر (ساندویچ)\n- اگر حرکت شما یک مهره دشمن را بین دو مهره خودی قرار دهد، آن مهره کپچر می‌شود\n- پس از هر کپچر یک حرکت جایزه می‌گیرید\n\nکپچرهای چندگانه\n- شما یکی را برای حذف انتخاب می‌کنید\n\nامنیت گوشه‌ها\n- مهره‌های ۴ گوشه امن هستند\n\nتایمر\n- ۶۰ ثانیه برای هر نوبت\n\nبرد\n- برای بردن ۱۱ مهره را کپچر کنید"

var coins = 100
var skin_p1 = 0 
var skin_p2 = 1 
var owned_skins = [0, 1] 
var piece_effect = 0
var owned_effects = [0]
var game_theme = 0
var owned_themes = [0]
var win_coins = 0

var anim_active = false
var anim_from_pos = Vector2.ZERO
var anim_to_pos = Vector2.ZERO
var anim_piece_color = 0
var anim_progress = 0.0
var anim_tr = 0
var anim_tc = 0
var anim_is_ai = false
const ANIM_TIME = 0.22

var sound_enabled = true
var music_enabled = true
var snd_players = {}
var bgm_player: AudioStreamPlayer

var state = [
	[0, 0, 0, 0, 0], [0, 0, 0, 0, 0], [0, 0, -1, 0, 0], [0, 0, 0, 0, 0], [0, 0, 0, 0, 0]
]

func _ready():
	position = Vector2.ZERO
	await get_tree().process_frame
	_setup_sounds()
	_load_shop()
	_setup_bgm()
	_setup_rotation()
	_center()
	if not get_viewport().size_changed.is_connected(_on_resize):
		get_viewport().size_changed.connect(_on_resize)
	
	var vbox = get_node_or_null("StartMenu/VBoxContainer")
	if vbox:
		var empty_style = StyleBoxEmpty.new()
		for child in vbox.get_children():
			if child is Button:
				child.flat = true
				child.add_theme_stylebox_override("normal", empty_style)
				child.add_theme_stylebox_override("hover", empty_style)
				child.add_theme_stylebox_override("pressed", empty_style)
				child.add_theme_stylebox_override("focus", empty_style)
				
		if vbox.get_child_count() > 0 and vbox.get_child(0) is Button:
			if not vbox.get_child(0).pressed.is_connected(_on_start_game_pressed):
				vbox.get_child(0).pressed.connect(_on_start_game_pressed)

		if vbox.get_child_count() > 1 and vbox.get_child(1) is Button:
			if not vbox.get_child(1).pressed.is_connected(_on_store_pressed):
				vbox.get_child(1).pressed.connect(_on_store_pressed)

		var settings_btn = vbox.get_node_or_null("SettingsButton") if vbox.has_node("SettingsButton") else (vbox.get_child(2) if vbox.get_child_count() > 2 else null)
		if settings_btn and settings_btn is Button:
			if not settings_btn.pressed.is_connected(_on_settings_pressed):
				settings_btn.pressed.connect(_on_settings_pressed)

		var help_btn = vbox.get_node_or_null("HelpButton") if vbox.has_node("HelpButton") else (vbox.get_node_or_null("InfoButton") if vbox.has_node("InfoButton") else (vbox.get_child(3) if vbox.get_child_count() > 3 else null))
		if help_btn and help_btn is Button:
			if not help_btn.pressed.is_connected(_on_help_pressed):
				help_btn.pressed.connect(_on_help_pressed)

	if _load_game():
		side_open = false
		anim_active = false
		anim_progress = 0.0
		selected = Vector2(-1, -1)
		valid_moves.clear()
		capture_options.clear()
		ai_delay = 1.0
		_update_text()
	else:
		side_open = true
	
	is_main_menu_open = true
	is_mode_menu_open = false
	is_diff_menu_open = false
	load_prompt_open = false
	save_prompt_open = false
	if has_node("StartMenu"): $StartMenu.show()
	queue_redraw()

func _setup_bgm():
	bgm_player = AudioStreamPlayer.new()
	bgm_player.volume_db = -5.0
	add_child(bgm_player)
	if ResourceLoader.exists("res://bgm.ogg"):
		bgm_player.stream = load("res://bgm.ogg")
	elif ResourceLoader.exists("res://bgm.mp3"):
		bgm_player.stream = load("res://bgm.mp3")
	if bgm_player.stream:
		if bgm_player.stream is AudioStreamOggVorbis or bgm_player.stream is AudioStreamMP3:
			bgm_player.stream.loop = true
		if music_enabled: bgm_player.play()

func _sync_bgm():
	if not bgm_player or not bgm_player.stream: return
	if music_enabled:
		if not bgm_player.playing: bgm_player.play()
	else:
		if bgm_player.playing: bgm_player.stop()

func _vibrate(ms: int):
	if vibration_enabled: Input.vibrate_handheld(ms)

func _on_help_pressed():
	_play_sound("click")
	if has_node("StartMenu"): $StartMenu.hide()
	help_from_main = true
	help_open = true
	side_open = false
	help_tab = 0
	is_main_menu_open = false
	queue_redraw()

func _on_store_pressed():
	_play_sound("click")
	if has_node("StartMenu"): $StartMenu.hide()
	store_from_main = true
	store_open = true
	side_open = false
	store_tab = 0
	store_scroll_y = 0.0
	is_main_menu_open = false
	queue_redraw()

func _on_settings_pressed():
	_play_sound("click")
	if has_node("StartMenu"): $StartMenu.hide()
	settings_open = true
	side_open = false
	is_main_menu_open = false
	queue_redraw()

func _save_game():
	if side_open or anim_active or (phase == "place" and placed == 0) or phase == "gameover":
		if phase == "gameover": _delete_save()
		return
	var data = {
		"state": state, "current": current, "placed": placed, "first": first,
		"phase": phase, "black_count": black_count, "white_count": white_count,
		"turn_time": turn_time, "vs_computer": vs_computer, "computer_color": computer_color,
		"difficulty": difficulty, "player_color": player_color, "sound_enabled": sound_enabled
	}
	var file = FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if file: file.store_string(JSON.stringify(data)); file.close()

func _load_game() -> bool:
	if not FileAccess.file_exists(SAVE_PATH): return false
	var file = FileAccess.open(SAVE_PATH, FileAccess.READ)
	if not file: return false
	var parsed = JSON.parse_string(file.get_as_text()); file.close()
	if parsed == null or not (parsed is Dictionary) or not parsed.has("state"): return false
	var s = parsed["state"]
	if not (s is Array) or s.size() != 5: return false
	state = []
	for row in s:
		if not (row is Array) or row.size() != 5: return false
		var new_row = []
		for v in row: new_row.append(int(v))
		state.append(new_row)
	current = int(parsed.get("current", 1))
	placed = int(parsed.get("placed", 0))
	first = int(parsed.get("first", 0))
	phase = str(parsed.get("phase", "place"))
	black_count = int(parsed.get("black_count", 0))
	white_count = int(parsed.get("white_count", 0))
	turn_time = float(parsed.get("turn_time", TURN_LIMIT))
	vs_computer = bool(parsed.get("vs_computer", false))
	computer_color = int(parsed.get("computer_color", 2))
	difficulty = int(parsed.get("difficulty", 1))
	player_color = int(parsed.get("player_color", 1))
	sound_enabled = bool(parsed.get("sound_enabled", true))
	if turn_time < 0.0: turn_time = TURN_LIMIT
	if placed < 0: placed = 0
	return true

func _delete_save():
	if FileAccess.file_exists(SAVE_PATH): DirAccess.remove_absolute(SAVE_PATH)

func _save_shop():
	var data = {
		"coins": coins, "skin_p1": skin_p1, "skin_p2": skin_p2, "owned_skins_v5": owned_skins,
		"game_theme": game_theme, "owned_themes_v5": owned_themes,
		"vibration_enabled": vibration_enabled, "language": language, "music_enabled": music_enabled
	}
	var file = FileAccess.open(SHOP_PATH, FileAccess.WRITE)
	if file: file.store_string(JSON.stringify(data)); file.close()

func _load_shop():
	if not FileAccess.file_exists(SHOP_PATH):
		coins = 100; skin_p1 = 0; skin_p2 = 1; game_theme = 0
		owned_skins = [0, 1]; owned_themes = [0]
		vibration_enabled = true; language = 0; music_enabled = true
		_save_shop(); return
	var file = FileAccess.open(SHOP_PATH, FileAccess.READ)
	if not file: return
	var parsed = JSON.parse_string(file.get_as_text()); file.close()
	if parsed != null and parsed is Dictionary:
		coins = int(parsed.get("coins", 100))
		skin_p1 = int(parsed.get("skin_p1", parsed.get("current_skin", 0)))
		skin_p2 = int(parsed.get("skin_p2", 1))
		game_theme = int(parsed.get("game_theme", 0))
		vibration_enabled = bool(parsed.get("vibration_enabled", true))
		language = int(parsed.get("language", 0))
		music_enabled = bool(parsed.get("music_enabled", true))
		
		var os_arr = parsed.get("owned_skins_v5", [0, 1]); owned_skins = []
		if os_arr is Array:
			for v in os_arr: owned_skins.append(int(v))
		if owned_skins.is_empty(): owned_skins = [0, 1]
		if not 1 in owned_skins: owned_skins.append(1)
		
		var ot_arr = parsed.get("owned_themes_v5", [0]); owned_themes = []
		if ot_arr is Array:
			for v in ot_arr: owned_themes.append(int(v))
		if owned_themes.is_empty(): owned_themes = [0]
		
	if skin_p1 < 0 or skin_p1 > 18: skin_p1 = 0
	if skin_p2 < 0 or skin_p2 > 18: skin_p2 = 1
	if game_theme < 0 or game_theme > 6: game_theme = 0
	if language < 0 or language > 1: language = 0
	_save_shop()

func _buy_or_select_skin(id: int):
	if id < 0 or id > 18: return
	var active_skin = skin_p1 if store_active_player == 1 else skin_p2
	if id == active_skin: _play_sound("error"); return
	
	if not id in owned_skins:
		var price = SKIN_PRICES[id]
		if coins < price: _play_sound("error"); return
		coins -= price; owned_skins.append(id)
		
	if store_active_player == 1:
		skin_p1 = id
	else:
		skin_p2 = id
		
	_play_sound("click"); _save_shop(); queue_redraw()

func _buy_or_select_theme(id: int):
	if id < 0 or id > 6: return
	if id == game_theme: _play_sound("error"); return
	if not id in owned_themes:
		var price = THEME_PRICES[id]
		if coins < price: _play_sound("error"); return
		coins -= price; owned_themes.append(id)
	game_theme = id
	_play_sound("click"); _save_shop(); queue_redraw()

func _earn_coins(amount: int):
	coins += amount
	if coins < 0: coins = 0
	_save_shop()

func _notification(what):
	if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_CLOSE_REQUEST or what == NOTIFICATION_WM_GO_BACK_REQUEST:
		_save_game(); _save_shop()

func _make_tone(freq: float, duration: float, volume: float = 0.5, freq2: float = -1.0) -> AudioStreamWAV:
	var sample_rate = 22050
	var num_samples = int(sample_rate * duration)
	var data = PackedByteArray(); data.resize(num_samples * 2)
	var fade = 0.006
	for i in range(num_samples):
		var t = float(i) / sample_rate
		var env = 1.0
		if t < fade: env = t / fade
		elif t > duration - fade: env = (duration - t) / fade
		var f = freq
		if freq2 > 0.0:
			var half = duration / 2.0
			f = freq if t < half else freq2
		var sample = sin(TAU * f * t) * volume * env
		data.encode_s16(i * 2, int(clamp(sample, -1.0, 1.0) * 32767))
	var stream = AudioStreamWAV.new()
	stream.format = AudioStreamWAV.FORMAT_16_BITS
	stream.mix_rate = sample_rate
	stream.stereo = false
	stream.data = data
	return stream

func _setup_sounds():
	var sounds = {
		"place": _make_tone(880.0, 0.07, 0.45), "move": _make_tone(660.0, 0.06, 0.4),
		"capture": _make_tone(440.0, 0.18, 0.55, 280.0), "win": _make_tone(700.0, 0.5, 0.55, 1050.0),
		"click": _make_tone(1200.0, 0.04, 0.35), "time": _make_tone(500.0, 0.3, 0.5, 400.0),
		"tick": _make_tone(1000.0, 0.05, 0.3), "error": _make_tone(200.0, 0.15, 0.5, 150.0),
		"pass": _make_tone(600.0, 0.12, 0.35, 450.0)
	}
	for k in sounds.keys():
		var p = AudioStreamPlayer.new()
		p.stream = sounds[k]; p.volume_db = 0.0
		add_child(p); snd_players[k] = p

func _play_sound(name: String):
	if sound_enabled and snd_players.has(name):
		var p = snd_players[name]
		p.stop(); p.volume_db = 0.0; p.play()
		if name == "click": _vibrate(15)
		elif name == "place": _vibrate(30)
		elif name == "capture": _vibrate(50)
		elif name == "win": _vibrate(100)

func _stop_all_sounds():
	for k in snd_players.keys():
		snd_players[k].stop(); snd_players[k].volume_db = -80.0

func _process(delta):
	if copy_flash > 0.0:
		copy_flash -= delta
		if copy_flash < 0.0: copy_flash = 0.0
		queue_redraw()
	if side_open or phase == "gameover" or menu_open or store_open or help_open or is_main_menu_open or is_mode_menu_open or is_diff_menu_open or settings_open or save_prompt_open or load_prompt_open:
		return
	if anim_active:
		anim_progress += delta / ANIM_TIME
		if anim_progress >= 1.0:
			anim_progress = 1.0; _finish_animation()
		queue_redraw()
	if vs_computer and current == computer_color:
		if anim_active: return
		ai_delay -= delta
		if ai_delay <= 0: _ai_play()
		queue_redraw(); return
	if not anim_active and (phase == "place" or phase == "move"):
		turn_time -= delta
		var display_sec = int(ceil(turn_time))
		if turn_time <= 10.0 and turn_time > 0 and display_sec != last_tick_sec:
			last_tick_sec = display_sec; _play_sound("tick")
		if turn_time <= 0:
			turn_time = 0; _time_out()
		queue_redraw()

func _start_animation(sr: int, sc: int, tr: int, tc: int, is_ai: bool):
	var piece = state[sr][sc]
	state[sr][sc] = -1 if _is_center(sr, sc) else 0
	anim_active = true
	anim_from_pos = gp(sr, sc); anim_to_pos = gp(tr, tc)
	anim_piece_color = piece; anim_progress = 0.0
	anim_tr = tr; anim_tc = tc; anim_is_ai = is_ai
	selected = Vector2(-1, -1); valid_moves.clear()
	_play_sound("move"); queue_redraw()

func _finish_animation():
	state[anim_tr][anim_tc] = anim_piece_color
	anim_active = false
	_after_move(anim_tr, anim_tc)
	if anim_is_ai: ai_delay = 0.5
	_save_game(); queue_redraw()

func _ai_play():
	if phase == "place": _ai_place()
	elif phase == "move": _ai_move()
	elif phase == "choose_capture": _ai_choose_capture()

func _ai_place():
	var options = []
	for r in range(5):
		for c in range(5):
			if not _is_center(r, c) and _is_empty(r, c):
				var sc = 100 if _is_corner(r, c) else (60 if (r == 0 or r == 4 or c == 0 or c == 4) else 30)
				sc += (randi() % 200 if difficulty == 0 else (randi() % 50 if difficulty == 1 else randi() % 10))
				options.append({"pos": Vector2(r, c), "score": sc})
	if options.size() == 0: return
	options.sort_custom(func(a, b): return a["score"] > b["score"])
	_handle_place(int(options[0]["pos"].x), int(options[0]["pos"].y))
	ai_delay = 0.5

func _ai_move():
	var all_moves = []
	for r in range(5):
		for c in range(5):
			if state[r][c] == computer_color:
				for m in _get_moves(r, c):
					all_moves.append({"from": Vector2(r, c), "to": m})
	if all_moves.size() == 0:
		_time_out(); ai_delay = 0.9; return
	if difficulty == 0 and randf() < 0.4:
		var pick = all_moves[randi() % all_moves.size()]
		_start_animation(int(pick["from"].x), int(pick["from"].y), int(pick["to"].x), int(pick["to"].y), true)
		return
	var best = null; var best_score = -999999
	for mv in all_moves:
		var sc = _ai_score_move(int(mv["from"].x), int(mv["from"].y), int(mv["to"].x), int(mv["to"].y))
		if sc > best_score: best_score = sc; best = mv
	if best == null: _time_out(); ai_delay = 0.9; return
	_start_animation(int(best["from"].x), int(best["from"].y), int(best["to"].x), int(best["to"].y), true)

func _ai_score_move(from_r, from_c, to_r, to_c):
	var save_to = state[to_r][to_c]; var save_from = state[from_r][from_c]
	state[to_r][to_c] = save_from; state[from_r][from_c] = -1 if _is_center(from_r, from_c) else 0
	var caps = _check_sandwiches(to_r, to_c)
	var score = caps.size() * 1000
	if _is_center(to_r, to_c): score += 40
	if _is_corner(to_r, to_c): score -= 30
	if difficulty == 2:
		score -= _count_opponent_captures() * 600
		if _is_threatened(to_r, to_c): score -= 300
	score += (randi() % 300 if difficulty == 0 else (randi() % 60 if difficulty == 1 else randi() % 10))
	state[to_r][to_c] = save_to; state[from_r][from_c] = save_from
	return score

func _count_opponent_captures():
	var count = 0; var opponent = 3 - computer_color
	for r in range(5):
		for c in range(5):
			if state[r][c] == opponent:
				for m in _get_moves(r, c):
					var mr = int(m.x); var mc = int(m.y)
					var save_to = state[mr][mc]; var save_from = state[r][c]
					state[mr][mc] = save_from; state[r][c] = -1 if _is_center(r, c) else 0
					var saved_current = current; current = opponent
					count += _check_sandwiches(mr, mc).size()
					current = saved_current
					state[mr][mc] = save_to; state[r][c] = save_from
	return count

func _is_threatened(r, c):
	var opp = 3 - computer_color
	var saved = state[r][c]; state[r][c] = opp
	var saved_current = current; current = opp
	var caps = _check_sandwiches(r, c)
	current = saved_current; state[r][c] = saved
	return caps.size() > 0

func _ai_choose_capture():
	if capture_options.size() == 0:
		phase = "move"; _begin_turn(); ai_delay = 0.9; return
	_handle_choose_capture(int(capture_options[0].x), int(capture_options[0].y))
	ai_delay = 0.9

func _time_out():
	if vs_computer and current == computer_color: _play_sound("pass")
	else: _play_sound("time")
	turn_time = TURN_LIMIT
	if phase == "place": current = 3 - current; _update_text()
	elif phase == "move":
		selected = Vector2(-1, -1); valid_moves.clear(); capture_options.clear()
		current = 3 - current; _begin_turn()
	_save_game()

func _on_resize():
	_setup_rotation(); _center()

func _setup_rotation():
	var vp = get_viewport().get_visible_rect().size
	if vp.x < 100 or vp.y < 100: return
	rotation = 0; position = Vector2.ZERO

func _center():
	var vp = get_viewport().get_visible_rect().size
	if vp.x < 100 or vp.y < 100: return
	var vw = vp.x; var vh = vp.y
	screen_size = Vector2(vw, vh)
	menu_rect = Rect2(vw - 150.0, 20.0, 130.0, 90.0)

	var counter_h = 60.0; var counter_w = 260.0; var gap_small = 25.0; var margin = 10.0; var gap_large = 250.0
	var s_height = (vh - 200.0 - 2.0 * gap_large) / 5.84
	var s_width = (vw - 40.0) / 5.5
	S = max(min(s_width, s_height), 30.0)
	PIECE_R = S * 0.23; PR = S * 0.12
	var board_size = S * 4.0
	var slot_h = PIECE_R * 2.0 + 4.0; var tray_h = slot_h * TRAY_ROWS + 12.0
	var slot_w = PIECE_R * 2.0 + 8.0; var tray_w = slot_w * TRAY_COLS + 16.0
	var tray_x = (vw - tray_w) / 2.0
	var total_h = (2.0 * margin + 2.0 * counter_h + 2.0 * gap_small + 2.0 * gap_large + 2.0 * tray_h + board_size)
	var y_offset = max((vh - total_h) / 2.0, 0)
	var y = y_offset + margin
	black_counter_rect = Rect2(vw / 2.0 - counter_w / 2.0, y, counter_w, counter_h)
	y += counter_h + gap_small
	black_tray_rect = Rect2(tray_x, y, tray_w, tray_h)
	y += tray_h + gap_large
	O = Vector2((vw - board_size) / 2.0, y)
	y += board_size + gap_large
	white_tray_rect = Rect2(tray_x, y, tray_w, tray_h)
	y += tray_h + gap_small
	white_counter_rect = Rect2(vw / 2.0 - counter_w / 2.0, y, counter_w, counter_h)

	panel_rect = Rect2(O - Vector2(20, 20), Vector2(board_size + 40, board_size + 40))
	var btn_w = panel_rect.size.x * 0.75; var btn_h = panel_rect.size.y * 0.10; var gap_y = panel_rect.size.y * 0.04; var title_h = panel_rect.size.y * 0.15
	var btn_x = panel_rect.position.x + (panel_rect.size.x - btn_w) / 2.0

	var content_h = title_h + (5 * btn_h) + (4 * gap_y)
	var btn_start_y = panel_rect.position.y + (panel_rect.size.y - content_h) / 2.0 + title_h
	resume_rect = Rect2(btn_x, btn_start_y, btn_w, btn_h)
	newgame_rect = Rect2(btn_x, btn_start_y + btn_h + gap_y, btn_w, btn_h)
	sound_rect = Rect2(btn_x, btn_start_y + (btn_h + gap_y) * 2, btn_w, btn_h)
	music_rect = Rect2(btn_x, btn_start_y + (btn_h + gap_y) * 3, btn_w, btn_h)
	exit_to_main_rect = Rect2(btn_x, btn_start_y + (btn_h + gap_y) * 4, btn_w, btn_h)
	
	# Save Prompt Layout (بزرگ‌تر شد)
	var sp_w = min(vw * 0.85, 600.0); var sp_h = 400.0
	save_prompt_panel_rect = Rect2((vw - sp_w) / 2.0, (vh - sp_h) / 2.0, sp_w, sp_h)
	var sp_btn_h = 80.0; var sp_gap = 20.0
	var sp_btn_w = (sp_w - sp_gap * 4) / 3.0
	save_prompt_yes_rect = Rect2(save_prompt_panel_rect.position.x + sp_gap, save_prompt_panel_rect.end.y - sp_btn_h - sp_gap, sp_btn_w, sp_btn_h)
	save_prompt_no_rect = Rect2(save_prompt_yes_rect.end.x + sp_gap, save_prompt_yes_rect.position.y, sp_btn_w, sp_btn_h)
	save_prompt_cancel_rect = Rect2(save_prompt_no_rect.end.x + sp_gap, save_prompt_yes_rect.position.y, sp_btn_w, sp_btn_h)

	# Load Prompt Layout (بزرگ‌تر شد)
	var lp_w = min(vw * 0.85, 600.0); var lp_h = 400.0
	load_prompt_panel_rect = Rect2((vw - lp_w) / 2.0, (vh - lp_h) / 2.0, lp_w, lp_h)
	var lp_btn_h = 80.0; var lp_gap = 20.0
	var lp_btn_w = (lp_w - lp_gap * 4) / 3.0
	load_prompt_resume_rect = Rect2(load_prompt_panel_rect.position.x + lp_gap, load_prompt_panel_rect.end.y - lp_btn_h - lp_gap, lp_btn_w, lp_btn_h)
	load_prompt_new_rect = Rect2(load_prompt_resume_rect.end.x + lp_gap, load_prompt_resume_rect.position.y, lp_btn_w, lp_btn_h)
	load_prompt_cancel_rect = Rect2(load_prompt_new_rect.end.x + lp_gap, load_prompt_resume_rect.position.y, lp_btn_w, lp_btn_h)

	mode_menu_rect = panel_rect
	var mode_start_y = panel_rect.position.y + (panel_rect.size.y - (title_h + (2 * btn_h) + gap_y)) / 2.0
	start_2p_btn = Rect2(btn_x, mode_start_y + title_h, btn_w, btn_h)
	start_ai_btn = Rect2(btn_x, mode_start_y + title_h + btn_h + gap_y, btn_w, btn_h)

	diff_menu_rect = panel_rect
	var diff_start_y = panel_rect.position.y + (panel_rect.size.y - (title_h + (3 * btn_h) + (2 * gap_y))) / 2.0
	diff_easy_btn = Rect2(btn_x, diff_start_y + title_h, btn_w, btn_h)
	diff_med_btn = Rect2(btn_x, diff_start_y + title_h + btn_h + gap_y, btn_w, btn_h)
	diff_hard_btn = Rect2(btn_x, diff_start_y + title_h + (btn_h + gap_y) * 2, btn_w, btn_h)

	side_panel_rect = panel_rect
	var side_btn_w = (btn_w - gap_y) / 2.0; var side_btn_h = panel_rect.size.y * 0.45
	var side_start_y = panel_rect.position.y + (panel_rect.size.y - (title_h + side_btn_h)) / 2.0
	side_black_rect = Rect2(btn_x, side_start_y + title_h, side_btn_w, side_btn_h)
	side_white_rect = Rect2(btn_x + side_btn_w + gap_y, side_start_y + title_h, side_btn_w, side_btn_h)

	var hw = vw - 40.0; var hh = vh - 80.0; var hx = 20.0; var hy = 40.0
	help_panel_rect = Rect2(hx, hy, hw, hh)
	help_intro_tab_rect = Rect2(hx + 20, hy + 100, (hw - 40) / 2.0, 70)
	help_rules_tab_rect = Rect2(hx + 20 + (hw - 40) / 2.0, hy + 100, (hw - 40) / 2.0, 70)
	help_copy_rect = Rect2(hx + 20, hy + hh - 100, 200, 80)
	help_close_rect = Rect2(hx + hw - 220, hy + hh - 100, 200, 80)

	settings_panel_rect = panel_rect
	var s_btn_w = settings_panel_rect.size.x * 0.75; var s_btn_h = settings_panel_rect.size.y * 0.10; var s_gap_y = settings_panel_rect.size.y * 0.04; var s_title_h = settings_panel_rect.size.y * 0.15
	var s_btn_x = settings_panel_rect.position.x + (settings_panel_rect.size.x - s_btn_w) / 2.0
	var set_btn_y = settings_panel_rect.position.y + (settings_panel_rect.size.y - (s_title_h + (5 * s_btn_h) + (4 * s_gap_y))) / 2.0 + s_title_h
	set_sound_rect = Rect2(s_btn_x, set_btn_y, s_btn_w, s_btn_h)
	set_music_rect = Rect2(s_btn_x, set_btn_y + s_btn_h + s_gap_y, s_btn_w, s_btn_h)
	set_vib_rect = Rect2(s_btn_x, set_btn_y + (s_btn_h + s_gap_y) * 2, s_btn_w, s_btn_h)
	var lang_btn_w = (s_btn_w - s_gap_y) / 2.0
	set_lang_en_rect = Rect2(s_btn_x, set_btn_y + (s_btn_h + s_gap_y) * 3, lang_btn_w, s_btn_h)
	set_lang_fa_rect = Rect2(s_btn_x + lang_btn_w + s_gap_y, set_btn_y + (s_btn_h + s_gap_y) * 3, lang_btn_w, s_btn_h)
	settings_close_rect = Rect2(s_btn_x, set_btn_y + (s_btn_h + s_gap_y) * 4, s_btn_w, s_btn_h)

	var go_w = min(vw * 0.85, 450.0); var go_h = min(vh * 0.55, 450.0)
	gameover_panel_rect = Rect2((vw - go_w)/2.0, (vh - go_h)/2.0, go_w, go_h)
	var go_btn_h = go_h * 0.18; var go_gap_y = go_h * 0.08; var go_btn_w = go_w * 0.75
	var go_btn_x = gameover_panel_rect.position.x + (go_w - go_btn_w) / 2.0
	var go_start_y = gameover_panel_rect.position.y + (go_h - (go_h * 0.30 + (2 * go_btn_h) + go_gap_y)) / 2.0 + go_h * 0.30
	gameover_play_again_rect = Rect2(go_btn_x, go_start_y, go_btn_w, go_btn_h)
	gameover_main_menu_rect = Rect2(go_btn_x, go_start_y + go_btn_h + go_gap_y, go_btn_w, go_btn_h)

	var shop_w = vw - 40.0; var shop_h = vh - 80.0
	store_panel_rect = Rect2(hx, hy, shop_w, shop_h)
	store_close_rect = Rect2(hx + shop_w/2 - 100, hy + shop_h - 100, 200, 80)
	store_piece_tab_rect = Rect2(hx + 20, hy + 100, (shop_w - 40) / 2.0, 80)
	store_theme_tab_rect = Rect2(hx + 20 + (shop_w - 40) / 2.0, hy + 100, (shop_w - 40) / 2.0, 80)

	_setup_store_layout(); queue_redraw()

func _setup_store_layout():
	var hw = store_panel_rect.size.x; var hh = store_panel_rect.size.y
	var hx = store_panel_rect.position.x; var hy = store_panel_rect.position.y
	var pad = 20.0; var gap = 10.0
	
	var selector_y = hy + 190.0
	store_p1_btn_rect = Rect2(hx + 20, selector_y, (hw - 40)/2.0 - 10, 60)
	store_p2_btn_rect = Rect2(hx + 20 + (hw - 40)/2.0 + 10, selector_y, (hw - 40)/2.0 - 10, 60)
	
	var grid_y = hy + 260.0 
	var close_y = hy + hh - 100.0
	var grid_avail_h = close_y - 15.0 - grid_y
	
	color_skin_rects.clear(); flag_skin_rects.clear(); theme_rects.clear()
	
	if store_tab == 0:
		var cols = 3
		if hw > hh * 1.2: cols = 6
		elif hw > hh * 0.9: cols = 4
		var color_count = 8; var flag_count = 11
		var total_rows = int(ceil(color_count / float(cols))) + int(ceil(flag_count / float(cols)))
		var header_h = 30.0; var total_headers_h = header_h * 2; var total_gaps = 15.0 * 3
		var item_w = (hw - pad * 2.0 - gap * (cols - 1)) / cols
		var item_h = (grid_avail_h - total_headers_h - total_gaps - gap * (total_rows - 1)) / total_rows
		if item_h > item_w: item_h = item_w
		var start_y = grid_y + (grid_avail_h - (total_rows * item_h + (total_rows - 1) * gap + total_headers_h + total_gaps)) / 2.0
		
		color_header_y = start_y
		var color_start_y = color_header_y + header_h + gap
		for i in range(color_count):
			color_skin_rects.append(Rect2(hx + pad + (i % cols) * (item_w + gap), color_start_y + (i / cols) * (item_h + gap), item_w, item_h))
			
		flag_header_y = color_start_y + int(ceil(color_count / float(cols))) * (item_h + gap) + gap
		var flag_start_y = flag_header_y + header_h + gap
		for i in range(flag_count):
			flag_skin_rects.append(Rect2(hx + pad + (i % cols) * (item_w + gap), flag_start_y + (i / cols) * (item_h + gap), item_w, item_h))
	else:
		var cols = 3
		if hw > hh * 1.2: cols = 4
		var rows = int(ceil(7.0 / cols))
		var item_w = (hw - pad * 2.0 - gap * (cols - 1)) / cols
		var item_h = (hh - 250.0 - gap * (rows - 1)) / rows
		if item_h > item_w * 1.0: item_h = item_w * 1.0
		var start_y = grid_y + (grid_avail_h - (rows * item_h + (rows - 1) * gap)) / 2.0
		for i in range(7):
			theme_rects.append(Rect2(hx + pad + (i % cols) * (item_w + gap), start_y + (i / cols) * (item_h + gap), item_w, item_h))

func gp(r, c): return O + Vector2(c * S, r * S)
func _is_center(r, c): return r == 2 and c == 2
func _is_empty(r, c): return state[r][c] == 0 or state[r][c] == -1

func _find_cell(pos):
	for r in range(5):
		for c in range(5):
			if pos.distance_to(gp(r, c)) < S * 0.5: return Vector2(r, c)
	return Vector2(-1, -1)

func _input(event):
	if not (event is InputEventScreenTouch or event is InputEventMouseButton or event is InputEventScreenDrag): return
	if event is InputEventMouseButton and (not event.pressed or event.button_index != MOUSE_BUTTON_LEFT): return
	if event is InputEventScreenTouch and not event.pressed: return
	var local_pos = to_local(event.position)

	# === اصلاح باگ کلیک همزمان (Click-through) ===
	# با قرار دادن set_input_as_handled در ابتدای این شرط‌ها، مطمئن می‌شویم که اگر پنجره‌ای باز باشد،
	# هیچ کلیکی به دکمه‌های پشت آن نفوذ نمی‌کند.

	if load_prompt_open:
		get_viewport().set_input_as_handled() # مسدود کردن کلیک‌های پشتی
		if not _check_debounce(): return
		if load_prompt_resume_rect.has_point(local_pos):
			_play_sound("click")
			load_prompt_open = false
			if has_node("StartMenu"): $StartMenu.hide()
			is_main_menu_open = false; is_mode_menu_open = false; side_open = false
			if _load_game():
				_update_text()
			queue_redraw(); return
		elif load_prompt_new_rect.has_point(local_pos):
			_play_sound("click")
			_delete_save()
			load_prompt_open = false
			if has_node("StartMenu"): $StartMenu.hide()
			is_main_menu_open = false; is_mode_menu_open = true
			queue_redraw(); return
		elif load_prompt_cancel_rect.has_point(local_pos):
			_play_sound("click")
			load_prompt_open = false
			if has_node("StartMenu"): $StartMenu.show() # بازگرداندن منوی اصلی
			queue_redraw(); return
		return

	if save_prompt_open:
		get_viewport().set_input_as_handled() # مسدود کردن کلیک‌های پشتی
		if not _check_debounce(): return
		if save_prompt_yes_rect.has_point(local_pos):
			_play_sound("click")
			_save_game()
			save_prompt_open = false; menu_open = false; is_main_menu_open = true
			if has_node("StartMenu"): $StartMenu.show()
			_center(); queue_redraw(); return
		elif save_prompt_no_rect.has_point(local_pos):
			_play_sound("click")
			_delete_save()
			save_prompt_open = false; menu_open = false; is_main_menu_open = true
			if has_node("StartMenu"): $StartMenu.show()
			_center(); queue_redraw(); return
		elif save_prompt_cancel_rect.has_point(local_pos):
			_play_sound("click")
			save_prompt_open = false
			queue_redraw(); return
		return
	# ==============================================

	if is_main_menu_open: return

	if phase == "gameover" and not side_open:
		if not _check_debounce(): return
		if gameover_play_again_rect.has_point(local_pos):
			_play_sound("click"); _reset_game()
			phase = "place"; debug_text = _t("black_place")
			is_main_menu_open = false; is_mode_menu_open = false; is_diff_menu_open = false; side_open = false
			queue_redraw(); get_viewport().set_input_as_handled(); return
		elif gameover_main_menu_rect.has_point(local_pos):
			_play_sound("click"); phase = "place"; is_main_menu_open = true
			if has_node("StartMenu"): $StartMenu.show()
			_center(); queue_redraw(); get_viewport().set_input_as_handled(); return

	if settings_open:
		if not _check_debounce(): return
		if settings_close_rect.has_point(local_pos):
			settings_open = false; is_main_menu_open = true
			if has_node("StartMenu"): $StartMenu.show()
			_save_shop()
		elif set_sound_rect.has_point(local_pos):
			sound_enabled = not sound_enabled
			if not sound_enabled: _stop_all_sounds()
			_play_sound("click")
		elif set_music_rect.has_point(local_pos):
			music_enabled = not music_enabled; _sync_bgm(); _play_sound("click")
		elif set_vib_rect.has_point(local_pos):
			vibration_enabled = not vibration_enabled; _play_sound("click")
		elif set_lang_en_rect.has_point(local_pos):
			language = 0; _play_sound("click"); _update_text()
		elif set_lang_fa_rect.has_point(local_pos):
			language = 1; _play_sound("click"); _update_text()
		_save_shop(); queue_redraw(); get_viewport().set_input_as_handled(); return

	if is_mode_menu_open:
		if not _check_debounce(): return
		if start_2p_btn.has_point(local_pos):
			_play_sound("click"); vs_computer = false; is_mode_menu_open = false; side_open = true; queue_redraw()
		elif start_ai_btn.has_point(local_pos):
			_play_sound("click"); vs_computer = true; is_mode_menu_open = false; is_diff_menu_open = true; queue_redraw()
		get_viewport().set_input_as_handled(); return

	if is_diff_menu_open:
		if not _check_debounce(): return
		if diff_easy_btn.has_point(local_pos):
			_play_sound("click"); difficulty = 0; is_diff_menu_open = false; side_open = true; queue_redraw()
		elif diff_med_btn.has_point(local_pos):
			_play_sound("click"); difficulty = 1; is_diff_menu_open = false; side_open = true; queue_redraw()
		elif diff_hard_btn.has_point(local_pos):
			_play_sound("click"); difficulty = 2; is_diff_menu_open = false; side_open = true; queue_redraw()
		get_viewport().set_input_as_handled(); return
		
	if side_open:
		if not _check_debounce(): return
		if side_black_rect.has_point(local_pos):
			_play_sound("click"); player_color = 1; computer_color = 2; side_open = false; _reset_game()
		elif side_white_rect.has_point(local_pos):
			_play_sound("click"); player_color = 2; computer_color = 1; side_open = false; _reset_game()
		last_tap_ms = Time.get_ticks_msec(); get_viewport().set_input_as_handled(); return

	if help_open:
		if not _check_debounce(): return
		if help_close_rect.has_point(local_pos): 
			help_open = false
			if help_from_main: is_main_menu_open = true; if has_node("StartMenu"): $StartMenu.show(); help_from_main = false
		elif help_copy_rect.has_point(local_pos):
			var txt = HELP_INTRO_TEXT_FA if (help_tab == 0 and language == 1) else (HELP_RULES_TEXT_FA if language == 1 else (HELP_INTRO_TEXT if help_tab == 0 else HELP_RULES_TEXT))
			DisplayServer.clipboard_set(txt + "\n\n" + _t("developer")); copy_flash = 1.2
		elif help_intro_tab_rect.has_point(local_pos): help_tab = 0
		elif help_rules_tab_rect.has_point(local_pos): help_tab = 1
		get_viewport().set_input_as_handled(); queue_redraw(); return

	if store_open:
		if not _check_debounce(): return
		if store_close_rect.has_point(local_pos): 
			store_open = false
			if store_from_main: is_main_menu_open = true; if has_node("StartMenu"): $StartMenu.show(); store_from_main = false
		elif store_piece_tab_rect.has_point(local_pos): store_tab = 0; _setup_store_layout()
		elif store_theme_tab_rect.has_point(local_pos): store_tab = 1; _setup_store_layout()
		elif store_tab == 0:
			if store_p1_btn_rect.has_point(local_pos):
				_play_sound("click"); store_active_player = 1; _setup_store_layout()
			elif store_p2_btn_rect.has_point(local_pos):
				_play_sound("click"); store_active_player = 2; _setup_store_layout()
			else:
				var handled = false
				for i in range(color_skin_rects.size()):
					if color_skin_rects[i].has_point(local_pos): _buy_or_select_skin(i); handled = true; break
				if not handled:
					for i in range(flag_skin_rects.size()):
						if flag_skin_rects[i].has_point(local_pos): _buy_or_select_skin(i + 8); break
		else:
			for i in range(theme_rects.size()):
				if theme_rects[i].has_point(local_pos): _buy_or_select_theme(i); break
		get_viewport().set_input_as_handled(); queue_redraw(); return

	if menu_open:
		if not _check_debounce(): return
		if sound_rect.has_point(local_pos):
			sound_enabled = not sound_enabled
			if not sound_enabled: _stop_all_sounds()
			_save_game(); queue_redraw()
		elif music_rect.has_point(local_pos):
			music_enabled = not music_enabled; _sync_bgm(); _save_shop(); queue_redraw()
		elif resume_rect.has_point(local_pos):
			menu_open = false; queue_redraw()
		elif newgame_rect.has_point(local_pos):
			menu_open = false; is_main_menu_open = false; is_mode_menu_open = true; is_diff_menu_open = false; side_open = false
			_delete_save(); if has_node("StartMenu"): $StartMenu.hide(); queue_redraw()
		elif exit_to_main_rect.has_point(local_pos):
			_play_sound("click")
			save_prompt_open = true
			queue_redraw()
			get_viewport().set_input_as_handled(); return
		get_viewport().set_input_as_handled(); return

	if menu_rect.has_point(local_pos):
		_play_sound("click"); menu_open = true; get_viewport().set_input_as_handled(); queue_redraw(); return
		
	if not anim_active and not (vs_computer and current == computer_color) and _check_debounce():
		_handle_tap(local_pos)
	get_viewport().set_input_as_handled()

func _check_debounce():
	var now = Time.get_ticks_msec()
	if now - last_tap_ms < 250: return false
	last_tap_ms = now
	return true

func _handle_tap(pos):
	var cell = _find_cell(pos)
	if cell.x < 0: return
	if phase == "place": _handle_place(int(cell.x), int(cell.y))
	elif phase == "move": _handle_move(int(cell.x), int(cell.y))
	elif phase == "choose_capture": _handle_choose_capture(int(cell.x), int(cell.y))

func _handle_place(r, c):
	if _is_center(r, c) or not _is_empty(r, c): return
	if first == 0: first = current
	state[r][c] = current
	if current == 1: black_count += 1
	else: white_count += 1
	placed += 1; current = 3 - current; turn_time = TURN_LIMIT
	_play_sound("place")
	if placed >= 24: phase = "move"; current = 3 - first; _update_text(); _begin_turn()
	else: _update_text(); _save_game()
	queue_redraw()

func _update_text():
	if phase == "gameover": return
	if phase == "place": debug_text = _t("black_place") if current == 1 else _t("white_place")
	elif phase == "choose_capture": debug_text = _t("choose_capture")
	else: debug_text = _t("black_turn") if current == 1 else _t("white_turn")

func _begin_turn():
	if phase != "move": return
	selected = Vector2(-1, -1); valid_moves.clear(); capture_options.clear(); turn_time = TURN_LIMIT; last_tick_sec = -1
	if _player_has_moves(current): _update_text(); queue_redraw(); return
	current = 3 - current; turn_time = TURN_LIMIT; last_tick_sec = -1
	if _player_has_moves(current):
		await get_tree().create_timer(0.9).timeout
		if phase == "move": _update_text(); queue_redraw()
	else:
		debug_text = _t("no_moves"); phase = "gameover"; _play_sound("win"); _delete_save()
	queue_redraw()

func _player_has_moves(player):
	for r in range(5):
		for c in range(5):
			if state[r][c] == player and _get_moves(r, c).size() > 0: return true
	return false

func _handle_move(r, c):
	if state[r][c] == current:
		selected = Vector2(r, c); valid_moves = _get_moves(r, c)
	elif selected.x >= 0 and Vector2(r, c) in valid_moves:
		_start_animation(int(selected.x), int(selected.y), r, c, false); return
	else:
		selected = Vector2(-1, -1); valid_moves.clear()
	_update_text(); queue_redraw()

func _after_move(r, c):
	var caps = _check_sandwiches(r, c)
	if caps.size() == 0:
		current = 3 - current; turn_time = TURN_LIMIT; _begin_turn()
	elif caps.size() == 1:
		_remove_piece(int(caps[0].x), int(caps[0].y))
		if phase != "gameover": turn_time = TURN_LIMIT; _begin_turn()
	elif caps.size() > 1:
		capture_options = caps; phase = "choose_capture"; debug_text = _t("choose_capture"); _save_game(); queue_redraw()

func _handle_choose_capture(r, c):
	if Vector2(r, c) in capture_options:
		_remove_piece(r, c); capture_options.clear()
		if phase != "gameover": phase = "move"; turn_time = TURN_LIMIT; _begin_turn()
		_save_game(); queue_redraw()

func _remove_piece(r, c):
	if state[r][c] == 1: black_count -= 1
	elif state[r][c] == 2: white_count -= 1
	state[r][c] = -1 if _is_center(r, c) else 0
	_play_sound("capture")
	
	if black_count <= 1:
		debug_text = _get_skin_name(skin_p2) + " " + _t("white_wins")
		if vs_computer: win_coins = [10, 30, 50][difficulty]; _earn_coins(win_coins)
		else: win_coins = 0
		phase = "gameover"; _play_sound("win"); _delete_save()
	elif white_count <= 1:
		debug_text = _get_skin_name(skin_p1) + " " + _t("black_wins")
		if vs_computer: win_coins = [10, 30, 50][difficulty]; _earn_coins(win_coins)
		else: win_coins = 0
		phase = "gameover"; _play_sound("win"); _delete_save()

func _is_corner(r, c): return (r == 0 or r == 4) and (c == 0 or c == 4)

func _check_sandwiches(r, c):
	var caps = []; var opponent = 3 - current
	for d in _dirs(r, c):
		var r1 = r + int(d.x); var c1 = c + int(d.y)
		var r2 = r + int(d.x) * 2; var c2 = c + int(d.y) * 2
		if r2 >= 0 and r2 <= 4 and c2 >= 0 and c2 <= 4 and state[r1][c1] == opponent and state[r2][c2] == current and not _is_corner(r1, c1):
			if not Vector2(r1, c1) in caps: caps.append(Vector2(r1, c1))
	return caps

func _dirs(r, c):
	var dirs = [Vector2(-1, 0), Vector2(1, 0), Vector2(0, -1), Vector2(0, 1)]
	if (r + c) % 2 == 0: dirs.append_array([Vector2(-1, -1), Vector2(-1, 1), Vector2(1, -1), Vector2(1, 1)])
	return dirs

func _get_moves(r, c):
	var moves = []
	for d in _dirs(r, c):
		var nr = r + int(d.x); var nc = c + int(d.y)
		if nr >= 0 and nr <= 4 and nc >= 0 and nc <= 4 and _is_empty(nr, nc): moves.append(Vector2(nr, nc))
	return moves

func _reset_game():
	state = [[0, 0, 0, 0, 0], [0, 0, 0, 0, 0], [0, 0, -1, 0, 0], [0, 0, 0, 0, 0], [0, 0, 0, 0, 0]]
	current = 1; placed = 0; first = 0; phase = "place"; debug_text = _t("black_place"); selected = Vector2(-1, -1)
	valid_moves.clear(); capture_options.clear(); black_count = 0; white_count = 0
	menu_open = false; store_open = false; help_open = false; help_tab = 0; save_prompt_open = false; load_prompt_open = false
	turn_time = TURN_LIMIT; ai_delay = 1.0; anim_active = false; anim_progress = 0.0
	last_tick_sec = -1
	_center(); queue_redraw()

func _make_box(bg: Color, border: Color, radius: int, bw: int) -> StyleBoxFlat:
	var box = StyleBoxFlat.new()
	box.bg_color = bg; box.border_color = border; box.set_border_width_all(bw)
	box.corner_radius_top_left = radius; box.corner_radius_top_right = radius
	box.corner_radius_bottom_left = radius; box.corner_radius_bottom_right = radius
	return box

func _draw_shadow_rect(rect: Rect2, radius: float = 12.0, alpha: float = 0.35, offset: Vector2 = Vector2(5, 7)):
	draw_style_box(_make_box(Color(0, 0, 0, alpha), Color(0, 0, 0, 0), int(radius), 0), Rect2(rect.position + offset, rect.size))

func _draw_timer_border(rect: Rect2, remaining: float, color: Color):
	var w = rect.size.x; var h = rect.size.y
	var rem = 2.0 * (w + h) * remaining; var x = rect.position.x; var y = rect.position.y; var lw = 5.0
	if rem > 0: var seg = min(rem, w); draw_line(Vector2(x, y), Vector2(x + seg, y), color, lw, true); rem -= seg
	if rem > 0: var seg = min(rem, h); draw_line(Vector2(x + w, y), Vector2(x + w, y + seg), color, lw, true); rem -= seg
	if rem > 0: var seg = min(rem, w); draw_line(Vector2(x + w, y + h), Vector2(x + w - seg, y + h), color, lw, true); rem -= seg
	if rem > 0: var seg = min(rem, h); draw_line(Vector2(x, y + h), Vector2(x, y + h - seg), color, lw, true)

func _draw_centered_text(text: String, rect: Rect2, size: int, color: Color):
	var tw = ThemeDB.fallback_font.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, size).x
	draw_string(ThemeDB.fallback_font, Vector2(rect.position.x + (rect.size.x - tw) / 2.0, rect.position.y + rect.size.y / 2.0 + size * 0.35), text, HORIZONTAL_ALIGNMENT_LEFT, -1, size, color)

func _draw_glow_circle(pos: Vector2, radius: float, color: Color):
	draw_circle(pos, radius * 1.8, Color(color.r, color.g, color.b, color.a * 0.08))
	draw_circle(pos, radius * 1.45, Color(color.r, color.g, color.b, color.a * 0.15))
	draw_circle(pos, radius * 1.18, Color(color.r, color.g, color.b, color.a * 0.28))
	draw_circle(pos, radius, color)

func _draw_wood_panel(rect: Rect2):
	draw_style_box(_make_box(Color("#1a110b"), Color(0,0,0,0), 22, 0), rect)
	for i in range(30):
		var y = rect.position.y + 10 + i * (rect.size.y - 20) / 29.0
		var pts = PackedVector2Array()
		for j in range(20):
			pts.append(Vector2(rect.position.x + 10 + j * (rect.size.x - 20) / 19.0, y + sin(j * 0.8 + i * 0.4) * 8.0 + cos(j * 1.2 + i * 0.2) * 3.0))
		draw_polyline(pts, Color(0.2, 0.125, 0.078, 0.5) if i % 5 == 0 else Color(0.05, 0.027, 0.016, 0.4), 2.0 if i % 5 == 0 else 1.5, true)
	draw_style_box(_make_box(Color(0,0,0,0), _theme_accent(), 22, 2), rect)
	draw_style_box(_make_box(Color(0,0,0,0.3), Color(0,0,0,0), 22, 0), Rect2(rect.position, Vector2(rect.size.x, 20)))

func _draw():
	draw_rect(Rect2(Vector2.ZERO, screen_size), _theme_background())
	draw_rect(Rect2(0, 0, screen_size.x, screen_size.y * 0.25), _theme_top())
	draw_rect(Rect2(0, screen_size.y * 0.75, screen_size.x, screen_size.y * 0.25), _theme_bottom())
	
	var cb = Vector2(screen_size.x / 2.0, screen_size.y / 2.0)
	draw_circle(cb, screen_size.y * 0.43, Color(0.35, 0.22, 0.10, 0.045))
	draw_circle(cb, screen_size.y * 0.31, Color(0.55, 0.35, 0.15, 0.025))
	draw_line(Vector2(20, 75), Vector2(screen_size.x - 20, 75), Color(0.75, 0.55, 0.30, 0.10), 1.0)
	draw_line(Vector2(20, screen_size.y - 55), Vector2(screen_size.x - 20, screen_size.y - 55), Color(0.75, 0.55, 0.30, 0.08), 1.0)

	if not is_main_menu_open:
		_draw_shadow_rect(menu_rect, 12.0, 0.40, Vector2(3, 5))
		draw_style_box(_make_box(Color("#1A1714"), _theme_secondary(), 12, 1), menu_rect)
		_draw_icon_menu(menu_rect, Color("#E7D4B7"))

	_draw_counter(black_counter_rect, 1, _get_skin_name(skin_p1), black_count)
	_draw_tray(black_tray_rect, clamp(TOTAL_PIECES - black_count, 0, TOTAL_PIECES), true)

	if current == 1 and phase != "gameover":
		if not (vs_computer and computer_color == 1):
			_draw_timer_border(black_tray_rect, max(turn_time / TURN_LIMIT, 0), Color("#D9544D") if turn_time <= 10.0 else _theme_accent())

	_draw_board_background()

	for r in range(5):
		for c in range(5):
			var p = gp(r, c)
			if c < 4:
				draw_line(p, gp(r, c + 1), Color("#D5AD77"), 6.0, true)
				draw_line(p + Vector2(0, 2), gp(r, c + 1) + Vector2(0, 2), Color(0, 0, 0, 0.22), 2.0, true)
			if r < 4:
				draw_line(p, gp(r + 1, c), Color("#D5AD77"), 6.0, true)
				draw_line(p + Vector2(2, 0), gp(r + 1, c) + Vector2(2, 0), Color(0, 0, 0, 0.22), 2.0, true)
			if (r + c) % 2 == 0:
				if r < 4 and c < 4: draw_line(p, gp(r + 1, c + 1), Color("#C99D68"), 5.0, true)
				if r < 4 and c > 0: draw_line(p, gp(r + 1, c - 1), Color("#C99D68"), 5.0, true)

	for r in range(5):
		for c in range(5):
			var p = gp(r, c)
			draw_circle(p + Vector2(2, 3), PR + 1, Color(0, 0, 0, 0.25))
			draw_circle(p, PR, Color("#B68B5C"))
			draw_circle(p - Vector2(0, 1), PR - 4, Color("#7A593A"))
			draw_circle(p, PR, _theme_accent(), false, 2)

	for m in valid_moves:
		var p = gp(int(m.x), int(m.y))
		_draw_glow_circle(p, PIECE_R * 0.52, Color(0.25, 0.85, 0.55, 0.42))
		draw_circle(p, PIECE_R * 0.43, Color("#5ED79A"), false, 4)
		draw_circle(p, 5, Color("#A9F3C9"))

	for m in capture_options:
		var p = gp(int(m.x), int(m.y))
		_draw_glow_circle(p, PIECE_R + 7, Color(0.95, 0.25, 0.18, 0.28))
		draw_circle(p, PIECE_R + 8, Color("#F05A50"), false, 4)

	for r in range(5):
		for c in range(5):
			if state[r][c] == 1 or state[r][c] == 2: _draw_piece_at(gp(r, c), state[r][c])

	if selected.x >= 0:
		var sp = gp(int(selected.x), int(selected.y))
		_draw_glow_circle(sp, PIECE_R + 7, Color(1.0, 0.72, 0.20, 0.28))
		draw_circle(sp, PIECE_R + 9, _theme_accent(), false, 4)
		draw_circle(sp, PIECE_R + 13, Color(0.9, 0.65, 0.2, 0.25), false, 2)

	if anim_active:
		var apos = anim_from_pos.lerp(anim_to_pos, 1.0 - pow(1.0 - anim_progress, 3.0))
		_draw_glow_circle(apos, PIECE_R + 6, Color(0.85, 0.65, 0.30, 0.15))
		draw_circle(apos + Vector2(3, 5), PIECE_R + 4, Color(0, 0, 0, 0.28))
		_draw_piece_at(apos, anim_piece_color)

	_draw_tray(white_tray_rect, clamp(TOTAL_PIECES - white_count, 0, TOTAL_PIECES), false)
	if current == 2 and phase != "gameover":
		if not (vs_computer and computer_color == 2):
			_draw_timer_border(white_tray_rect, max(turn_time / TURN_LIMIT, 0), Color("#D9544D") if turn_time <= 10.0 else _theme_accent())
	
	_draw_counter(white_counter_rect, 2, _get_skin_name(skin_p2), white_count)

	if phase == "gameover" and not side_open:
		draw_rect(Rect2(Vector2.ZERO, screen_size), Color(0, 0, 0, 0.5))
		_draw_shadow_rect(gameover_panel_rect, 24.0, 0.75, Vector2(8, 10))
		_draw_wood_panel(gameover_panel_rect)
		var btn_sz = clamp(int(gameover_play_again_rect.size.y * 0.40), 20, 40); var title_sz = int(btn_sz * 1.4)
		var title_y = gameover_play_again_rect.position.y - (gameover_play_again_rect.size.y * 1.5)
		_draw_centered_text(debug_text, Rect2(gameover_panel_rect.position.x, title_y, gameover_panel_rect.size.x, gameover_play_again_rect.size.y), title_sz, _theme_accent())
		if win_coins > 0:
			_draw_centered_text("+" + str(win_coins) + " " + _t("coins"), Rect2(gameover_panel_rect.position.x, title_y + title_sz + 10, gameover_panel_rect.size.x, 30), 22, Color("#E6C56D"))
		draw_style_box(_make_box(Color("#20372A"), Color("#5BAA79"), 10, 2), gameover_play_again_rect)
		_draw_centered_text(_t("play_again"), gameover_play_again_rect, btn_sz, Color("#D8F1E0"))
		draw_style_box(_make_box(Color("#382321"), Color("#80524C"), 10, 1), gameover_main_menu_rect)
		_draw_centered_text(_t("main_menu"), gameover_main_menu_rect, btn_sz, Color("#A99C96"))

	if is_mode_menu_open:
		draw_rect(Rect2(0, 0, screen_size.x, screen_size.y), Color(0, 0, 0, 0.6))
		_draw_shadow_rect(mode_menu_rect, 24.0, 0.70, Vector2(8, 10)); _draw_wood_panel(mode_menu_rect)
		var btn_sz = clamp(int(start_2p_btn.size.y * 0.45), 20, 40); var title_sz = int(btn_sz * 1.2)
		var title_y = start_2p_btn.position.y - (start_2p_btn.size.y * 1.2)
		_draw_centered_text(_t("choose_mode"), Rect2(mode_menu_rect.position.x, title_y, mode_menu_rect.size.x, start_2p_btn.size.y), title_sz, _theme_accent())
		draw_style_box(_make_box(Color("#253A2C"), Color("#63B47F"), 15, 3), start_2p_btn)
		_draw_centered_text(_t("two_players"), start_2p_btn, btn_sz, Color("#F0E4D1"))
		draw_style_box(_make_box(Color("#253447"), Color("#6B9BC7"), 15, 3), start_ai_btn)
		_draw_centered_text(_t("play_ai"), start_ai_btn, btn_sz, Color("#E0EBF5"))

	if is_diff_menu_open:
		draw_rect(Rect2(0, 0, screen_size.x, screen_size.y), Color(0, 0, 0, 0.6))
		_draw_shadow_rect(diff_menu_rect, 24.0, 0.70, Vector2(8, 10)); _draw_wood_panel(diff_menu_rect)
		var btn_sz = clamp(int(diff_easy_btn.size.y * 0.45), 20, 40); var title_sz = int(btn_sz * 1.2)
		var title_y = diff_easy_btn.position.y - (diff_easy_btn.size.y * 1.2)
		_draw_centered_text(_t("select_diff"), Rect2(diff_menu_rect.position.x, title_y, diff_menu_rect.size.x, diff_easy_btn.size.y), title_sz, _theme_accent())
		draw_style_box(_make_box(Color("#243A2A"), Color("#63B47F"), 15, 2), diff_easy_btn)
		_draw_centered_text(_t("easy"), diff_easy_btn, btn_sz, Color("#F0E4D1"))
		draw_style_box(_make_box(Color("#46391F"), Color("#D2A952"), 15, 2), diff_med_btn)
		_draw_centered_text(_t("medium"), diff_med_btn, btn_sz, Color("#F0E4D1"))
		draw_style_box(_make_box(Color("#432522"), Color("#B75B51"), 15, 2), diff_hard_btn)
		_draw_centered_text(_t("hard"), diff_hard_btn, btn_sz, Color("#F0E4D1"))

	if menu_open: _draw_menu()
	if side_open: _draw_side_chooser()
	if store_open: _draw_store()
	if help_open: _draw_help()
	if settings_open: _draw_settings()
	if save_prompt_open: _draw_save_prompt()
	if load_prompt_open: _draw_load_prompt()

func _draw_load_prompt():
	draw_rect(Rect2(0, 0, screen_size.x, screen_size.y), Color(0, 0, 0, 0.7))
	_draw_shadow_rect(load_prompt_panel_rect, 24.0, 0.8, Vector2(8, 10))
	_draw_wood_panel(load_prompt_panel_rect)
	
	var title_sz = 42
	var text_sz = 28
	var btn_sz = 32
	
	var title_y = load_prompt_panel_rect.position.y + 50
	_draw_centered_text(_t("load_prompt"), Rect2(load_prompt_panel_rect.position.x, title_y, load_prompt_panel_rect.size.x, 60), title_sz, _theme_accent())
	
	var text_y = title_y + 80
	_draw_centered_text(_t("load_prompt_text"), Rect2(load_prompt_panel_rect.position.x, text_y, load_prompt_panel_rect.size.x, 50), text_sz, Color("#E8DCC8"))
	
	draw_style_box(_make_box(Color("#20372A"), Color("#5BAA79"), 15, 3), load_prompt_resume_rect)
	_draw_centered_text(_t("resume_game"), load_prompt_resume_rect, btn_sz, Color("#D8F1E0"))
	
	draw_style_box(_make_box(Color("#382321"), Color("#80524C"), 15, 3), load_prompt_new_rect)
	_draw_centered_text(_t("new_game"), load_prompt_new_rect, btn_sz, Color("#A99C96"))
	
	draw_style_box(_make_box(Color("#30271E"), Color("#876B49"), 15, 3), load_prompt_cancel_rect)
	_draw_centered_text(_t("cancel"), load_prompt_cancel_rect, btn_sz, Color("#F0E4D1"))

func _draw_save_prompt():
	draw_rect(Rect2(0, 0, screen_size.x, screen_size.y), Color(0, 0, 0, 0.7))
	_draw_shadow_rect(save_prompt_panel_rect, 24.0, 0.8, Vector2(8, 10))
	_draw_wood_panel(save_prompt_panel_rect)
	
	var title_sz = 48
	var text_sz = 32
	var btn_sz = 36
	
	var title_y = save_prompt_panel_rect.position.y + 50
	_draw_centered_text(_t("save_prompt"), Rect2(save_prompt_panel_rect.position.x, title_y, save_prompt_panel_rect.size.x, 60), title_sz, _theme_accent())
	
	var text_y = title_y + 80
	_draw_centered_text(_t("save_prompt_text"), Rect2(save_prompt_panel_rect.position.x, text_y, save_prompt_panel_rect.size.x, 50), text_sz, Color("#E8DCC8"))
	
	draw_style_box(_make_box(Color("#20372A"), Color("#5BAA79"), 15, 3), save_prompt_yes_rect)
	_draw_centered_text(_t("yes"), save_prompt_yes_rect, btn_sz, Color("#D8F1E0"))
	
	draw_style_box(_make_box(Color("#382321"), Color("#80524C"), 15, 3), save_prompt_no_rect)
	_draw_centered_text(_t("no"), save_prompt_no_rect, btn_sz, Color("#A99C96"))
	
	draw_style_box(_make_box(Color("#30271E"), Color("#876B49"), 15, 3), save_prompt_cancel_rect)
	_draw_centered_text(_t("cancel"), save_prompt_cancel_rect, btn_sz, Color("#F0E4D1"))

func _draw_settings():
	draw_rect(Rect2(0, 0, screen_size.x, screen_size.y), Color(0, 0, 0, 0.7))
	_draw_shadow_rect(settings_panel_rect, 24.0, 0.70, Vector2(8, 10)); _draw_wood_panel(settings_panel_rect)
	var btn_sz = clamp(int(set_sound_rect.size.y * 0.45), 20, 40); var title_sz = int(btn_sz * 1.2)
	var title_y = set_sound_rect.position.y - (set_sound_rect.size.y * 1.5)
	_draw_centered_text(_t("settings"), Rect2(settings_panel_rect.position.x, title_y, settings_panel_rect.size.x, set_sound_rect.size.y), title_sz, _theme_accent())
	
	draw_style_box(_make_box(Color("#20372A") if sound_enabled else Color("#382321"), Color("#5BAA79") if sound_enabled else Color("#80524C"), 10, 2 if sound_enabled else 1), set_sound_rect)
	_draw_centered_text(_t("sound") + " : " + (_t("on") if sound_enabled else _t("off")), set_sound_rect, btn_sz, Color("#D8F1E0") if sound_enabled else Color("#A99C96"))
	draw_style_box(_make_box(Color("#20372A") if music_enabled else Color("#382321"), Color("#5BAA79") if music_enabled else Color("#80524C"), 10, 2 if music_enabled else 1), set_music_rect)
	_draw_centered_text(_t("music") + " : " + (_t("on") if music_enabled else _t("off")), set_music_rect, btn_sz, Color("#D8F1E0") if music_enabled else Color("#A99C96"))
	draw_style_box(_make_box(Color("#20372A") if vibration_enabled else Color("#382321"), Color("#5BAA79") if vibration_enabled else Color("#80524C"), 10, 2 if vibration_enabled else 1), set_vib_rect)
	_draw_centered_text(_t("vibration") + " : " + (_t("on") if vibration_enabled else _t("off")), set_vib_rect, btn_sz, Color("#D8F1E0") if vibration_enabled else Color("#A99C96"))
	
	draw_style_box(_make_box(Color("#44341F") if language == 0 else Color("#28231E"), _theme_accent() if language == 0 else Color("#57493B"), 10, 2 if language == 0 else 1), set_lang_en_rect)
	_draw_centered_text(_t("english"), set_lang_en_rect, btn_sz, Color("#F3DFB0") if language == 0 else Color("#A99D8E"))
	draw_style_box(_make_box(Color("#44341F") if language == 1 else Color("#28231E"), _theme_accent() if language == 1 else Color("#57493B"), 10, 2 if language == 1 else 1), set_lang_fa_rect)
	_draw_centered_text(_t("persian"), set_lang_fa_rect, btn_sz, Color("#F3DFB0") if language == 1 else Color("#A99D8E"))
	
	draw_style_box(_make_box(Color("#38231F"), Color("#9D5A48"), 10, 1), settings_close_rect)
	_draw_centered_text(_t("back"), settings_close_rect, btn_sz, Color("#F4DDD5"))

func _on_start_game_pressed():
	if not _check_debounce(): return # جلوگیری از کلیک دوبل
	_play_sound("click")
	
	# بررسی وجود سیو برای پرسیدن سوال
	if FileAccess.file_exists(SAVE_PATH):
		load_prompt_open = true
		if has_node("StartMenu"): $StartMenu.hide() # مخفی کردن منو تا پنجره دیده شود
		queue_redraw()
	else:
		if has_node("StartMenu"): $StartMenu.hide()
		is_main_menu_open = false; is_mode_menu_open = true 
		queue_redraw()

func _theme_background(): return [Color("#080A0D"), Color("#05070D"), Color("#07100C"), Color("#100607"), Color("#071018"), Color("#050505"), Color("#0E0E0E")][game_theme]
func _theme_top(): return [Color("#10151A"), Color("#0B1020"), Color("#0C1812"), Color("#1A0A0C"), Color("#0A1822"), Color("#080808"), Color("#181818")][game_theme]
func _theme_bottom(): return [Color("#0B0D10"), Color("#070A12"), Color("#07100B"), Color("#120708"), Color("#07121A"), Color("#050505"), Color("#111111")][game_theme]
func _theme_board_outer(): return [Color("#3A2416"), Color("#161B2C"), Color("#173326"), Color("#35171A"), Color("#163044"), Color("#191919"), Color("#34302A")][game_theme]
func _theme_board_surface(): return [Color("#6B4325"), Color("#27304A"), Color("#28513D"), Color("#5A292E"), Color("#25465A"), Color("#2B2B2B"), Color("#686157")][game_theme]
func _theme_accent(): return [Color("#E0B45A"), Color("#6EA8E6"), Color("#5FC68B"), Color("#E06467"), Color("#73CFE8"), Color("#D6AA55"), Color("#E2D0A6")][game_theme]
func _theme_secondary(): return [Color("#B98243"), Color("#435E8C"), Color("#428A63"), Color("#9D454D"), Color("#4C8BA4"), Color("#866B43"), Color("#A89D8A")][game_theme]

func _draw_flag_band(c: Vector2, r: float, y1: float, y2: float, col: Color):
	var pts = PackedVector2Array(); var steps = 15
	pts.append(c + Vector2(-sqrt(max(0.0, r*r - y1*y1)), y1))
	pts.append(c + Vector2(sqrt(max(0.0, r*r - y1*y1)), y1))
	var a1 = asin(clamp(y1 / r, -1.0, 1.0)); var a2 = asin(clamp(y2 / r, -1.0, 1.0))
	for i in range(steps + 1): pts.append(c + Vector2(cos(lerp(a1, a2, float(i)/steps)) * r, sin(lerp(a1, a2, float(i)/steps)) * r))
	pts.append(c + Vector2(sqrt(max(0.0, r*r - y2*y2)), y2))
	pts.append(c + Vector2(-sqrt(max(0.0, r*r - y2*y2)), y2))
	for i in range(steps + 1): pts.append(c + Vector2(cos(lerp(PI - a2, PI - a1, float(i)/steps)) * r, sin(lerp(PI - a2, PI - a1, float(i)/steps)) * r))
	draw_colored_polygon(pts, col)

func _draw_flag_piece(pos: Vector2, skin: int, is_black: bool):
	var r = PIECE_R 
	draw_circle(pos + Vector2(4, 6), PIECE_R + 1, Color(0, 0, 0, 0.48))
	match skin:
		8: # Iran
			_draw_flag_band(pos, r, -r, -r/3, Color("#239F40")); _draw_flag_band(pos, r, -r/3, r/3, Color("#FFFFFF")); _draw_flag_band(pos, r, r/3, r, Color("#DA0000"))
			draw_circle(pos, r*0.15, Color("#DA0000"))
		9: # Yemen
			_draw_flag_band(pos, r, -r, -r/3, Color("#CE1126")); _draw_flag_band(pos, r, -r/3, r/3, Color("#FFFFFF")); _draw_flag_band(pos, r, r/3, r, Color("#000000"))
		10: # Palestine
			_draw_flag_band(pos, r, -r, -r/3, Color("#000000")); _draw_flag_band(pos, r, -r/3, r/3, Color("#FFFFFF")); _draw_flag_band(pos, r, r/3, r, Color("#007A3D"))
			draw_colored_polygon(PackedVector2Array([pos + Vector2(-r*0.8, -r*0.6), pos + Vector2(-r*0.8, r*0.6), pos + Vector2(0, 0)]), Color("#CE1126"))
		11: # Lebanon
			_draw_flag_band(pos, r, -r, -r*0.6, Color("#CE1126")); _draw_flag_band(pos, r, -r*0.6, r*0.6, Color("#FFFFFF")); _draw_flag_band(pos, r, r*0.6, r, Color("#CE1126"))
			draw_colored_polygon(PackedVector2Array([pos + Vector2(0, -r*0.3), pos + Vector2(-r*0.15, r*0.2), pos + Vector2(r*0.15, r*0.2)]), Color("#00A651"))
		12: # Iraq
			_draw_flag_band(pos, r, -r, -r/3, Color("#CE1126")); _draw_flag_band(pos, r, -r/3, r/3, Color("#FFFFFF")); _draw_flag_band(pos, r, r/3, r, Color("#000000"))
			draw_line(pos + Vector2(-r*0.3, 0), pos + Vector2(r*0.3, 0), Color("#007A3D"), 3.0)
		13: # Russia
			_draw_flag_band(pos, r, -r, -r/3, Color("#FFFFFF")); _draw_flag_band(pos, r, -r/3, r/3, Color("#0039A6")); _draw_flag_band(pos, r, r/3, r, Color("#D52B1E"))
		14: # Syria
			_draw_flag_band(pos, r, -r, -r/3, Color("#CE1126")); _draw_flag_band(pos, r, -r/3, r/3, Color("#FFFFFF")); _draw_flag_band(pos, r, r/3, r, Color("#000000"))
			draw_circle(pos + Vector2(-r*0.2, 0), r*0.1, Color("#007A3D")); draw_circle(pos + Vector2(r*0.2, 0), r*0.1, Color("#007A3D"))
		15: # China
			draw_circle(pos, r, Color("#DE2910")); draw_circle(pos + Vector2(-r*0.3, -r*0.3), r*0.2, Color("#FFDE00"))
			draw_circle(pos + Vector2(0, -r*0.1), r*0.08, Color("#FFDE00")); draw_circle(pos + Vector2(-r*0.1, r*0.1), r*0.08, Color("#FFDE00"))
			draw_circle(pos + Vector2(-r*0.2, r*0.3), r*0.08, Color("#FFDE00")); draw_circle(pos + Vector2(-r*0.4, r*0.2), r*0.08, Color("#FFDE00"))
		16: # Spain
			_draw_flag_band(pos, r, -r, -r*0.5, Color("#AA151B")); _draw_flag_band(pos, r, -r*0.5, r*0.5, Color("#F1BF00")); _draw_flag_band(pos, r, r*0.5, r, Color("#AA151B"))
			draw_circle(pos + Vector2(-r*0.35, 0), r*0.15, Color("#AA151B"))
		17: # Brazil
			draw_circle(pos, r, Color("#009C3B"))
			draw_colored_polygon(PackedVector2Array([pos + Vector2(0, -r*0.6), pos + Vector2(r*0.6, 0), pos + Vector2(0, r*0.6), pos + Vector2(-r*0.6, 0)]), Color("#FFDF00"))
			draw_circle(pos, r*0.3, Color("#002776"))
		18: # Venezuela
			_draw_flag_band(pos, r, -r, -r/3, Color("#FFCC00")); _draw_flag_band(pos, r, -r/3, r/3, Color("#0033CC")); _draw_flag_band(pos, r, r/3, r, Color("#CC0000"))
			for i in range(8):
				var ang = PI + (i * PI / 7.0)
				draw_circle(pos + Vector2(cos(ang), sin(ang)) * r * 0.5 + Vector2(0, -r/3), r*0.04, Color("#FFFFFF"))
	
	if is_black: draw_circle(pos, PIECE_R + 1.0, Color("#0A0A0A"), false, 3.5); draw_circle(pos, PIECE_R + 4.0, Color("#3A3A3A"), false, 1.5)
	else: draw_circle(pos, PIECE_R + 1.0, Color("#F5EBD8"), false, 3.5); draw_circle(pos, PIECE_R + 4.0, Color("#A08B60"), false, 1.5)
	draw_circle(pos, PIECE_R, Color(0,0,0,0.35), false, 1.0)

func _draw_piece_at(pos: Vector2, piece_color: int, override_skin: int = -1):
	var skin = override_skin if override_skin >= 0 else (skin_p1 if piece_color == 1 else skin_p2)
	
	if piece_effect == 1: _draw_glow_circle(pos, PIECE_R + 7, Color(0.95, 0.70, 0.20, 0.30))
	elif piece_effect == 2: _draw_glow_circle(pos, PIECE_R + 7, Color(0.25, 0.90, 0.55, 0.28))
	elif piece_effect == 3: _draw_glow_circle(pos, PIECE_R + 7, Color(0.95, 0.20, 0.25, 0.28))
	elif piece_effect == 4: _draw_glow_circle(pos, PIECE_R + 7, Color(0.25, 0.80, 1.0, 0.28))
	elif piece_effect == 5: _draw_glow_circle(pos, PIECE_R + 10, Color(1.0, 0.72, 0.25, 0.24))
	
	draw_circle(pos + Vector2(4, 6), PIECE_R + 1, Color(0, 0, 0, 0.48 if piece_color == 1 else 0.45))
	
	if skin >= 8:
		_draw_flag_piece(pos, skin, piece_color == 1); return

	var c = COLOR_PALETTE[skin]
	var main = Color(c[0]) if piece_color == 1 else Color(c[3])
	var inner = Color(c[1]) if piece_color == 1 else Color(c[4])
	var border = Color(c[2]) if piece_color == 1 else Color(c[5])
	
	draw_circle(pos, PIECE_R, main); draw_circle(pos - Vector2(0, 1), PIECE_R - 3, inner); draw_circle(pos, PIECE_R, border, false, 3 if piece_color == 1 else 2.5)
	var alpha = 0.30 if piece_color == 1 else 0.92
	draw_circle(pos - Vector2(PIECE_R * 0.32, PIECE_R * 0.34), PIECE_R * 0.12, Color(1, 1, 1, alpha))
	draw_circle(pos - Vector2(PIECE_R * 0.22, PIECE_R * 0.23), PIECE_R * 0.055, Color(1, 1, 1, alpha * 0.6))

func _draw_board_background():
	var bs = S * 4.0
	var outer = Rect2(O - Vector2(20, 20), Vector2(bs + 40, bs + 40))
	_draw_shadow_rect(outer, 24.0, 0.42, Vector2(7, 9))
	draw_style_box(_make_box(_theme_board_outer(), _theme_accent(), 22, 3), outer)
	draw_style_box(_make_box(_theme_board_surface(), _theme_accent(), 4, 2), Rect2(O - Vector2(11, 11), Vector2(bs + 22, bs + 22)))
	var surface = Rect2(O - Vector2(5, 5), Vector2(bs + 10, bs + 10))
	draw_style_box(_make_box(_theme_board_surface(), Color("#2D1A0E"), 4, 2), surface)
	for i in range(12):
		var yy = surface.position.y + 10.0 + i * (surface.size.y - 20.0) / 12.0
		draw_line(Vector2(surface.position.x + 5, yy), Vector2(surface.end.x - 5, yy), Color(1, 0.8, 0.55, 0.035), 2.0, true)

func _draw_tray(rect: Rect2, count: int, is_black: bool):
	_draw_shadow_rect(rect, 14.0, 0.42, Vector2(4, 6))
	draw_style_box(_make_box(Color("#241A14"), _theme_secondary(), 14, 2), rect)
	draw_style_box(_make_box(Color("#34251B"), Color("#60452E"), 10, 1), Rect2(rect.position + Vector2(6, 6), rect.size - Vector2(12, 12)))
	var pad = 8.0; var inner_w = rect.size.x - pad * 2.0; var inner_h = rect.size.y - pad * 2.0
	var slot_w = inner_w / TRAY_COLS; var slot_h = inner_h / TRAY_ROWS
	for i in range(TOTAL_PIECES):
		var pos = Vector2(rect.position.x + pad + slot_w * ((i % TRAY_COLS) + 0.5), rect.position.y + pad + slot_h * ((i / TRAY_COLS) + 0.5))
		draw_circle(pos, PIECE_R + 2, Color(0, 0, 0, 0.20))
		if i < count: _draw_piece_at(pos, 1 if is_black else 2)
		else:
			draw_circle(pos, PIECE_R, Color("#46362A")); draw_circle(pos, PIECE_R, Color("#735538"), false, 2)
			var num_text = str(i + 1); var num_size = int(PIECE_R * 0.82)
			var tw = ThemeDB.fallback_font.get_string_size(num_text, HORIZONTAL_ALIGNMENT_LEFT, -1, num_size).x
			draw_string(ThemeDB.fallback_font, Vector2(pos.x - tw / 2.0, pos.y + num_size * 0.35), num_text, HORIZONTAL_ALIGNMENT_LEFT, -1, num_size, Color("#BCA98E"))

func _draw_counter(rect: Rect2, piece_color: int, label: String, count: int):
	_draw_shadow_rect(rect, 12.0, 0.35, Vector2(3, 5))
	draw_style_box(_make_box(Color("#201811"), _theme_secondary(), 12, 1), rect)
	var cy = rect.position.y + rect.size.y / 2.0
	var text_str = label + "  " + str(count)
	var tw = ThemeDB.fallback_font.get_string_size(text_str, HORIZONTAL_ALIGNMENT_LEFT, -1, 28).x
	var start_x = rect.position.x + (rect.size.x - ((PIECE_R * 2.0) + 20.0 + tw)) / 2.0
	_draw_piece_at(Vector2(start_x + PIECE_R, cy), piece_color)
	draw_string(ThemeDB.fallback_font, Vector2(start_x + PIECE_R * 2.0 + 20.0, cy + 28 * 0.35), text_str, HORIZONTAL_ALIGNMENT_LEFT, -1, 28, Color("#E9DED0"))

func _draw_menu():
	draw_rect(Rect2(0, 0, screen_size.x, screen_size.y), Color(0, 0, 0, 0.6))
	_draw_shadow_rect(panel_rect, 24.0, 0.70, Vector2(8, 10)); _draw_wood_panel(panel_rect)
	var btn_sz = clamp(int(resume_rect.size.y * 0.45), 20, 40); var title_sz = int(btn_sz * 1.2)
	var title_y = resume_rect.position.y - (resume_rect.size.y * 1.5)
	_draw_centered_text(_t("menu"), Rect2(panel_rect.position.x, title_y, panel_rect.size.x, resume_rect.size.y), title_sz, _theme_accent())
	
	draw_style_box(_make_box(Color("#30271E"), Color("#876B49"), 10, 1), resume_rect)
	_draw_centered_text(_t("resume"), resume_rect, btn_sz, Color("#F0E4D1"))
	draw_style_box(_make_box(Color("#43251F"), Color("#9D5A48"), 10, 1), newgame_rect)
	_draw_centered_text(_t("new_game"), newgame_rect, btn_sz, Color("#F4DDD5"))
	draw_style_box(_make_box(Color("#20372A") if sound_enabled else Color("#382321"), Color("#5BAA79") if sound_enabled else Color("#80524C"), 10, 2 if sound_enabled else 1), sound_rect)
	_draw_centered_text(_t("sound"), sound_rect, btn_sz, Color("#D8F1E0") if sound_enabled else Color("#A99C96"))
	draw_style_box(_make_box(Color("#20372A") if music_enabled else Color("#382321"), Color("#5BAA79") if music_enabled else Color("#80524C"), 10, 2 if music_enabled else 1), music_rect)
	_draw_centered_text(_t("music"), music_rect, btn_sz, Color("#D8F1E0") if music_enabled else Color("#A99C96"))
	draw_style_box(_make_box(Color("#38231F"), Color("#9D5A48"), 10, 1), exit_to_main_rect)
	_draw_centered_text(_t("home"), exit_to_main_rect, btn_sz, Color("#F4DDD5"))

func _draw_side_chooser():
	draw_rect(Rect2(0, 0, screen_size.x, screen_size.y), Color(0, 0, 0, 0.6))
	_draw_shadow_rect(side_panel_rect, 24.0, 0.70, Vector2(8, 10)); _draw_wood_panel(side_panel_rect)
	var btn_sz = clamp(int(side_black_rect.size.y * 0.18), 20, 40); var title_sz = int(btn_sz * 1.2)
	var title_y = side_black_rect.position.y - (side_black_rect.size.y * 0.25)
	_draw_centered_text(_t("choose_side"), Rect2(side_panel_rect.position.x, title_y, side_panel_rect.size.x, 40), title_sz, _theme_accent())
	
	_draw_custom_side_btn(side_black_rect, true, player_color == 1)
	var pos_b = side_black_rect.position
	_draw_piece_at(Vector2(pos_b.x + side_black_rect.size.x/2, pos_b.y + side_black_rect.size.y*0.35), 1)
	_draw_centered_text(_get_skin_name(skin_p1), Rect2(pos_b.x, pos_b.y + side_black_rect.size.y*0.65, side_black_rect.size.x, 40), btn_sz, Color("#F5E9D5"))
	
	_draw_custom_side_btn(side_white_rect, false, player_color == 2)
	var pos_w = side_white_rect.position
	_draw_piece_at(Vector2(pos_w.x + side_white_rect.size.x/2, pos_w.y + side_white_rect.size.y*0.35), 2)
	_draw_centered_text(_get_skin_name(skin_p2), Rect2(pos_w.x, pos_w.y + side_white_rect.size.y*0.65, side_white_rect.size.x, 40), btn_sz, Color("#27221D"))

func _draw_custom_side_btn(rect: Rect2, is_black: bool, is_selected: bool):
	var base = Color("#2b1a10") if is_black else Color("#eedac1")
	var grain_dark = Color("#140a05") if is_black else Color("#c4a88b"); var grain_light = Color("#4a2c1c") if is_black else Color("#fff5e6")
	var border = _theme_accent() if is_selected else (Color("#5c3c28") if is_black else Color("#b59d85")); var bw = 4 if is_selected else 2
	draw_style_box(_make_box(base, Color(0,0,0,0), 16, 0), rect)
	for i in range(18):
		var x_base = rect.position.x + 15 + i * (rect.size.x - 30) / 17.0
		var pts = PackedVector2Array()
		for j in range(15):
			pts.append(Vector2(x_base + sin(j * 1.5 + i * 0.7) * 5.0 + cos(j * 3.0 + i) * 2.0, rect.position.y + 10 + j * (rect.size.y - 20) / 14.0))
		draw_polyline(pts, Color(grain_light.r, grain_light.g, grain_light.b, 0.5) if i % 4 == 0 else Color(grain_dark.r, grain_dark.g, grain_dark.b, 0.6), 2.0 if i % 4 == 0 else 1.5, true)
	draw_style_box(_make_box(Color(0,0,0,0), border, 16, bw), rect)

func _draw_store():
	draw_rect(Rect2(0, 0, screen_size.x, screen_size.y), Color(0, 0, 0, 0.85))
	_draw_shadow_rect(store_panel_rect, 24.0, 0.75, Vector2(8, 10)); _draw_wood_panel(store_panel_rect)
	_draw_centered_text(_t("premium_store"), Rect2(store_panel_rect.position.x, store_panel_rect.position.y + 10, store_panel_rect.size.x, 50), 36, _theme_accent())
	_draw_centered_text(_t("coins") + ": " + str(coins), Rect2(store_panel_rect.position.x, store_panel_rect.position.y + 55, store_panel_rect.size.x, 40), 34, Color("#E6C56D"))

	draw_style_box(_make_box(Color("#44341F") if store_tab == 0 else Color("#28231E"), _theme_accent() if store_tab == 0 else Color("#57493B"), 10, 2 if store_tab == 0 else 1), store_piece_tab_rect)
	_draw_centered_text(_t("piece_skins"), store_piece_tab_rect, 30, Color("#F3DFB0") if store_tab == 0 else Color("#A99D8E"))
	draw_style_box(_make_box(Color("#44341F") if store_tab == 1 else Color("#28231E"), _theme_accent() if store_tab == 1 else Color("#57493B"), 10, 2 if store_tab == 1 else 1), store_theme_tab_rect)
	_draw_centered_text(_t("board_themes"), store_theme_tab_rect, 30, Color("#F3DFB0") if store_tab == 1 else Color("#A99D8E"))
	draw_style_box(_make_box(Color("#38221F"), Color("#9C5A4D"), 12, 2), store_close_rect)
	_draw_centered_text(_t("close"), store_close_rect, 40, Color("#F0D8D0"))

	if store_tab == 0:
		draw_style_box(_make_box(Color("#44341F") if store_active_player == 1 else Color("#28231E"), _theme_accent() if store_active_player == 1 else Color("#57493B"), 10, 2 if store_active_player == 1 else 1), store_p1_btn_rect)
		_draw_centered_text(_t("player_1"), store_p1_btn_rect, 28, Color("#F3DFB0") if store_active_player == 1 else Color("#A99D8E"))
		draw_style_box(_make_box(Color("#44341F") if store_active_player == 2 else Color("#28231E"), _theme_accent() if store_active_player == 2 else Color("#57493B"), 10, 2 if store_active_player == 2 else 1), store_p2_btn_rect)
		_draw_centered_text(_t("player_2"), store_p2_btn_rect, 28, Color("#F3DFB0") if store_active_player == 2 else Color("#A99D8E"))

		var preview_color = 1 if store_active_player == 1 else 2

		_draw_centered_text(_t("color_skins"), Rect2(store_panel_rect.position.x, color_header_y, store_panel_rect.size.x, 30), 24, _theme_accent())
		for i in range(color_skin_rects.size()):
			var r = color_skin_rects[i]
			var is_sel = (skin_p1 == i) if store_active_player == 1 else (skin_p2 == i)
			var is_owned = (i in owned_skins)
			draw_style_box(_make_box(Color("#1A1410") if is_sel else Color("#2B241D"), _theme_accent() if is_sel else Color("#5E4B38"), 12, 3 if is_sel else 1), r)
			var old_pr = PIECE_R; PIECE_R = clamp(r.size.x * 0.34, 18.0, 45.0)
			_draw_piece_at(Vector2(r.position.x + r.size.x / 2.0, r.position.y + r.size.y * 0.40), preview_color, i)
			PIECE_R = old_pr
			_draw_centered_text(_get_skin_name(i), Rect2(r.position.x, r.position.y + r.size.y * 0.72, r.size.x, r.size.y * 0.15), clamp(int(r.size.y * 0.11), 12, 22), Color("#F0E4D1"))
			var status = _t("equipped") if is_sel else (_t("owned") if is_owned else _t("free"))
			var scol = _theme_accent() if is_sel else (Color("#7ECB9E") if is_owned else Color("#E6C56D"))
			_draw_centered_text(status, Rect2(r.position.x, r.position.y + r.size.y * 0.88, r.size.x, r.size.y * 0.15), clamp(int(r.size.y * 0.13), 10, 22), scol)
		
		_draw_centered_text(_t("flag_skins"), Rect2(store_panel_rect.position.x, flag_header_y, store_panel_rect.size.x, 30), 24, _theme_accent())
		for i in range(flag_skin_rects.size()):
			var r = flag_skin_rects[i]; var skin_idx = i + 8
			var is_sel = (skin_p1 == skin_idx) if store_active_player == 1 else (skin_p2 == skin_idx)
			var is_owned = (skin_idx in owned_skins)
			draw_style_box(_make_box(Color("#1A1410") if is_sel else Color("#2B241D"), _theme_accent() if is_sel else Color("#5E4B38"), 12, 3 if is_sel else 1), r)
			var old_pr = PIECE_R; PIECE_R = clamp(r.size.x * 0.34, 18.0, 45.0)
			_draw_piece_at(Vector2(r.position.x + r.size.x / 2.0, r.position.y + r.size.y * 0.40), preview_color, skin_idx)
			PIECE_R = old_pr
			_draw_centered_text(_get_skin_name(skin_idx), Rect2(r.position.x, r.position.y + r.size.y * 0.72, r.size.x, r.size.y * 0.15), clamp(int(r.size.y * 0.11), 12, 22), Color("#F0E4D1"))
			var status = _t("equipped") if is_sel else (_t("owned") if is_owned else str(SKIN_PRICES[skin_idx]) + " C")
			var scol = _theme_accent() if is_sel else (Color("#7ECB9E") if is_owned else Color("#E6C56D"))
			_draw_centered_text(status, Rect2(r.position.x, r.position.y + r.size.y * 0.88, r.size.x, r.size.y * 0.15), clamp(int(r.size.y * 0.13), 10, 22), scol)
	else:
		for i in range(theme_rects.size()):
			var r = theme_rects[i]; var is_sel = (game_theme == i); var is_owned = (i in owned_themes)
			draw_style_box(_make_box(Color("#1A1410") if is_sel else Color("#2B241D"), _theme_accent() if is_sel else Color("#5E4B38"), 12, 3 if is_sel else 1), r)
			var old_theme = game_theme; game_theme = i
			var prev_h = r.size.y * 0.5
			draw_style_box(_make_box(_theme_background(), Color(0,0,0,0), 8, 0), Rect2(r.position.x + 10, r.position.y + 10, r.size.x - 20, prev_h))
			var bsize = min(r.size.x * 0.35, prev_h * 0.75)
			var prev_board = Rect2(r.position.x + r.size.x/2 - bsize/2, r.position.y + 15 + (prev_h - bsize)/2, bsize, bsize)
			draw_style_box(_make_box(_theme_board_outer(), _theme_accent(), 4, 2), prev_board)
			draw_style_box(_make_box(_theme_board_surface(), Color(0,0,0,0), 2, 0), Rect2(prev_board.position + Vector2(4,4), prev_board.size - Vector2(8,8)))
			game_theme = old_theme
			_draw_centered_text("THEME " + str(i+1), Rect2(r.position.x, r.position.y + r.size.y * 0.72, r.size.x, r.size.y * 0.15), clamp(int(r.size.y * 0.11), 12, 22), Color("#F0E4D1"))
			var status = _t("equipped") if is_sel else (_t("owned") if is_owned else str(THEME_PRICES[i]) + " C")
			var scol = _theme_accent() if is_sel else (Color("#7ECB9E") if is_owned else Color("#E6C56D"))
			_draw_centered_text(status, Rect2(r.position.x, r.position.y + r.size.y * 0.88, r.size.x, r.size.y * 0.15), clamp(int(r.size.y * 0.13), 10, 22), scol)

func _draw_help():
	draw_rect(Rect2(0, 0, screen_size.x, screen_size.y), Color(0, 0, 0, 0.85))
	_draw_shadow_rect(help_panel_rect, 24.0, 0.75, Vector2(8, 10)); _draw_wood_panel(help_panel_rect)
	_draw_centered_text(_t("help"), Rect2(help_panel_rect.position.x, help_panel_rect.position.y + 10, help_panel_rect.size.x, 50), 48, _theme_accent())
	draw_style_box(_make_box(Color("#44341F") if help_tab == 0 else Color("#28231E"), _theme_accent() if help_tab == 0 else Color("#57493B"), 10, 2 if help_tab == 0 else 1), help_intro_tab_rect)
	_draw_centered_text(_t("intro"), help_intro_tab_rect, 28, Color("#F3DFB0") if help_tab == 0 else Color("#A99D8E"))
	draw_style_box(_make_box(Color("#44341F") if help_tab == 1 else Color("#28231E"), _theme_accent() if help_tab == 1 else Color("#57493B"), 10, 2 if help_tab == 1 else 1), help_rules_tab_rect)
	_draw_centered_text(_t("rules"), help_rules_tab_rect, 28, Color("#F3DFB0") if help_tab == 1 else Color("#A99D8E"))
	draw_style_box(_make_box(Color("#20372A"), Color("#5BAA79"), 12, 2), help_copy_rect)
	_draw_centered_text(_t("copy"), help_copy_rect, 32, Color("#D8F1E0"))
	if copy_flash > 0.0: _draw_centered_text(_t("copied"), Rect2(help_copy_rect.end.x + 20, help_copy_rect.position.y, 150, help_copy_rect.size.y), 26, Color("#A9F3C9"))
	draw_style_box(_make_box(Color("#38221F"), Color("#9C5A4D"), 12, 1), help_close_rect)
	_draw_centered_text(_t("close"), help_close_rect, 32, Color("#F0D8D0"))

	var cx = help_panel_rect.position.x + 30.0; var cy = help_panel_rect.position.y + 230.0
	var cw = help_panel_rect.size.x - 60.0; var cb = help_panel_rect.end.y - 120.0
	if help_tab == 0: _draw_help_intro(cx, cy, cw)
	else: _draw_help_rules(cx, cy, cw, cb)

func _draw_help_intro(cx: float, cy: float, cw: float):
	var font = ThemeDB.fallback_font; var fs = 34; var lh = 48.0; var y = cy
	for para in (HELP_INTRO_TEXT_FA if language == 1 else HELP_INTRO_TEXT).split("\n"):
		if para.strip_edges() == "": y += lh * 0.5; continue
		var line = ""
		for word in para.split(" "):
			var test = line + word + " "
			if font.get_string_size(test, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x > cw and line != "":
				draw_string(font, Vector2(cx if language == 0 else cx + cw - font.get_string_size(line.strip_edges(), HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x, y), line.strip_edges(), HORIZONTAL_ALIGNMENT_LEFT, -1, fs, Color("#E8DCC8"))
				y += lh; line = word + " "
			else: line = test
		if line.strip_edges() != "":
			draw_string(font, Vector2(cx if language == 0 else cx + cw - font.get_string_size(line.strip_edges(), HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x, y), line.strip_edges(), HORIZONTAL_ALIGNMENT_LEFT, -1, fs, Color("#E8DCC8"))
			y += lh
	y += lh * 2
	draw_string(font, Vector2(cx if language == 0 else cx + cw - font.get_string_size(_t("developer"), HORIZONTAL_ALIGNMENT_LEFT, -1, fs + 4).x, y), _t("developer"), HORIZONTAL_ALIGNMENT_LEFT, -1, fs + 4, _theme_accent())

func _draw_help_rules(cx: float, cy: float, cw: float, cb: float):
	var font = ThemeDB.fallback_font; var fs = 30; var lh = 42.0; var y = cy
	for para in (HELP_RULES_TEXT_FA if language == 1 else HELP_RULES_TEXT).split("\n"):
		if y > cb - lh: draw_string(font, Vector2(cx, y), "...", HORIZONTAL_ALIGNMENT_LEFT, -1, fs, Color("#9C8A76")); break
		if para.strip_edges() == "": y += lh * 0.4; continue
		var is_h = not para.begins_with("-")
		var col = Color("#F0D27C") if is_h else Color("#E8DCC8")
		var sz = fs + 5 if is_h else fs
		var line = ""
		for word in para.split(" "):
			var test = line + word + " "
			if font.get_string_size(test, HORIZONTAL_ALIGNMENT_LEFT, -1, sz).x > cw and line != "":
				draw_string(font, Vector2(cx if language == 0 else cx + cw - font.get_string_size(line.strip_edges(), HORIZONTAL_ALIGNMENT_LEFT, -1, sz).x, y), line.strip_edges(), HORIZONTAL_ALIGNMENT_LEFT, -1, sz, col)
				y += lh; line = word + " "
			else: line = test
		if line.strip_edges() != "":
			draw_string(font, Vector2(cx if language == 0 else cx + cw - font.get_string_size(line.strip_edges(), HORIZONTAL_ALIGNMENT_LEFT, -1, sz).x, y), line.strip_edges(), HORIZONTAL_ALIGNMENT_LEFT, -1, sz, col)
			y += lh + (8 if is_h else 0)
	y += lh * 2
	draw_string(font, Vector2(cx if language == 0 else cx + cw - font.get_string_size(_t("developer"), HORIZONTAL_ALIGNMENT_LEFT, -1, fs + 4).x, y), _t("developer"), HORIZONTAL_ALIGNMENT_LEFT, -1, fs + 4, _theme_accent())

func _draw_icon_menu(rect: Rect2, color: Color):
	var cx = rect.position.x + rect.size.x / 2.0; var cy = rect.position.y + rect.size.y / 2.0
	for i in range(3):
		draw_line(Vector2(cx - rect.size.x * 0.3, cy + (i - 1) * 16.0), Vector2(cx + rect.size.x * 0.3, cy + (i - 1) * 16.0), color, 10.0)
