extends Node2D

var S = 100.0
var PR = 18.0
var PIECE_R = 24.0
var O = Vector2.ZERO
var current = 1
var placed = 0
var first = 0
var phase = "place"
var debug_text = "BLACK - PLACE"
var selected = Vector2(-1, -1)
var valid_moves = []
var capture_options = []
var last_tap_ms = 0
var black_count = 0
var white_count = 0
var screen_size = Vector2.ZERO

var menu_rect = Rect2()
var help_rect = Rect2()
var menu_open = false
var panel_rect = Rect2()
var resume_rect = Rect2()
var newgame_rect = Rect2()
var sound_rect = Rect2()
var mode_2p_rect = Rect2()
var mode_ai_rect = Rect2()
var diff_easy_rect = Rect2()
var diff_med_rect = Rect2()
var diff_hard_rect = Rect2()

var black_counter_rect = Rect2()
var black_tray_rect = Rect2()
var white_tray_rect = Rect2()
var white_counter_rect = Rect2()

var side_open = true
var player_color = 1
var computer_color = 2
var side_panel_rect = Rect2()
var side_black_rect = Rect2()
var side_white_rect = Rect2()

var vs_computer = false
var ai_delay = 1.0
var difficulty = 1

var turn_time = 60.0
const TURN_LIMIT = 60.0
const TOTAL_PIECES = 12
const TRAY_COLS = 6
const TRAY_ROWS = 2

const SAVE_PATH = "user://save_game.json"
const SHOP_PATH = "user://shop_data.json"

var store_open = false
var store_tab = 0

var store_rect = Rect2()
var store_panel_rect = Rect2()
var store_close_rect = Rect2()
var store_piece_tab_rect = Rect2()
var store_theme_tab_rect = Rect2()

var help_open = false
var help_tab = 0
var help_panel_rect = Rect2()
var help_close_rect = Rect2()
var help_intro_tab_rect = Rect2()
var help_rules_tab_rect = Rect2()
var help_copy_rect = Rect2()
var copy_flash = 0.0

const HELP_INTRO_TEXT = "Welcome to the world of RAH BI RAH!\n\nThis game is not just an ordinary game. It is a local treasure from the village of Charak Dashti in Bushehr Province, in our beloved Iran.\n\nFor generations, it has been played among the people of this region, in the warmth of Bushehr, together, with laughter and competition.\n\nNow it is your turn to become part of this story. Here, you compete with your opponent, place your pieces, move wisely, and trap your opponent's pieces. A game that demands thought, patience, and precision!\n\nAre you ready to keep this heritage alive?"

const HELP_RULES_TEXT = "GOAL\nRemove 11 of the opponent's pieces, leaving them with only 1 piece to win. No draws. Someone always wins.\n\nSETUP\n- 5x5 board with 25 points\n- 12 BLACK + 12 WHITE pieces\n- Two trays outside the board\n- The center point stays empty\n\nPLACEMENT PHASE\n- Players take turns placing pieces one by one on any empty blue point\n- BLACK places first\n- No captures during this phase\n- The player who places first moves second\n\nMOVEMENT PHASE\n- Move one piece to an adjacent empty point\n- All 8 directions allowed (horizontal, vertical, diagonal)\n- Backward moves allowed\n\nCAPTURING (SANDWICH)\n- If your move places an enemy piece between two of your pieces, it is captured\n- Works in all directions\n- You get a bonus move after each capture\n- Bonus moves chain if you capture again\n\nMULTIPLE CAPTURES\n- If one move creates multiple sandwiches, circles appear around capturable pieces\n- You choose one to remove\n\nCORNER SAFETY\n- Pieces in the 4 corners are safe and cannot be captured\n\nNO SUICIDE\n- Placing your own piece between two enemy pieces does nothing\n\nTIMER\n- 60 seconds per turn\n- Timer shown as a colored border\n- Time out, turn passes to opponent\n\nNO MOVES?\n- If you have no legal moves, your turn is skipped\n- Wait for opponent to open a path\n\nWIN\n- Capture 11 pieces to win"

const HELP_CREDIT_TEXT = "\n\n\n\n\nDeveloper: Kalat Group"

var coins = 100

var piece_skin = 0
var owned_skins = [0]

var piece_effect = 0
var owned_effects = [0]

var game_theme = 0
var owned_themes = [0]

var skin_rects = []
var effect_rects = []
var theme_rects = []

var anim_active = false
var anim_from_pos = Vector2.ZERO
var anim_to_pos = Vector2.ZERO
var anim_piece_color = 0
var anim_progress = 0.0
var anim_tr = 0
var anim_tc = 0
var anim_is_ai = false

const ANIM_TIME = 0.22

var sound_enabled = true
var snd_players = {}

var state = [
	[0, 0, 0, 0, 0],
	[0, 0, 0, 0, 0],
	[0, 0, -1, 0, 0],
	[0, 0, 0, 0, 0],
	[0, 0, 0, 0, 0]
]

func _ready():
	position = Vector2.ZERO
	await get_tree().process_frame
	_setup_sounds()
	_load_shop()
	_setup_rotation()
	_center()
	if not get_viewport().size_changed.is_connected(_on_resize):
		get_viewport().size_changed.connect(_on_resize)
	if _load_game():
		side_open = false
		anim_active = false
		anim_progress = 0.0
		selected = Vector2(-1, -1)
		valid_moves.clear()
		capture_options.clear()
		ai_delay = 1.0
		_update_text()
	else:
		side_open = true
	queue_redraw()

func _save_game():
	if side_open:
		return
	if anim_active:
		return
	if phase == "place" and placed == 0:
		return
	if phase == "gameover":
		_delete_save()
		return
	var data = {
		"state": state,
		"current": current,
		"placed": placed,
		"first": first,
		"phase": phase,
		"black_count": black_count,
		"white_count": white_count,
		"turn_time": turn_time,
		"vs_computer": vs_computer,
		"computer_color": computer_color,
		"difficulty": difficulty,
		"player_color": player_color,
		"sound_enabled": sound_enabled
	}
	var file = FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if file:
		file.store_string(JSON.stringify(data))
		file.close()

func _load_game() -> bool:
	if not FileAccess.file_exists(SAVE_PATH):
		return false
	var file = FileAccess.open(SAVE_PATH, FileAccess.READ)
	if not file:
		return false
	var text = file.get_as_text()
	file.close()
	var parsed = JSON.parse_string(text)
	if parsed == null:
		return false
	if not (parsed is Dictionary):
		return false
	var d = parsed as Dictionary
	if not d.has("state"):
		return false
	var s = d["state"]
	if not (s is Array) or s.size() != 5:
		return false
	state = []
	for row in s:
		if not (row is Array) or row.size() != 5:
			return false
		var new_row = []
		for v in row:
			new_row.append(int(v))
		state.append(new_row)
	current = int(d.get("current", 1))
	placed = int(d.get("placed", 0))
	first = int(d.get("first", 0))
	phase = str(d.get("phase", "place"))
	black_count = int(d.get("black_count", 0))
	white_count = int(d.get("white_count", 0))
	turn_time = float(d.get("turn_time", TURN_LIMIT))
	vs_computer = bool(d.get("vs_computer", false))
	computer_color = int(d.get("computer_color", 2))
	difficulty = int(d.get("difficulty", 1))
	player_color = int(d.get("player_color", 1))
	sound_enabled = bool(d.get("sound_enabled", true))
	if turn_time < 0.0:
		turn_time = TURN_LIMIT
	if placed < 0:
		placed = 0
	return true

func _delete_save():
	if FileAccess.file_exists(SAVE_PATH):
		DirAccess.remove_absolute(SAVE_PATH)

func _save_shop():
	var data = {
		"coins": coins,
		"piece_skin": piece_skin,
		"owned_skins": owned_skins,
		"piece_effect": piece_effect,
		"owned_effects": owned_effects,
		"game_theme": game_theme,
		"owned_themes": owned_themes
	}
	var file = FileAccess.open(SHOP_PATH, FileAccess.WRITE)
	if file:
		file.store_string(JSON.stringify(data))
		file.close()

func _load_shop():
	owned_skins = [0, 1, 2, 3, 4, 5, 6, 7]
	owned_effects = [0, 1, 2, 3, 4, 5]
	owned_themes = [0, 1, 2, 3, 4, 5, 6]
	if not FileAccess.file_exists(SHOP_PATH):
		coins = 100
		piece_skin = 0
		piece_effect = 0
		game_theme = 0
		_save_shop()
		return
	var file = FileAccess.open(SHOP_PATH, FileAccess.READ)
	if not file:
		return
	var text = file.get_as_text()
	file.close()
	var parsed = JSON.parse_string(text)
	if parsed != null and parsed is Dictionary:
		var d = parsed as Dictionary
		coins = int(d.get("coins", 100))
		piece_skin = int(d.get("piece_skin", 0))
		piece_effect = int(d.get("piece_effect", 0))
		game_theme = int(d.get("game_theme", 0))
	owned_skins = [0, 1, 2, 3, 4, 5, 6, 7]
	owned_effects = [0, 1, 2, 3, 4, 5]
	owned_themes = [0, 1, 2, 3, 4, 5, 6]
	if piece_skin < 0 or piece_skin > 7:
		piece_skin = 0
	if piece_effect < 0 or piece_effect > 5:
		piece_effect = 0
	if game_theme < 0 or game_theme > 6:
		game_theme = 0
	_save_shop()

func _buy_or_select_skin(id: int, _price: int):
	if id < 0 or id > 7:
		return
	if not id in owned_skins:
		owned_skins.append(id)
	piece_skin = id
	_play_sound("click")
	_save_shop()
	queue_redraw()

func _buy_or_select_effect(id: int, _price: int):
	if id < 0 or id > 5:
		return
	if not id in owned_effects:
		owned_effects.append(id)
	piece_effect = id
	_play_sound("click")
	_save_shop()
	queue_redraw()

func _buy_or_select_theme(id: int, _price: int):
	if id < 0 or id > 6:
		return
	if not id in owned_themes:
		owned_themes.append(id)
	game_theme = id
	_play_sound("click")
	_save_shop()
	queue_redraw()

func _earn_coins(amount: int):
	coins += amount
	if coins < 0:
		coins = 0
	_save_shop()

func _notification(what):
	if what == NOTIFICATION_APPLICATION_PAUSED \
	or what == NOTIFICATION_WM_CLOSE_REQUEST \
	or what == NOTIFICATION_WM_GO_BACK_REQUEST:
		_save_game()
		_save_shop()

# =========================================================
# SOUND
# =========================================================

func _make_tone(
	freq: float,
	duration: float,
	volume: float = 0.5,
	freq2: float = -1.0
) -> AudioStreamWAV:
	var sample_rate = 22050
	var num_samples = int(sample_rate * duration)
	var data = PackedByteArray()
	data.resize(num_samples * 2)
	var fade = 0.006
	for i in range(num_samples):
		var t = float(i) / sample_rate
		var env = 1.0
		if t < fade:
			env = t / fade
		elif t > duration - fade:
			env = (duration - t) / fade
		var f = freq
		if freq2 > 0.0:
			var half = duration / 2.0
			f = freq if t < half else freq2
		var sample = sin(TAU * f * t) * volume * env
		var s16 = int(clamp(sample, -1.0, 1.0) * 32767)
		data.encode_s16(i * 2, s16)
	var stream = AudioStreamWAV.new()
	stream.format = AudioStreamWAV.FORMAT_16_BITS
	stream.mix_rate = sample_rate
	stream.stereo = false
	stream.data = data
	return stream

func _setup_sounds():
	var place_snd = _make_tone(880.0, 0.07, 0.45)
	var move_snd = _make_tone(660.0, 0.06, 0.4)
	var cap_snd = _make_tone(440.0, 0.18, 0.55, 280.0)
	var win_snd = _make_tone(700.0, 0.5, 0.55, 1050.0)
	var click_snd = _make_tone(1200.0, 0.04, 0.35)
	var time_snd = _make_tone(500.0, 0.3, 0.5, 400.0)
	var sounds = {
		"place": place_snd,
		"move": move_snd,
		"capture": cap_snd,
		"win": win_snd,
		"click": click_snd,
		"time": time_snd
	}
	for k in sounds.keys():
		var p = AudioStreamPlayer.new()
		p.stream = sounds[k]
		p.volume_db = 0.0
		add_child(p)
		snd_players[k] = p

func _play_sound(name: String):
	if not sound_enabled:
		return
	if snd_players.has(name):
		var p = snd_players[name]
		p.stop()
		p.volume_db = 0.0
		p.play()

func _stop_all_sounds():
	for k in snd_players.keys():
		var p = snd_players[k]
		p.stop()
		p.volume_db = -80.0

# =========================================================
# PROCESS
# =========================================================

func _process(delta):
	if copy_flash > 0.0:
		copy_flash -= delta
		if copy_flash < 0.0:
			copy_flash = 0.0
		queue_redraw()
	if side_open or phase == "gameover" or menu_open or store_open or help_open:
		return
	if anim_active:
		anim_progress += delta / ANIM_TIME
		if anim_progress >= 1.0:
			anim_progress = 1.0
			_finish_animation()
		queue_redraw()
	if vs_computer and current == computer_color:
		if anim_active:
			return
		ai_delay -= delta
		if ai_delay <= 0:
			_ai_play()
		queue_redraw()
		return
	if not anim_active and (phase == "place" or phase == "move"):
		turn_time -= delta
		if turn_time <= 0:
			turn_time = 0
			_time_out()
		queue_redraw()

# =========================================================
# ANIMATION
# =========================================================

func _start_animation(sr: int, sc: int, tr: int, tc: int, is_ai: bool):
	var piece = state[sr][sc]
	if _is_center(sr, sc):
		state[sr][sc] = -1
	else:
		state[sr][sc] = 0
	anim_active = true
	anim_from_pos = gp(sr, sc)
	anim_to_pos = gp(tr, tc)
	anim_piece_color = piece
	anim_progress = 0.0
	anim_tr = tr
	anim_tc = tc
	anim_is_ai = is_ai
	selected = Vector2(-1, -1)
	valid_moves.clear()
	_play_sound("move")
	queue_redraw()

func _finish_animation():
	state[anim_tr][anim_tc] = anim_piece_color
	anim_active = false
	var tr = anim_tr
	var tc = anim_tc
	var was_ai = anim_is_ai
	_after_move(tr, tc)
	if was_ai:
		ai_delay = 0.5
	_save_game()
	queue_redraw()

# =========================================================
# AI
# =========================================================

func _ai_play():
	if phase == "place":
		_ai_place()
	elif phase == "move":
		_ai_move()
	elif phase == "choose_capture":
		_ai_choose_capture()

func _ai_place():
	var options = []
	for r in range(5):
		for c in range(5):
			if not _is_center(r, c) and _is_empty(r, c):
				var sc = 30
				if _is_corner(r, c):
					sc = 100
				elif r == 0 or r == 4 or c == 0 or c == 4:
					sc = 60
				if difficulty == 0:
					sc += randi() % 200
				elif difficulty == 1:
					sc += randi() % 50
				else:
					sc += randi() % 10
				options.append({
					"pos": Vector2(r, c),
					"score": sc
				})
	if options.size() == 0:
		return
	options.sort_custom(
		func(a, b):
			return a["score"] > b["score"]
	)
	var pick = options[0]["pos"]
	_handle_place(int(pick.x), int(pick.y))
	ai_delay = 0.5

func _ai_move():
	var all_moves = []
	for r in range(5):
		for c in range(5):
			if state[r][c] == computer_color:
				for m in _get_moves(r, c):
					all_moves.append({
						"from": Vector2(r, c),
						"to": m
					})
	if all_moves.size() == 0:
		_time_out()
		ai_delay = 0.9
		return
	if difficulty == 0 and randf() < 0.4:
		var pick = all_moves[randi() % all_moves.size()]
		_start_animation(
			int(pick["from"].x),
			int(pick["from"].y),
			int(pick["to"].x),
			int(pick["to"].y),
			true
		)
		return
	var best = null
	var best_score = -999999
	for mv in all_moves:
		var sc = _ai_score_move(
			int(mv["from"].x),
			int(mv["from"].y),
			int(mv["to"].x),
			int(mv["to"].y)
		)
		if sc > best_score:
			best_score = sc
			best = mv
	if best == null:
		_time_out()
		ai_delay = 0.9
		return
	_start_animation(
		int(best["from"].x),
		int(best["from"].y),
		int(best["to"].x),
		int(best["to"].y),
		true
	)

func _ai_score_move(from_r, from_c, to_r, to_c):
	var save_to = state[to_r][to_c]
	var save_from = state[from_r][from_c]
	state[to_r][to_c] = save_from
	if _is_center(from_r, from_c):
		state[from_r][from_c] = -1
	else:
		state[from_r][from_c] = 0
	var caps = _check_sandwiches(to_r, to_c)
	var score = caps.size() * 1000
	if _is_center(to_r, to_c):
		score += 40
	if _is_corner(to_r, to_c):
		score -= 30
	if difficulty == 2:
		var opp_caps = _count_opponent_captures()
		score -= opp_caps * 600
		if _is_threatened(to_r, to_c):
			score -= 300
	if difficulty == 0:
		score += randi() % 300
	elif difficulty == 1:
		score += randi() % 60
	else:
		score += randi() % 10
	state[to_r][to_c] = save_to
	state[from_r][from_c] = save_from
	return score

func _count_opponent_captures():
	var count = 0
	var opponent = 3 - computer_color
	for r in range(5):
		for c in range(5):
			if state[r][c] == opponent:
				for m in _get_moves(r, c):
					var mr = int(m.x)
					var mc = int(m.y)
					var save_to = state[mr][mc]
					var save_from = state[r][c]
					state[mr][mc] = save_from
					if _is_center(r, c):
						state[r][c] = -1
					else:
						state[r][c] = 0
					var saved_current = current
					current = opponent
					var caps = _check_sandwiches(mr, mc)
					current = saved_current
					state[mr][mc] = save_to
					state[r][c] = save_from
					count += caps.size()
	return count

func _is_threatened(r, c):
	var opp = 3 - computer_color
	var saved = state[r][c]
	state[r][c] = opp
	var saved_current = current
	current = opp
	var caps = _check_sandwiches(r, c)
	current = saved_current
	state[r][c] = saved
	return caps.size() > 0

func _ai_choose_capture():
	if capture_options.size() == 0:
		phase = "move"
		_begin_turn()
		ai_delay = 0.9
		return
	var pick = capture_options[0]
	_handle_choose_capture(int(pick.x), int(pick.y))
	ai_delay = 0.9

func _time_out():
	_play_sound("time")
	turn_time = TURN_LIMIT
	if phase == "place":
		current = 3 - current
		_update_text()
	elif phase == "move":
		selected = Vector2(-1, -1)
		valid_moves.clear()
		capture_options.clear()
		current = 3 - current
		_begin_turn()
	_save_game()

func _on_resize():
	_setup_rotation()
	_center()

func _setup_rotation():
	var vp = get_viewport().get_visible_rect().size
	if vp.x < 100 or vp.y < 100:
		return
	rotation = -PI / 2.0
	position = Vector2(0, vp.y)

func _center():
	var vp = get_viewport().get_visible_rect().size
	if vp.x < 100 or vp.y < 100:
		return
	var vw = vp.y
	var vh = vp.x
	screen_size = Vector2(vw, vh)

	menu_rect = Rect2(vw - 110.0, 12.0, 90.0, 45.0)
	help_rect = Rect2(20.0, 12.0, 90.0, 45.0)
	store_rect = Rect2(20.0, vh - 58.0, 112.0, 44.0)

	var counter_h = 45.0
	var counter_w = 200.0
	var gap_small = 8.0
	var margin = 10.0
	var dpi = DisplayServer.screen_get_dpi()
	if dpi <= 0:
		dpi = 320.0
	var gap_large = 1.5 * dpi / 2.54
	if gap_large < 20.0:
		gap_large = 20.0
	if gap_large > vh * 0.15:
		gap_large = vh * 0.15
	var s_height = (vh - 166.0 - 2.0 * gap_large) / 5.84
	var s_width = (vw - 40.0) / 5.5
	S = min(s_width, s_height)
	if S < 30.0:
		S = 30.0
	PIECE_R = S * 0.23
	PR = S * 0.12
	var board_size = S * 4.0
	var slot_h = PIECE_R * 2.0 + 4.0
	var tray_h = slot_h * TRAY_ROWS + 12.0
	var slot_w = PIECE_R * 2.0 + 8.0
	var tray_w = slot_w * TRAY_COLS + 16.0
	var tray_x = (vw - tray_w) / 2.0
	var total_h = (
		2.0 * margin
		+ 2.0 * counter_h
		+ 2.0 * gap_small
		+ 2.0 * gap_large
		+ 2.0 * tray_h
		+ board_size
	)
	var y_offset = (vh - total_h) / 2.0
	if y_offset < 0:
		y_offset = 0
	var y = y_offset + margin
	black_counter_rect = Rect2(
		vw / 2.0 - counter_w / 2.0,
		y,
		counter_w,
		counter_h
	)
	y += counter_h + gap_small
	black_tray_rect = Rect2(tray_x, y, tray_w, tray_h)
	y += tray_h + gap_large
	O = Vector2((vw - board_size) / 2.0, y)
	y += board_size + gap_large
	white_tray_rect = Rect2(tray_x, y, tray_w, tray_h)
	y += tray_h + gap_small
	white_counter_rect = Rect2(
		vw / 2.0 - counter_w / 2.0,
		y,
		counter_w,
		counter_h
	)

	var pw = min(vw - 60.0, 560.0)
	var ph = 480.0 if vs_computer else 420.0
	panel_rect = Rect2(
		(vw - pw) / 2.0,
		(vh - ph) / 2.0,
		pw,
		ph
	)
	var px = panel_rect.position.x
	var py = panel_rect.position.y
	var pad = 30.0
	var btn_gap = 20.0
	var full_w = pw - pad * 2.0

	resume_rect = Rect2(px + pad, py + 75, full_w, 50)
	newgame_rect = Rect2(px + pad, py + 132, full_w, 50)
	sound_rect = Rect2(px + pad, py + 189, full_w, 48)

	var mode_y = py + 285
	var side_w = (full_w - btn_gap) / 2.0
	mode_2p_rect = Rect2(px + pad, mode_y, side_w, 50)
	mode_ai_rect = Rect2(px + pad + side_w + btn_gap, mode_y, side_w, 50)

	var diff_y = py + 385
	var third_w = (full_w - btn_gap * 2.0) / 3.0
	diff_easy_rect = Rect2(px + pad, diff_y, third_w, 50)
	diff_med_rect = Rect2(px + pad + third_w + btn_gap, diff_y, third_w, 50)
	diff_hard_rect = Rect2(
		px + pad + (third_w + btn_gap) * 2,
		diff_y,
		third_w,
		50
	)

	var spw = min(vw * 0.7, 500.0)
	var sph = min(vh * 0.6, 340.0)
	side_panel_rect = Rect2(
		(vw - spw) / 2.0,
		(vh - sph) / 2.0,
		spw,
		sph
	)
	var side_btn_w = (spw - 80.0) / 2.0
	var side_btn_h = sph - 130.0
	side_black_rect = Rect2(
		side_panel_rect.position.x + 30.0,
		side_panel_rect.position.y + 90.0,
		side_btn_w,
		side_btn_h
	)
	side_white_rect = Rect2(
		side_panel_rect.position.x + 50.0 + side_btn_w,
		side_panel_rect.position.y + 90.0,
		side_btn_w,
		side_btn_h
	)

	var hw = min(vw - 40.0, 900.0)
	var hh = min(vh - 40.0, 900.0)
	help_panel_rect = Rect2(
		(vw - hw) / 2.0,
		(vh - hh) / 2.0,
		hw,
		hh
	)
	var hpx = help_panel_rect.position.x
	var hpy = help_panel_rect.position.y
	var hpw = help_panel_rect.size.x
	var hph = help_panel_rect.size.y

	var tab_gap_h = 14.0
	var tab_w_h = (hpw - 60.0 - tab_gap_h) / 2.0
	help_intro_tab_rect = Rect2(hpx + 30.0, hpy + 80.0, tab_w_h, 46.0)
	help_rules_tab_rect = Rect2(
		help_intro_tab_rect.end.x + tab_gap_h,
		hpy + 80.0,
		tab_w_h,
		46.0
	)

	var btn_gap_h = 16.0
	var btn_w_h = (hpw - 60.0 - btn_gap_h) / 2.0
	help_copy_rect = Rect2(hpx + 30.0, hpy + hph - 75.0, btn_w_h, 55.0)
	help_close_rect = Rect2(
		help_copy_rect.end.x + btn_gap_h,
		hpy + hph - 75.0,
		btn_w_h,
		55.0
	)

	_setup_store_layout()
	queue_redraw()

func _setup_store_layout():
	var vw = screen_size.x
	var vh = screen_size.y
	var shop_w = min(vw - 20.0, 620.0)
	var shop_h = min(vh - 16.0, 680.0)
	store_panel_rect = Rect2(
		(vw - shop_w) / 2.0,
		(vh - shop_h) / 2.0,
		shop_w,
		shop_h
	)
	store_close_rect = Rect2(
		store_panel_rect.end.x - 56.0,
		store_panel_rect.position.y + 14.0,
		40.0,
		36.0
	)
	var tab_gap = 10.0
	var tab_w = (shop_w - 44.0 - tab_gap) / 2.0
	store_piece_tab_rect = Rect2(
		store_panel_rect.position.x + 22.0,
		store_panel_rect.position.y + 98.0,
		tab_w,
		42.0
	)
	store_theme_tab_rect = Rect2(
		store_piece_tab_rect.end.x + tab_gap,
		store_panel_rect.position.y + 98.0,
		tab_w,
		42.0
	)
	skin_rects.clear()
	effect_rects.clear()
	theme_rects.clear()
	var pad = 22.0
	var gap = 10.0
	var item_w = (shop_w - pad * 2.0 - gap) / 2.0
	var skins_start_y = store_panel_rect.position.y + 182.0
	var skin_h = 52.0
	var skin_gap = 6.0
	for i in range(8):
		var row = i / 2
		var col = i % 2
		var rect = Rect2(
			store_panel_rect.position.x
				+ pad
				+ col * (item_w + gap),
			skins_start_y
				+ row * (skin_h + skin_gap),
			item_w,
			skin_h
		)
		skin_rects.append(rect)
	var effects_start_y = store_panel_rect.position.y + 452.0
	var effect_h = 48.0
	var effect_gap = 6.0
	for i in range(6):
		var row = i / 2
		var col = i % 2
		var rect = Rect2(
			store_panel_rect.position.x
				+ pad
				+ col * (item_w + gap),
			effects_start_y
				+ row * (effect_h + effect_gap),
			item_w,
			effect_h
		)
		effect_rects.append(rect)
	var themes_start_y = store_panel_rect.position.y + 182.0
	var theme_h = 64.0
	var theme_gap = 6.0
	for i in range(7):
		var row = i / 2
		var col = i % 2
		var rect = Rect2(
			store_panel_rect.position.x
				+ pad
				+ col * (item_w + gap),
			themes_start_y
				+ row * (theme_h + theme_gap),
			item_w,
			theme_h
		)
		theme_rects.append(rect)

func gp(r, c):
	return O + Vector2(c * S, r * S)

func _is_center(r, c):
	return r == 2 and c == 2

func _is_empty(r, c):
	return state[r][c] == 0 or state[r][c] == -1

func _find_cell(pos):
	for r in range(5):
		for c in range(5):
			if pos.distance_to(gp(r, c)) < S * 0.5:
				return Vector2(r, c)
	return Vector2(-1, -1)

func _input(event):
	if not (
		event is InputEventScreenTouch
		or event is InputEventMouseButton
	):
		return
	if event is InputEventMouseButton and not event.pressed:
		return
	if event is InputEventMouseButton \
	and event.button_index != MOUSE_BUTTON_LEFT:
		return
	if event is InputEventScreenTouch and not event.pressed:
		return
	var local_pos = to_local(event.position)

	if side_open:
		if not _check_debounce():
			get_viewport().set_input_as_handled()
			return
		if side_black_rect.has_point(local_pos):
			_play_sound("click")
			player_color = 1
			computer_color = 2
			side_open = false
			_reset_game()
			last_tap_ms = Time.get_ticks_msec()
			get_viewport().set_input_as_handled()
			return
		if side_white_rect.has_point(local_pos):
			_play_sound("click")
			player_color = 2
			computer_color = 1
			side_open = false
			_reset_game()
			last_tap_ms = Time.get_ticks_msec()
			get_viewport().set_input_as_handled()
			return
		get_viewport().set_input_as_handled()
		return

	if help_open:
		if not _check_debounce():
			get_viewport().set_input_as_handled()
			return
		if help_close_rect.has_point(local_pos):
			_play_sound("click")
			help_open = false
			get_viewport().set_input_as_handled()
			queue_redraw()
			return
		if help_copy_rect.has_point(local_pos):
			_play_sound("click")
			var txt = HELP_INTRO_TEXT if help_tab == 0 else HELP_RULES_TEXT
			txt += HELP_CREDIT_TEXT
			DisplayServer.clipboard_set(txt)
			copy_flash = 1.2
			get_viewport().set_input_as_handled()
			queue_redraw()
			return
		if help_intro_tab_rect.has_point(local_pos):
			_play_sound("click")
			help_tab = 0
			get_viewport().set_input_as_handled()
			queue_redraw()
			return
		if help_rules_tab_rect.has_point(local_pos):
			_play_sound("click")
			help_tab = 1
			get_viewport().set_input_as_handled()
			queue_redraw()
			return
		get_viewport().set_input_as_handled()
		return

	if store_open:
		if not _check_debounce():
			get_viewport().set_input_as_handled()
			return
		if store_close_rect.has_point(local_pos):
			_play_sound("click")
			store_open = false
			get_viewport().set_input_as_handled()
			queue_redraw()
			return
		if store_piece_tab_rect.has_point(local_pos):
			_play_sound("click")
			store_tab = 0
			get_viewport().set_input_as_handled()
			queue_redraw()
			return
		if store_theme_tab_rect.has_point(local_pos):
			_play_sound("click")
			store_tab = 1
			get_viewport().set_input_as_handled()
			queue_redraw()
			return
		if store_tab == 0:
			for i in range(skin_rects.size()):
				if skin_rects[i].has_point(local_pos):
					_buy_or_select_skin(i, 0)
					get_viewport().set_input_as_handled()
					return
			for i in range(effect_rects.size()):
				if effect_rects[i].has_point(local_pos):
					_buy_or_select_effect(i, 0)
					get_viewport().set_input_as_handled()
					return
		else:
			for i in range(theme_rects.size()):
				if theme_rects[i].has_point(local_pos):
					_buy_or_select_theme(i, 0)
					get_viewport().set_input_as_handled()
					return
		get_viewport().set_input_as_handled()
		return

	if menu_open:
		if not _check_debounce():
			get_viewport().set_input_as_handled()
			return
		if sound_rect.has_point(local_pos):
			sound_enabled = not sound_enabled
			if not sound_enabled:
				_stop_all_sounds()
			_save_game()
			get_viewport().set_input_as_handled()
			queue_redraw()
			return
		if resume_rect.has_point(local_pos):
			_play_sound("click")
			menu_open = false
			get_viewport().set_input_as_handled()
			queue_redraw()
			return
		if newgame_rect.has_point(local_pos):
			_play_sound("click")
			menu_open = false
			side_open = true
			_delete_save()
			last_tap_ms = Time.get_ticks_msec()
			get_viewport().set_input_as_handled()
			queue_redraw()
			return
		if mode_2p_rect.has_point(local_pos):
			_play_sound("click")
			vs_computer = false
			_center()
			_save_game()
			queue_redraw()
			get_viewport().set_input_as_handled()
			return
		if mode_ai_rect.has_point(local_pos):
			_play_sound("click")
			vs_computer = true
			_center()
			_save_game()
			queue_redraw()
			get_viewport().set_input_as_handled()
			return
		if vs_computer:
			if diff_easy_rect.has_point(local_pos):
				_play_sound("click")
				difficulty = 0
				_save_game()
				queue_redraw()
				get_viewport().set_input_as_handled()
				return
			if diff_med_rect.has_point(local_pos):
				_play_sound("click")
				difficulty = 1
				_save_game()
				queue_redraw()
				get_viewport().set_input_as_handled()
				return
			if diff_hard_rect.has_point(local_pos):
				_play_sound("click")
				difficulty = 2
				_save_game()
				queue_redraw()
				get_viewport().set_input_as_handled()
				return
		get_viewport().set_input_as_handled()
		return

	if store_rect.has_point(local_pos):
		_play_sound("click")
		store_open = true
		store_tab = 0
		get_viewport().set_input_as_handled()
		queue_redraw()
		return

	if help_rect.has_point(local_pos):
		_play_sound("click")
		help_open = true
		help_tab = 0
		get_viewport().set_input_as_handled()
		queue_redraw()
		return

	if menu_rect.has_point(local_pos):
		_play_sound("click")
		menu_open = true
		get_viewport().set_input_as_handled()
		queue_redraw()
		return

	if anim_active:
		get_viewport().set_input_as_handled()
		return

	if vs_computer and current == computer_color:
		return

	if _check_debounce():
		_handle_tap(local_pos)

	get_viewport().set_input_as_handled()

func _check_debounce():
	var now = Time.get_ticks_msec()
	if now - last_tap_ms < 250:
		return false
	last_tap_ms = now
	return true

func _handle_tap(pos):
	if phase == "gameover":
		return
	if anim_active:
		return
	var cell = _find_cell(pos)
	if cell.x < 0:
		return
	var r = int(cell.x)
	var c = int(cell.y)
	if phase == "place":
		_handle_place(r, c)
	elif phase == "move":
		_handle_move(r, c)
	elif phase == "choose_capture":
		_handle_choose_capture(r, c)

func _handle_place(r, c):
	if _is_center(r, c):
		return
	if not _is_empty(r, c):
		return
	if first == 0:
		first = current
	state[r][c] = current
	if current == 1:
		black_count += 1
	else:
		white_count += 1
	placed += 1
	current = 3 - current
	turn_time = TURN_LIMIT
	_play_sound("place")
	if placed >= 24:
		phase = "move"
		current = 3 - first
		turn_time = TURN_LIMIT
		_update_text()
		_begin_turn()
	else:
		_update_text()
		_save_game()
	queue_redraw()

func _update_text():
	if phase == "gameover":
		return
	if phase == "place":
		if current == 1:
			debug_text = "BLACK - PLACE"
		else:
			debug_text = "WHITE - PLACE"
	elif phase == "choose_capture":
		debug_text = "CHOOSE CAPTURE"
	else:
		if current == 1:
			debug_text = "BLACK TURN"
		else:
			debug_text = "WHITE TURN"

func _begin_turn():
	if phase != "move":
		return
	selected = Vector2(-1, -1)
	valid_moves.clear()
	capture_options.clear()
	turn_time = TURN_LIMIT
	if _player_has_moves(current):
		_update_text()
		queue_redraw()
		return
	current = 3 - current
	turn_time = TURN_LIMIT
	if _player_has_moves(current):
		queue_redraw()
		await get_tree().create_timer(0.9).timeout
		if phase == "move":
			_update_text()
			queue_redraw()
	else:
		debug_text = "NO MORE MOVES"
		phase = "gameover"
		_play_sound("win")
		_earn_coins(50)
		_delete_save()
		queue_redraw()

func _player_has_moves(player):
	for r in range(5):
		for c in range(5):
			if state[r][c] == player:
				var moves = _get_moves(r, c)
				if moves.size() > 0:
					return true
	return false

func _handle_move(r, c):
	if state[r][c] == current:
		selected = Vector2(r, c)
		valid_moves = _get_moves(r, c)
		queue_redraw()
		return
	if selected.x >= 0 and Vector2(r, c) in valid_moves:
		var sr = int(selected.x)
		var sc = int(selected.y)
		_start_animation(sr, sc, r, c, false)
		return
	selected = Vector2(-1, -1)
	valid_moves.clear()
	_update_text()
	queue_redraw()

func _after_move(r, c):
	var caps = _check_sandwiches(r, c)
	if caps.size() == 0:
		current = 3 - current
		turn_time = TURN_LIMIT
		_begin_turn()
	elif caps.size() == 1:
		var cap = caps[0]
		_remove_piece(int(cap.x), int(cap.y))
		if phase != "gameover":
			turn_time = TURN_LIMIT
			_begin_turn()
	elif caps.size() > 1:
		capture_options = caps
		phase = "choose_capture"
		debug_text = "CHOOSE CAPTURE"
		_save_game()
		queue_redraw()

func _handle_choose_capture(r, c):
	var v = Vector2(r, c)
	if v in capture_options:
		_remove_piece(r, c)
		capture_options.clear()
		if phase != "gameover":
			phase = "move"
			turn_time = TURN_LIMIT
			_begin_turn()
		_save_game()
		queue_redraw()

func _remove_piece(r, c):
	if state[r][c] == 1:
		black_count -= 1
	elif state[r][c] == 2:
		white_count -= 1
	if _is_center(r, c):
		state[r][c] = -1
	else:
		state[r][c] = 0
	_play_sound("capture")
	if black_count <= 1:
		black_count = max(black_count, 0)
		white_count = max(white_count, 0)
		debug_text = "WHITE WINS!"
		phase = "gameover"
		_play_sound("win")
		_earn_coins(50)
		_delete_save()
	elif white_count <= 1:
		black_count = max(black_count, 0)
		white_count = max(white_count, 0)
		debug_text = "BLACK WINS!"
		phase = "gameover"
		_play_sound("win")
		_earn_coins(50)
		_delete_save()

func _is_corner(r, c):
	return (
		(r == 0 or r == 4)
		and
		(c == 0 or c == 4)
	)

func _check_sandwiches(r, c):
	var caps = []
	var opponent = 3 - current
	for d in _dirs(r, c):
		var r1 = r + int(d.x)
		var c1 = c + int(d.y)
		var r2 = r + int(d.x) * 2
		var c2 = c + int(d.y) * 2
		if r1 < 0 or r1 > 4:
			continue
		if c1 < 0 or c1 > 4:
			continue
		if r2 < 0 or r2 > 4:
			continue
		if c2 < 0 or c2 > 4:
			continue
		if state[r1][c1] != opponent:
			continue
		if state[r2][c2] != current:
			continue
		if _is_corner(r1, c1):
			continue
		var already_found = false
		for cap in caps:
			if cap == Vector2(r1, c1):
				already_found = true
				break
		if not already_found:
			caps.append(Vector2(r1, c1))
	return caps

func _dirs(r, c):
	var dirs = [
		Vector2(-1, 0),
		Vector2(1, 0),
		Vector2(0, -1),
		Vector2(0, 1)
	]
	if (r + c) % 2 == 0:
		dirs.append(Vector2(-1, -1))
		dirs.append(Vector2(-1, 1))
		dirs.append(Vector2(1, -1))
		dirs.append(Vector2(1, 1))
	return dirs

func _get_moves(r, c):
	var moves = []
	for d in _dirs(r, c):
		var nr = r + int(d.x)
		var nc = c + int(d.y)
		if nr < 0 or nr > 4:
			continue
		if nc < 0 or nc > 4:
			continue
		if _is_empty(nr, nc):
			moves.append(Vector2(nr, nc))
	return moves

func _reset_game():
	state = [
		[0, 0, 0, 0, 0],
		[0, 0, 0, 0, 0],
		[0, 0, -1, 0, 0],
		[0, 0, 0, 0, 0],
		[0, 0, 0, 0, 0]
	]
	current = 1
	placed = 0
	first = 0
	phase = "place"
	debug_text = "BLACK - PLACE"
	selected = Vector2(-1, -1)
	valid_moves.clear()
	capture_options.clear()
	black_count = 0
	white_count = 0
	menu_open = false
	store_open = false
	help_open = false
	help_tab = 0
	turn_time = TURN_LIMIT
	ai_delay = 1.0
	anim_active = false
	anim_progress = 0.0
	_center()
	queue_redraw()

# =========================================================
# UI HELPERS
# =========================================================

func _make_box(
	bg_color: Color,
	border_color: Color,
	radius: int,
	border_width: int
) -> StyleBoxFlat:
	var box = StyleBoxFlat.new()
	box.bg_color = bg_color
	box.border_color = border_color
	box.set_border_width_all(border_width)
	box.corner_radius_top_left = radius
	box.corner_radius_top_right = radius
	box.corner_radius_bottom_left = radius
	box.corner_radius_bottom_right = radius
	return box

func _draw_shadow_rect(
	rect: Rect2,
	radius: float = 12.0,
	alpha: float = 0.35,
	offset: Vector2 = Vector2(5, 7)
):
	var shadow_rect = Rect2(
		rect.position + offset,
		rect.size
	)
	draw_style_box(
		_make_box(
			Color(0, 0, 0, alpha),
			Color(0, 0, 0, 0),
			int(radius),
			0
		),
		shadow_rect
	)

func _draw_timer_border(
	rect: Rect2,
	remaining: float,
	color: Color
):
	var w = rect.size.x
	var h = rect.size.y
	var total_perim = 2.0 * (w + h)
	var draw_len = total_perim * remaining
	var x = rect.position.x
	var y = rect.position.y
	var lw = 5.0
	var rem = draw_len
	if rem > 0:
		var seg = min(rem, w)
		draw_line(
			Vector2(x, y),
			Vector2(x + seg, y),
			color,
			lw,
			true
		)
		rem -= seg
	if rem > 0:
		var seg = min(rem, h)
		draw_line(
			Vector2(x + w, y),
			Vector2(x + w, y + seg),
			color,
			lw,
			true
		)
		rem -= seg
	if rem > 0:
		var seg = min(rem, w)
		draw_line(
			Vector2(x + w, y + h),
			Vector2(x + w - seg, y + h),
			color,
			lw,
			true
		)
		rem -= seg
	if rem > 0:
		var seg = min(rem, h)
		draw_line(
			Vector2(x, y + h),
			Vector2(x, y + h - seg),
			color,
			lw,
			true
		)

func _draw_centered_text(
	text: String,
	rect: Rect2,
	size: int,
	color: Color
):
	var tw = ThemeDB.fallback_font.get_string_size(
		text,
		HORIZONTAL_ALIGNMENT_LEFT,
		-1,
		size
	).x
	var tx = rect.position.x + (rect.size.x - tw) / 2.0
	var ty = rect.position.y + rect.size.y / 2.0 + size * 0.35
	draw_string(
		ThemeDB.fallback_font,
		Vector2(tx, ty),
		text,
		HORIZONTAL_ALIGNMENT_LEFT,
		-1,
		size,
		color
	)

func _draw_glow_circle(
	pos: Vector2,
	radius: float,
	color: Color
):
	var c1 = Color(
		color.r,
		color.g,
		color.b,
		color.a * 0.08
	)
	var c2 = Color(
		color.r,
		color.g,
		color.b,
		color.a * 0.15
	)
	var c3 = Color(
		color.r,
		color.g,
		color.b,
		color.a * 0.28
	)
	draw_circle(pos, radius * 1.8, c1)
	draw_circle(pos, radius * 1.45, c2)
	draw_circle(pos, radius * 1.18, c3)
	draw_circle(pos, radius, color)

# =========================================================
# ICONS
# =========================================================

func _draw_icon_menu(rect: Rect2, color: Color):
	var cx = rect.position.x + rect.size.x / 2.0
	var cy = rect.position.y + rect.size.y / 2.0
	var w = rect.size.x * 0.42
	var h = 3.5
	var gap = 8.0
	for i in range(3):
		var y = cy + (i - 1) * gap
		draw_line(
			Vector2(cx - w / 2, y),
			Vector2(cx + w / 2, y),
			color,
			h
		)

func _draw_icon_store(rect: Rect2, color: Color):
	var cx = rect.position.x + rect.size.x / 2.0
	var cy = rect.position.y + rect.size.y / 2.0
	var s = rect.size.y * 0.32
	draw_line(
		Vector2(cx - s * 1.15, cy - s * 0.75),
		Vector2(cx - s * 0.75, cy - s * 0.75),
		color,
		2.5
	)
	draw_line(
		Vector2(cx - s * 0.75, cy - s * 0.75),
		Vector2(cx - s * 0.55, cy - s * 0.35),
		color,
		2.5
	)
	var pts = PackedVector2Array([
		Vector2(cx - s * 0.55, cy - s * 0.45),
		Vector2(cx + s * 0.95, cy - s * 0.45),
		Vector2(cx + s * 0.75, cy + s * 0.35),
		Vector2(cx - s * 0.35, cy + s * 0.35),
		Vector2(cx - s * 0.55, cy - s * 0.45)
	])
	draw_polyline(pts, color, 2.5, true)
	draw_circle(
		Vector2(cx - s * 0.15, cy + s * 0.72),
		s * 0.14,
		color
	)
	draw_circle(
		Vector2(cx + s * 0.6, cy + s * 0.72),
		s * 0.14,
		color
	)

func _draw_icon_rules(rect: Rect2, color: Color):
	var cx = rect.position.x + rect.size.x / 2.0
	var cy = rect.position.y + rect.size.y / 2.0
	var w = rect.size.x * 0.48
	var h = rect.size.y * 0.52
	var left = Rect2(cx - w / 2.0, cy - h / 2.0, w / 2.0 - 1.0, h)
	var right = Rect2(cx + 1.0, cy - h / 2.0, w / 2.0 - 1.0, h)
	draw_rect(left, color, false, 2.0)
	draw_rect(right, color, false, 2.0)
	draw_line(
		Vector2(cx, cy - h / 2.0),
		Vector2(cx, cy + h / 2.0),
		color,
		2.0
	)

func _draw_icon_sound_on(rect: Rect2, color: Color):
	var cx = rect.position.x + rect.size.x / 2.0
	var cy = rect.position.y + rect.size.y / 2.0
	var s = rect.size.y * 0.4
	draw_rect(
		Rect2(
			cx - s * 0.9,
			cy - s * 0.30,
			s * 0.35,
			s * 0.6
		),
		color
	)
	var pts = PackedVector2Array([
		Vector2(cx - s * 0.55, cy - s * 0.30),
		Vector2(cx - s * 0.55, cy + s * 0.30),
		Vector2(cx - s * 0.10, cy + s * 0.70),
		Vector2(cx - s * 0.10, cy - s * 0.70)
	])
	draw_colored_polygon(pts, color)
	draw_arc(
		Vector2(cx + s * 0.10, cy),
		s * 0.35,
		-PI / 3.0,
		PI / 3.0,
		12,
		color,
		2.0
	)
	draw_arc(
		Vector2(cx + s * 0.10, cy),
		s * 0.60,
		-PI / 3.0,
		PI / 3.0,
		16,
		color,
		2.0
	)

func _draw_icon_sound_off(rect: Rect2, color: Color):
	var cx = rect.position.x + rect.size.x / 2.0
	var cy = rect.position.y + rect.size.y / 2.0
	var s = rect.size.y * 0.4
	draw_rect(
		Rect2(
			cx - s * 0.9,
			cy - s * 0.30,
			s * 0.35,
			s * 0.6
		),
		color
	)
	var pts = PackedVector2Array([
		Vector2(cx - s * 0.55, cy - s * 0.30),
		Vector2(cx - s * 0.55, cy + s * 0.30),
		Vector2(cx - s * 0.10, cy + s * 0.70),
		Vector2(cx - s * 0.10, cy - s * 0.70)
	])
	draw_colored_polygon(pts, color)
	var xx = cx + s * 0.55
	var xy = cy
	var xs = s * 0.3
	draw_line(
		Vector2(xx - xs, xy - xs),
		Vector2(xx + xs, xy + xs),
		Color("#D9544D"),
		3.0
	)
	draw_line(
		Vector2(xx - xs, xy + xs),
		Vector2(xx + xs, xy - xs),
		Color("#D9544D"),
		3.0
	)

func _draw_icon_play(rect: Rect2, color: Color):
	var cx = rect.position.x + rect.size.x / 2.0
	var cy = rect.position.y + rect.size.y / 2.0
	var s = rect.size.y * 0.32
	var pts = PackedVector2Array([
		Vector2(cx - s * 0.6, cy - s),
		Vector2(cx - s * 0.6, cy + s),
		Vector2(cx + s * 0.9, cy)
	])
	draw_colored_polygon(pts, color)

func _draw_icon_refresh(rect: Rect2, color: Color):
	var cx = rect.position.x + rect.size.x / 2.0
	var cy = rect.position.y + rect.size.y / 2.0
	var r = rect.size.y * 0.3
	draw_arc(
		Vector2(cx, cy),
		r,
		-PI * 0.35,
		PI * 1.15,
		32,
		color,
		2.5
	)
	var ang = PI * 1.15
	var tip = Vector2(cx + r * cos(ang), cy + r * sin(ang))
	var t1 = tip + Vector2(-3, -7)
	var t2 = tip + Vector2(5, -3)
	draw_line(tip, t1, color, 2.5)
	draw_line(tip, t2, color, 2.5)

func _draw_icon_2players(rect: Rect2, color: Color):
	var cx = rect.position.x + rect.size.x / 2.0
	var cy = rect.position.y + rect.size.y / 2.0
	var s = rect.size.y * 0.32
	draw_circle(Vector2(cx - s * 0.75, cy - s * 0.35), s * 0.28, color)
	draw_arc(
		Vector2(cx - s * 0.75, cy + s * 0.45),
		s * 0.55,
		PI,
		TAU,
		16,
		color,
		2.5
	)
	draw_circle(Vector2(cx + s * 0.75, cy - s * 0.35), s * 0.28, color)
	draw_arc(
		Vector2(cx + s * 0.75, cy + s * 0.45),
		s * 0.55,
		PI,
		TAU,
		16,
		color,
		2.5
	)

func _draw_icon_ai(rect: Rect2, color: Color):
	var cx = rect.position.x + rect.size.x / 2.0
	var cy = rect.position.y + rect.size.y / 2.0
	var s = rect.size.y * 0.32
	var head = Rect2(
		cx - s * 0.85,
		cy - s * 0.5,
		s * 1.7,
		s * 1.0
	)
	draw_rect(head, color, false, 2.5)
	draw_circle(Vector2(cx - s * 0.35, cy), s * 0.13, color)
	draw_circle(Vector2(cx + s * 0.35, cy), s * 0.13, color)
	draw_line(
		Vector2(cx, cy - s * 0.5),
		Vector2(cx, cy - s * 0.95),
		color,
		2.0
	)
	draw_circle(Vector2(cx, cy - s * 0.95), s * 0.10, color)

func _draw_icon_close(rect: Rect2, color: Color):
	var cx = rect.position.x + rect.size.x / 2.0
	var cy = rect.position.y + rect.size.y / 2.0
	var s = rect.size.y * 0.26
	draw_line(
		Vector2(cx - s, cy - s),
		Vector2(cx + s, cy + s),
		color,
		3.0
	)
	draw_line(
		Vector2(cx - s, cy + s),
		Vector2(cx + s, cy - s),
		color,
		3.0
	)

func _draw_star(center: Vector2, size: float, color: Color):
	var pts = PackedVector2Array()
	var points = 5
	for i in range(points * 2):
		var ang = -PI / 2.0 + i * PI / float(points)
		var r = size if i % 2 == 0 else size * 0.4
		pts.append(
			center + Vector2(cos(ang), sin(ang)) * r
		)
	draw_colored_polygon(pts, color)

func _draw_icon_difficulty(
	rect: Rect2,
	level: int,
	color: Color
):
	var cx = rect.position.x + rect.size.x / 2.0
	var cy = rect.position.y + rect.size.y / 2.0
	var s = rect.size.y * 0.22
	var gap = s * 2.6
	var total_w = (level - 1) * gap
	var start_x = cx - total_w / 2.0
	for i in range(level):
		_draw_star(
			Vector2(start_x + i * gap, cy),
			s,
			color
		)

# =========================================================
# THEME COLORS
# =========================================================

func _theme_background():
	var colors = [
		Color("#080A0D"),
		Color("#05070D"),
		Color("#07100C"),
		Color("#100607"),
		Color("#071018"),
		Color("#050505"),
		Color("#0E0E0E")
	]
	return colors[game_theme]

func _theme_top():
	var colors = [
		Color("#10151A"),
		Color("#0B1020"),
		Color("#0C1812"),
		Color("#1A0A0C"),
		Color("#0A1822"),
		Color("#080808"),
		Color("#181818")
	]
	return colors[game_theme]

func _theme_bottom():
	var colors = [
		Color("#0B0D10"),
		Color("#070A12"),
		Color("#07100B"),
		Color("#120708"),
		Color("#07121A"),
		Color("#050505"),
		Color("#111111")
	]
	return colors[game_theme]

func _theme_board_outer():
	var colors = [
		Color("#3A2416"),
		Color("#161B2C"),
		Color("#173326"),
		Color("#35171A"),
		Color("#163044"),
		Color("#191919"),
		Color("#34302A")
	]
	return colors[game_theme]

func _theme_board_surface():
	var colors = [
		Color("#6B4325"),
		Color("#27304A"),
		Color("#28513D"),
		Color("#5A292E"),
		Color("#25465A"),
		Color("#2B2B2B"),
		Color("#686157")
	]
	return colors[game_theme]

func _theme_accent():
	var colors = [
		Color("#E0B45A"),
		Color("#6EA8E6"),
		Color("#5FC68B"),
		Color("#E06467"),
		Color("#73CFE8"),
		Color("#D6AA55"),
		Color("#E2D0A6")
	]
	return colors[game_theme]

func _theme_secondary():
	var colors = [
		Color("#B98243"),
		Color("#435E8C"),
		Color("#428A63"),
		Color("#9D454D"),
		Color("#4C8BA4"),
		Color("#866B43"),
		Color("#A89D8A")
	]
	return colors[game_theme]

func _draw_piece_at(pos: Vector2, piece_color: int):
	var skin = piece_skin
	if piece_effect == 1:
		_draw_glow_circle(
			pos,
			PIECE_R + 7,
			Color(0.95, 0.70, 0.20, 0.30)
		)
	elif piece_effect == 2:
		_draw_glow_circle(
			pos,
			PIECE_R + 7,
			Color(0.25, 0.90, 0.55, 0.28)
		)
	elif piece_effect == 3:
		_draw_glow_circle(
			pos,
			PIECE_R + 7,
			Color(0.95, 0.20, 0.25, 0.28)
		)
	elif piece_effect == 4:
		_draw_glow_circle(
			pos,
			PIECE_R + 7,
			Color(0.25, 0.80, 1.0, 0.28)
		)
	elif piece_effect == 5:
		_draw_glow_circle(
			pos,
			PIECE_R + 10,
			Color(1.0, 0.72, 0.25, 0.24)
		)

	if piece_color == 1:
		draw_circle(
			pos + Vector2(4, 6),
			PIECE_R + 1,
			Color(0, 0, 0, 0.48)
		)
		var main = Color("#090909")
		var inner = Color("#1D1D1F")
		var border = Color("#050505")
		if skin == 1:
			main = Color("#171008")
			inner = Color("#674618")
			border = Color("#E0B451")
		elif skin == 2:
			main = Color("#190708")
			inner = Color("#702027")
			border = Color("#E35460")
		elif skin == 3:
			main = Color("#071018")
			inner = Color("#1E5068")
			border = Color("#66C7E7")
		elif skin == 4:
			main = Color("#07130D")
			inner = Color("#1D6543")
			border = Color("#62D69B")
		elif skin == 5:
			main = Color("#11091A")
			inner = Color("#57246E")
			border = Color("#C875E4")
		elif skin == 6:
			main = Color("#020202")
			inner = Color("#111111")
			border = Color("#777777")
		elif skin == 7:
			main = Color("#24211B")
			inner = Color("#AAA08D")
			border = Color("#F1E7C8")
		draw_circle(pos, PIECE_R, main)
		draw_circle(
			pos - Vector2(0, 1),
			PIECE_R - 3,
			inner
		)
		draw_circle(pos, PIECE_R, border, false, 3)
		draw_circle(
			pos - Vector2(
				PIECE_R * 0.32,
				PIECE_R * 0.34
			),
			PIECE_R * 0.12,
			Color(1, 1, 1, 0.30)
		)
		draw_circle(
			pos - Vector2(
				PIECE_R * 0.22,
				PIECE_R * 0.23
			),
			PIECE_R * 0.055,
			Color(1, 1, 1, 0.16)
		)
	elif piece_color == 2:
		draw_circle(
			pos + Vector2(4, 6),
			PIECE_R + 1,
			Color(0, 0, 0, 0.45)
		)
		var wmain = Color("#F4F1EA")
		var winner = Color("#DAD8D3")
		var wborder = Color("#756F68")
		if skin == 1:
			wmain = Color("#FFF1C4")
			winner = Color("#D6A947")
			wborder = Color("#F0C85A")
		elif skin == 2:
			wmain = Color("#FFE0E3")
			winner = Color("#D96B72")
			wborder = Color("#A9343D")
		elif skin == 3:
			wmain = Color("#E8FAFF")
			winner = Color("#8FD0E2")
			wborder = Color("#4D9BB4")
		elif skin == 4:
			wmain = Color("#E3FFE9")
			winner = Color("#83C99B")
			wborder = Color("#3E9C64")
		elif skin == 5:
			wmain = Color("#F4E5FF")
			winner = Color("#C18BD7")
			wborder = Color("#8C4AA5")
		elif skin == 6:
			wmain = Color("#DADADA")
			winner = Color("#707070")
			wborder = Color("#2A2A2A")
		elif skin == 7:
			wmain = Color("#FFFDF2")
			winner = Color("#E9DDBB")
			wborder = Color("#B8A97C")
		draw_circle(pos, PIECE_R, wmain)
		draw_circle(
			pos - Vector2(0, 1),
			PIECE_R - 3,
			winner
		)
		draw_circle(pos, PIECE_R, wborder, false, 2.5)
		draw_circle(
			pos - Vector2(
				PIECE_R * 0.32,
				PIECE_R * 0.34
			),
			PIECE_R * 0.12,
			Color(1, 1, 1, 0.92)
		)
		draw_circle(
			pos - Vector2(
				PIECE_R * 0.20,
				PIECE_R * 0.22
			),
			PIECE_R * 0.05,
			Color(1, 1, 1, 0.96)
		)

func _draw_board_background():
	var board_size = S * 4.0
	var outer = Rect2(
		O - Vector2(20, 20),
		Vector2(board_size + 40, board_size + 40)
	)
	var shadow = Rect2(
		outer.position + Vector2(7, 9),
		outer.size
	)
	draw_style_box(
		_make_box(
			Color(0, 0, 0, 0.42),
			Color(0, 0, 0, 0),
			24,
			0
		),
		shadow
	)
	draw_style_box(
		_make_box(
			_theme_board_outer(),
			_theme_accent(),
			22,
			3
		),
		outer
	)
	var inner = Rect2(
		O - Vector2(11, 11),
		Vector2(board_size + 22, board_size + 22)
	)
	draw_style_box(
		_make_box(
			_theme_board_surface(),
			_theme_accent(),
			4,
			2
		),
		inner
	)
	var surface = Rect2(
		O - Vector2(5, 5),
		Vector2(board_size + 10, board_size + 10)
	)
	draw_style_box(
		_make_box(
			_theme_board_surface(),
			Color("#2D1A0E"),
			4,
			2
		),
		surface
	)
	for i in range(12):
		var yy = surface.position.y + 10.0 + i * (
			surface.size.y - 20.0
		) / 12.0
		draw_line(
			Vector2(surface.position.x + 5, yy),
			Vector2(surface.end.x - 5, yy),
			Color(1, 0.8, 0.55, 0.035),
			2.0,
			true
		)
	draw_line(
		Vector2(
			surface.position.x + 7,
			surface.position.y + 7
		),
		Vector2(
			surface.end.x - 7,
			surface.position.y + 7
		),
		Color(1, 0.82, 0.55, 0.16),
		2.0,
		true
	)
	draw_line(
		Vector2(
			surface.position.x + 7,
			surface.end.y - 7
		),
		Vector2(
			surface.end.x - 7,
			surface.end.y - 7
		),
		Color(0, 0, 0, 0.28),
		2.0,
		true
	)

func _draw_tray(
	rect: Rect2,
	count: int,
	is_black: bool
):
	_draw_shadow_rect(
		rect,
		14.0,
		0.42,
		Vector2(4, 6)
	)
	draw_style_box(
		_make_box(
			Color("#241A14"),
			_theme_secondary(),
			14,
			2
		),
		rect
	)
	var inner_rect = Rect2(
		rect.position + Vector2(6, 6),
		rect.size - Vector2(12, 12)
	)
	draw_style_box(
		_make_box(
			Color("#34251B"),
			Color("#60452E"),
			10,
			1
		),
		inner_rect
	)
	var pad = 8.0
	var inner_w = rect.size.x - pad * 2.0
	var inner_h = rect.size.y - pad * 2.0
	var slot_w = inner_w / TRAY_COLS
	var slot_h = inner_h / TRAY_ROWS
	var num_color = Color("#BCA98E")
	for i in range(TOTAL_PIECES):
		var row = i / TRAY_COLS
		var col = i % TRAY_COLS
		var cx = rect.position.x + pad + slot_w * (col + 0.5)
		var cy = rect.position.y + pad + slot_h * (row + 0.5)
		var pos = Vector2(cx, cy)
		draw_circle(
			pos,
			PIECE_R + 2,
			Color(0, 0, 0, 0.20)
		)
		if i < count:
			_draw_piece_at(
				pos,
				1 if is_black else 2
			)
		else:
			draw_circle(
				pos,
				PIECE_R,
				Color("#46362A")
			)
			draw_circle(
				pos,
				PIECE_R,
				Color("#735538"),
				false,
				2
			)
			var num_text = str(i + 1)
			var num_size = int(PIECE_R * 0.82)
			var tw = ThemeDB.fallback_font.get_string_size(
				num_text,
				HORIZONTAL_ALIGNMENT_LEFT,
				-1,
				num_size
			).x
			draw_string(
				ThemeDB.fallback_font,
				Vector2(
					pos.x - tw / 2.0,
					pos.y + num_size * 0.35
				),
				num_text,
				HORIZONTAL_ALIGNMENT_LEFT,
				-1,
				num_size,
				num_color
			)

func _draw_counter(
	rect: Rect2,
	piece_color: int,
	label: String,
	count: int
):
	_draw_shadow_rect(
		rect,
		12.0,
		0.35,
		Vector2(3, 5)
	)
	draw_style_box(
		_make_box(
			Color("#201811"),
			_theme_secondary(),
			12,
			1
		),
		rect
	)
	var cy = rect.position.y + rect.size.y / 2.0
	_draw_piece_at(
		Vector2(
			rect.position.x + 29,
			cy
		),
		piece_color
	)
	draw_string(
		ThemeDB.fallback_font,
		Vector2(
			rect.position.x + 60,
			cy + 9
		),
		label + "  " + str(count),
		HORIZONTAL_ALIGNMENT_LEFT,
		-1,
		23,
		Color("#E9DED0")
	)

func _draw_side_chooser():
	draw_rect(
		Rect2(
			0,
			0,
			screen_size.x,
			screen_size.y
		),
		_theme_background()
	)
	draw_circle(
		Vector2(
			screen_size.x / 2.0,
			screen_size.y / 2.0
		),
		screen_size.y * 0.42,
		Color(0.35, 0.22, 0.10, 0.10)
	)
	_draw_shadow_rect(
		side_panel_rect,
		24.0,
		0.60,
		Vector2(7, 10)
	)
	draw_style_box(
		_make_box(
			Color("#17120E"),
			_theme_accent(),
			24,
			2
		),
		side_panel_rect
	)
	var panel_inner = Rect2(
		side_panel_rect.position + Vector2(5, 5),
		side_panel_rect.size - Vector2(10, 10)
	)
	draw_style_box(
		_make_box(
			Color("#211912"),
			Color("#60452D"),
			20,
			1
		),
		panel_inner
	)
	var pw = side_panel_rect.size.x
	var px = side_panel_rect.position.x
	var py = side_panel_rect.position.y
	_draw_centered_text(
		"CHOOSE YOUR SIDE",
		Rect2(px, py + 15, pw, 45),
		30,
		_theme_accent()
	)
	_draw_centered_text(
		"SELECT YOUR COLOR",
		Rect2(px, py + 53, pw, 25),
		13,
		Color("#9E8B76")
	)
	var bbr = _theme_accent() if player_color == 1 \
		else Color("#57483A")
	var bbw = 3 if player_color == 1 else 1
	_draw_shadow_rect(
		side_black_rect,
		16.0,
		0.35,
		Vector2(3, 5)
	)
	draw_style_box(
		_make_box(
			Color("#0C0C0D"),
			bbr,
			16,
			bbw
		),
		side_black_rect
	)
	var bcx = side_black_rect.position.x \
		+ side_black_rect.size.x / 2.0
	var bcy = side_black_rect.position.y \
		+ side_black_rect.size.y / 2.0 - 20
	_draw_piece_at(
		Vector2(bcx, bcy),
		1
	)
	draw_string(
		ThemeDB.fallback_font,
		Vector2(
			bcx - 40,
			side_black_rect.position.y
				+ side_black_rect.size.y - 20
		),
		"BLACK",
		HORIZONTAL_ALIGNMENT_LEFT,
		-1,
		24,
		Color("#F5E9D5")
	)
	var wbr = _theme_accent() if player_color == 2 \
		else Color("#57483A")
	var wbw = 3 if player_color == 2 else 1
	_draw_shadow_rect(
		side_white_rect,
		16.0,
		0.35,
		Vector2(3, 5)
	)
	draw_style_box(
		_make_box(
			Color("#E5E0D7"),
			wbr,
			16,
			wbw
		),
		side_white_rect
	)
	var wcx = side_white_rect.position.x \
		+ side_white_rect.size.x / 2.0
	var wcy = side_white_rect.position.y \
		+ side_white_rect.size.y / 2.0 - 20
	_draw_piece_at(
		Vector2(wcx, wcy),
		2
	)
	draw_string(
		ThemeDB.fallback_font,
		Vector2(
			wcx - 40,
			side_white_rect.position.y
				+ side_white_rect.size.y - 20
		),
		"WHITE",
		HORIZONTAL_ALIGNMENT_LEFT,
		-1,
		24,
		Color("#27221D")
	)

func _skin_name(id):
	var names = [
		"CLASSIC",
		"GOLD",
		"RUBY",
		"SAPPHIRE",
		"EMERALD",
		"AMETHYST",
		"OBSIDIAN",
		"PEARL"
	]
	return names[id]

func _effect_name(id):
	var names = [
		"NONE",
		"GOLD GLOW",
		"EMERALD GLOW",
		"RUBY GLOW",
		"ICE GLOW",
		"ROYAL SHINE"
	]
	return names[id]

func _theme_name(id):
	var names = [
		"ROYAL GOLD",
		"MIDNIGHT",
		"EMERALD PALACE",
		"RUBY LUXURY",
		"ICE CRYSTAL",
		"OBSIDIAN ELITE",
		"PEARL WHITE"
	]
	return names[id]

func _draw_store_item(
	rect: Rect2,
	label: String,
	price: int,
	owned: bool,
	selected_item: bool
):
	var bg = Color("#2B241D")
	var border = Color("#5E4B38")
	if selected_item:
		bg = Color("#49391F")
		border = _theme_accent()
	elif owned:
		bg = Color("#24372B")
		border = Color("#58A974")
	draw_style_box(
		_make_box(
			bg,
			border,
			11,
			2 if selected_item else 1
		),
		rect
	)
	if selected_item:
		_draw_centered_text(
			"✓",
			Rect2(
				rect.position.x + 2,
				rect.position.y + 2,
				25,
				25
			),
			16,
			_theme_accent()
		)
	draw_string(
		ThemeDB.fallback_font,
		Vector2(
			rect.position.x + 14,
			rect.position.y + 25
		),
		label,
		HORIZONTAL_ALIGNMENT_LEFT,
		-1,
		14,
		Color("#F0E4D1")
	)
	var status = ""
	if selected_item:
		status = "EQUIPPED"
	elif owned:
		status = "FREE"
	else:
		status = "FREE"
	draw_string(
		ThemeDB.fallback_font,
		Vector2(
			rect.position.x + 14,
			rect.position.y + rect.size.y - 9
		),
		status,
		HORIZONTAL_ALIGNMENT_LEFT,
		-1,
		11,
		Color("#73C78F")
	)

func _draw_store_skin_preview(
	rect: Rect2,
	id: int
):
	var old_skin = piece_skin
	piece_skin = id
	_draw_piece_at(
		Vector2(
			rect.position.x + rect.size.x - 34,
			rect.position.y + rect.size.y / 2.0
		),
		1
	)
	piece_skin = old_skin

func _draw_store_effect_preview(
	rect: Rect2,
	id: int
):
	var old_effect = piece_effect
	piece_effect = id
	_draw_piece_at(
		Vector2(
			rect.position.x + rect.size.x - 34,
			rect.position.y + rect.size.y / 2.0
		),
		1
	)
	piece_effect = old_effect

func _draw_store_theme_preview(
	rect: Rect2,
	id: int
):
	var old_theme = game_theme
	game_theme = id
	var preview_rect = Rect2(
		rect.position.x + rect.size.x - 62,
		rect.position.y + 10,
		48,
		rect.size.y - 20
	)
	draw_style_box(
		_make_box(
			_theme_board_surface(),
			_theme_accent(),
			8,
			2
		),
		preview_rect
	)
	draw_circle(
		Vector2(
			preview_rect.position.x + preview_rect.size.x / 2.0,
			preview_rect.position.y + preview_rect.size.y / 2.0
		),
		10,
		_theme_accent()
	)
	game_theme = old_theme

func _draw_store():
	draw_rect(
		Rect2(
			0,
			0,
			screen_size.x,
			screen_size.y
		),
		Color(0, 0, 0, 0.86)
	)
	_draw_shadow_rect(
		store_panel_rect,
		24.0,
		0.75,
		Vector2(8, 10)
	)
	draw_style_box(
		_make_box(
			Color("#14110E"),
			_theme_accent(),
			24,
			2
		),
		store_panel_rect
	)
	var inner = Rect2(
		store_panel_rect.position + Vector2(5, 5),
		store_panel_rect.size - Vector2(10, 10)
	)
	draw_style_box(
		_make_box(
			Color("#201A15"),
			Color("#56432F"),
			20,
			1
		),
		inner
	)
	_draw_centered_text(
		"PREMIUM STORE",
		Rect2(
			store_panel_rect.position.x,
			store_panel_rect.position.y + 10,
			store_panel_rect.size.x,
			34
		),
		26,
		_theme_accent()
	)
	_draw_centered_text(
		"◆  " + str(coins) + " COINS",
		Rect2(
			store_panel_rect.position.x,
			store_panel_rect.position.y + 46,
			store_panel_rect.size.x,
			24
		),
		16,
		Color("#F0D27C")
	)
	_draw_centered_text(
		"EVERYTHING IS FREE",
		Rect2(
			store_panel_rect.position.x,
			store_panel_rect.position.y + 72,
			store_panel_rect.size.x,
			20
		),
		12,
		Color("#73C78F")
	)
	draw_style_box(
		_make_box(
			Color("#38221F"),
			Color("#9C5A4D"),
			10,
			1
		),
		store_close_rect
	)
	_draw_icon_close(store_close_rect, Color("#F0D8D0"))
	var piece_active = store_tab == 0
	draw_style_box(
		_make_box(
			Color("#44341F") if piece_active else Color("#28231E"),
			_theme_accent() if piece_active else Color("#57493B"),
			10,
			2 if piece_active else 1
		),
		store_piece_tab_rect
	)
	_draw_centered_text(
		"PIECES",
		store_piece_tab_rect,
		16,
		Color("#F3DFB0") if piece_active else Color("#A99D8E")
	)
	var theme_active = store_tab == 1
	draw_style_box(
		_make_box(
			Color("#44341F") if theme_active else Color("#28231E"),
			_theme_accent() if theme_active else Color("#57493B"),
			10,
			2 if theme_active else 1
		),
		store_theme_tab_rect
	)
	_draw_centered_text(
		"THEMES",
		store_theme_tab_rect,
		16,
		Color("#F3DFB0") if theme_active else Color("#A99D8E")
	)
	if store_tab == 0:
		_draw_store_pieces()
	else:
		_draw_store_themes()

func _draw_store_pieces():
	_draw_centered_text(
		"PIECE COLLECTION",
		Rect2(
			store_panel_rect.position.x,
			store_panel_rect.position.y + 154,
			store_panel_rect.size.x,
			22
		),
		13,
		Color("#9C8A76")
	)
	for i in range(skin_rects.size()):
		var rect = skin_rects[i]
		_draw_store_item(
			rect,
			_skin_name(i),
			0,
			true,
			piece_skin == i
		)
		_draw_store_skin_preview(rect, i)
	_draw_centered_text(
		"PREMIUM EFFECTS",
		Rect2(
			store_panel_rect.position.x,
			store_panel_rect.position.y + 424,
			store_panel_rect.size.x,
			22
		),
		13,
		Color("#9C8A76")
	)
	for i in range(effect_rects.size()):
		var rect = effect_rects[i]
		_draw_store_item(
			rect,
			_effect_name(i),
			0,
			true,
			piece_effect == i
		)
		_draw_store_effect_preview(rect, i)

func _draw_store_themes():
	_draw_centered_text(
		"SELECT YOUR WORLD",
		Rect2(
			store_panel_rect.position.x,
			store_panel_rect.position.y + 154,
			store_panel_rect.size.x,
			22
		),
		13,
		Color("#9C8A76")
	)
	for i in range(theme_rects.size()):
		var rect = theme_rects[i]
		_draw_store_item(
			rect,
			_theme_name(i),
			0,
			true,
			game_theme == i
		)
		_draw_store_theme_preview(rect, i)

# =========================================================
# HELP PANEL
# =========================================================

func _draw_help():
	draw_rect(
		Rect2(0, 0, screen_size.x, screen_size.y),
		Color(0, 0, 0, 0.92)
	)

	_draw_shadow_rect(
		help_panel_rect,
		24.0,
		0.75,
		Vector2(8, 10)
	)
	draw_style_box(
		_make_box(
			Color("#14110E"),
			_theme_accent(),
			24,
			2
		),
		help_panel_rect
	)
	var inner = Rect2(
		help_panel_rect.position + Vector2(5, 5),
		help_panel_rect.size - Vector2(10, 10)
	)
	draw_style_box(
		_make_box(
			Color("#201A15"),
			Color("#56432F"),
			20,
			1
		),
		inner
	)

	var px = help_panel_rect.position.x
	var py = help_panel_rect.position.y
	var pw = help_panel_rect.size.x
	var ph = help_panel_rect.size.y

	_draw_centered_text(
		"HELP",
		Rect2(px, py + 15, pw, 42),
		28,
		_theme_accent()
	)

	draw_line(
		Vector2(px + 30, py + 62),
		Vector2(px + pw - 30, py + 62),
		Color(0.75, 0.55, 0.30, 0.25),
		2.0
	)

	var intro_active = (help_tab == 0)
	draw_style_box(
		_make_box(
			Color("#44341F") if intro_active else Color("#28231E"),
			_theme_accent() if intro_active else Color("#57493B"),
			10,
			2 if intro_active else 1
		),
		help_intro_tab_rect
	)
	_draw_centered_text(
		"INTRODUCTION",
		help_intro_tab_rect,
		15,
		Color("#F3DFB0") if intro_active else Color("#A99D8E")
	)

	var rules_active = (help_tab == 1)
	draw_style_box(
		_make_box(
			Color("#44341F") if rules_active else Color("#28231E"),
			_theme_accent() if rules_active else Color("#57493B"),
			10,
			2 if rules_active else 1
		),
		help_rules_tab_rect
	)
	_draw_centered_text(
		"RULES",
		help_rules_tab_rect,
		15,
		Color("#F3DFB0") if rules_active else Color("#A99D8E")
	)

	var content_x = px + 40.0
	var content_y = py + 150.0
	var content_w = pw - 80.0
	var content_bottom = help_copy_rect.position.y - 15.0

	if help_tab == 0:
		_draw_help_intro(content_x, content_y, content_w)
	else:
		_draw_help_rules(content_x, content_y, content_w, content_bottom)

	draw_style_box(
		_make_box(
			Color("#20372A"),
			Color("#5BAA79"),
			12,
			2
		),
		help_copy_rect
	)
	_draw_centered_text(
		"COPY ALL",
		help_copy_rect,
		18,
		Color("#D8F1E0")
	)

	draw_style_box(
		_make_box(
			Color("#38221F"),
			Color("#9C5A4D"),
			12,
			1
		),
		help_close_rect
	)
	_draw_centered_text(
		"CLOSE",
		help_close_rect,
		18,
		Color("#F0D8D0")
	)

	if copy_flash > 0.0:
		var toast_alpha = 1.0
		if copy_flash < 0.3:
			toast_alpha = copy_flash / 0.3
		var toast_w = 220.0
		var toast_h = 50.0
		var toast_rect = Rect2(
			screen_size.x / 2.0 - toast_w / 2.0,
			help_panel_rect.position.y - 15.0,
			toast_w,
			toast_h
		)
		_draw_shadow_rect(
			toast_rect,
			12.0,
			0.5 * toast_alpha,
			Vector2(3, 5)
		)
		draw_style_box(
			_make_box(
				Color(0.2, 0.35, 0.25, 0.95 * toast_alpha),
				Color(0.4, 0.85, 0.55, 0.9 * toast_alpha),
				12,
				2
			),
			toast_rect
		)
		_draw_centered_text(
			"COPIED!",
			toast_rect,
			18,
			Color(0.85, 1.0, 0.9, toast_alpha)
		)

func _draw_help_intro(cx: float, cy: float, cw: float):
	var font = ThemeDB.fallback_font
	var font_size = 15
	var line_h = 26.0
	var y = cy
	var paragraphs = HELP_INTRO_TEXT.split("\n")

	for para in paragraphs:
		if para.strip_edges() == "":
			y += line_h * 0.5
			continue
		var words = para.split(" ")
		var line = ""
		for word in words:
			var test = line + word + " "
			var w = font.get_string_size(
				test,
				HORIZONTAL_ALIGNMENT_LEFT,
				-1,
				font_size
			).x
			if w > cw and line != "":
				draw_string(
					font,
					Vector2(cx, y),
					line.strip_edges(),
					HORIZONTAL_ALIGNMENT_LEFT,
					-1,
					font_size,
					Color("#E8DCC8")
				)
				y += line_h
				line = word + " "
			else:
				line = test
		if line.strip_edges() != "":
			draw_string(
				font,
				Vector2(cx, y),
				line.strip_edges(),
				HORIZONTAL_ALIGNMENT_LEFT,
				-1,
				font_size,
				Color("#E8DCC8")
			)
			y += line_h

	y += line_h * 5

	var credit_text = "Developer: Kalat Group"
	draw_string(
		font,
		Vector2(cx, y),
		credit_text,
		HORIZONTAL_ALIGNMENT_LEFT,
		-1,
		font_size + 2,
		_theme_accent()
	)

func _draw_help_rules(cx: float, cy: float, cw: float, cb: float):
	var font = ThemeDB.fallback_font
	var font_size = 13
	var line_h = 20.0
	var y = cy
	var paragraphs = HELP_RULES_TEXT.split("\n")

	for para in paragraphs:
		if y > cb - line_h:
			draw_string(
				font,
				Vector2(cx, y),
				"...",
				HORIZONTAL_ALIGNMENT_LEFT,
				-1,
				font_size,
				Color("#9C8A76")
			)
			break

		if para.strip_edges() == "":
			y += line_h * 0.4
			continue

		var is_heading = not para.begins_with("-")
		var col = Color("#F0D27C") if is_heading else Color("#E8DCC8")
		var sz = font_size + 3 if is_heading else font_size
		var y_advance = line_h + 4 if is_heading else line_h

		var words = para.split(" ")
		var line = ""
		for word in words:
			var test = line + word + " "
			var w = font.get_string_size(
				test,
				HORIZONTAL_ALIGNMENT_LEFT,
				-1,
				sz
			).x
			if w > cw and line != "":
				draw_string(
					font,
					Vector2(cx, y),
					line.strip_edges(),
					HORIZONTAL_ALIGNMENT_LEFT,
					-1,
					sz,
					col
				)
				y += line_h
				line = word + " "
			else:
				line = test
		if line.strip_edges() != "":
			draw_string(
				font,
				Vector2(cx, y),
				line.strip_edges(),
				HORIZONTAL_ALIGNMENT_LEFT,
				-1,
				sz,
				col
			)
			y += y_advance

	y += line_h * 5

	var credit_text = "Developer: Kalat Group"
	draw_string(
		font,
		Vector2(cx, y),
		credit_text,
		HORIZONTAL_ALIGNMENT_LEFT,
		-1,
		font_size + 2,
		_theme_accent()
	)

# =========================================================
# MAIN DRAW
# =========================================================

func _draw():
	draw_rect(
		Rect2(
			Vector2.ZERO,
			screen_size
		),
		_theme_background()
	)
	draw_rect(
		Rect2(
			0,
			0,
			screen_size.x,
			screen_size.y * 0.25
		),
		_theme_top()
	)
	draw_rect(
		Rect2(
			0,
			screen_size.y * 0.75,
			screen_size.x,
			screen_size.y * 0.25
		),
		_theme_bottom()
	)
	var center_bg = Vector2(
		screen_size.x / 2.0,
		screen_size.y / 2.0
	)
	draw_circle(
		center_bg,
		screen_size.y * 0.43,
		Color(0.35, 0.22, 0.10, 0.045)
	)
	draw_circle(
		center_bg,
		screen_size.y * 0.31,
		Color(0.55, 0.35, 0.15, 0.025)
	)
	draw_line(
		Vector2(20, 75),
		Vector2(screen_size.x - 20, 75),
		Color(0.75, 0.55, 0.30, 0.10),
		1.0
	)
	draw_line(
		Vector2(20, screen_size.y - 55),
		Vector2(screen_size.x - 20, screen_size.y - 55),
		Color(0.75, 0.55, 0.30, 0.08),
		1.0
	)

	# MENU button (top-right)
	_draw_shadow_rect(
		menu_rect,
		12.0,
		0.40,
		Vector2(3, 5)
	)
	draw_style_box(
		_make_box(
			Color("#1A1714"),
			_theme_secondary(),
			12,
			1
		),
		menu_rect
	)
	_draw_icon_menu(menu_rect, Color("#E7D4B7"))

	# HELP button (top-left)
	if not menu_open and not side_open and not store_open and not help_open:
		_draw_shadow_rect(
			help_rect,
			12.0,
			0.40,
			Vector2(3, 5)
		)
		draw_style_box(
			_make_box(
				Color("#1A1714"),
				_theme_secondary(),
				12,
				1
			),
			help_rect
		)
		_draw_icon_rules(help_rect, Color("#E7D4B7"))

	# STORE button (bottom-left)
	if not menu_open and not side_open and not store_open and not help_open:
		_draw_shadow_rect(
			store_rect,
			12.0,
			0.40,
			Vector2(3, 5)
		)
		draw_style_box(
			_make_box(
				Color("#211A12"),
				_theme_accent(),
				12,
				1
			),
			store_rect
		)
		_draw_icon_store(store_rect, _theme_accent())

	_draw_counter(
		black_counter_rect,
		1,
		"BLACK",
		black_count
	)

	var black_in_tray = TOTAL_PIECES - black_count
	black_in_tray = clamp(
		black_in_tray,
		0,
		TOTAL_PIECES
	)
	_draw_tray(
		black_tray_rect,
		black_in_tray,
		true
	)

	var black_active = (
		current == 1
		and phase != "gameover"
	)
	if black_active and not (
		vs_computer
		and computer_color == 1
	):
		var ratio = turn_time / TURN_LIMIT
		ratio = max(ratio, 0)
		var timer_color = _theme_accent()
		if turn_time <= 10.0:
			timer_color = Color("#D9544D")
		_draw_timer_border(
			black_tray_rect,
			ratio,
			timer_color
		)
	elif black_active and vs_computer \
	and computer_color == 1:
		_draw_timer_border(
			black_tray_rect,
			1.0,
			Color("#65C98A")
		)

	_draw_board_background()

	for r in range(5):
		for c in range(5):
			var p = gp(r, c)
			if c < 4:
				draw_line(
					p,
					gp(r, c + 1),
					Color("#D5AD77"),
					6.0,
					true
				)
				draw_line(
					p + Vector2(0, 2),
					gp(r, c + 1) + Vector2(0, 2),
					Color(0, 0, 0, 0.22),
					2.0,
					true
				)
			if r < 4:
				draw_line(
					p,
					gp(r + 1, c),
					Color("#D5AD77"),
					6.0,
					true
				)
				draw_line(
					p + Vector2(2, 0),
					gp(r + 1, c) + Vector2(2, 0),
					Color(0, 0, 0, 0.22),
					2.0,
					true
				)
			if (r + c) % 2 == 0:
				if r < 4 and c < 4:
					draw_line(
						p,
						gp(r + 1, c + 1),
						Color("#C99D68"),
						5.0,
						true
					)
				if r < 4 and c > 0:
					draw_line(
						p,
						gp(r + 1, c - 1),
						Color("#C99D68"),
						5.0,
						true
					)

	for r in range(5):
		for c in range(5):
			var p = gp(r, c)
			draw_circle(
				p + Vector2(2, 3),
				PR + 1,
				Color(0, 0, 0, 0.25)
			)
			draw_circle(
				p,
				PR,
				Color("#B68B5C")
			)
			draw_circle(
				p - Vector2(0, 1),
				PR - 4,
				Color("#7A593A")
			)
			draw_circle(
				p,
				PR,
				_theme_accent(),
				false,
				2
			)

	for m in valid_moves:
		var p = gp(
			int(m.x),
			int(m.y)
		)
		_draw_glow_circle(
			p,
			PIECE_R * 0.52,
			Color(0.25, 0.85, 0.55, 0.42)
		)
		draw_circle(
			p,
			PIECE_R * 0.43,
			Color("#5ED79A"),
			false,
			4
		)
		draw_circle(
			p,
			5,
			Color("#A9F3C9")
		)

	for m in capture_options:
		var p = gp(
			int(m.x),
			int(m.y)
		)
		_draw_glow_circle(
			p,
			PIECE_R + 7,
			Color(0.95, 0.25, 0.18, 0.28)
		)
		draw_circle(
			p,
			PIECE_R + 8,
			Color("#F05A50"),
			false,
			4
		)

	for r in range(5):
		for c in range(5):
			var piece = state[r][c]
			if piece == 1 or piece == 2:
				_draw_piece_at(
					gp(r, c),
					piece
				)

	if selected.x >= 0:
		var selected_pos = gp(
			int(selected.x),
			int(selected.y)
		)
		_draw_glow_circle(
			selected_pos,
			PIECE_R + 7,
			Color(1.0, 0.72, 0.20, 0.28)
		)
		draw_circle(
			selected_pos,
			PIECE_R + 9,
			_theme_accent(),
			false,
			4
		)
		draw_circle(
			selected_pos,
			PIECE_R + 13,
			Color(0.9, 0.65, 0.2, 0.25),
			false,
			2
		)

	if anim_active:
		var t = anim_progress
		t = 1.0 - pow(1.0 - t, 3.0)
		var apos = anim_from_pos.lerp(
			anim_to_pos,
			t
		)
		_draw_glow_circle(
			apos,
			PIECE_R + 6,
			Color(0.85, 0.65, 0.30, 0.15)
		)
		draw_circle(
			apos + Vector2(3, 5),
			PIECE_R + 4,
			Color(0, 0, 0, 0.28)
		)
		_draw_piece_at(
			apos,
			anim_piece_color
		)

	var white_in_tray = TOTAL_PIECES - white_count
	white_in_tray = clamp(
		white_in_tray,
		0,
		TOTAL_PIECES
	)
	_draw_tray(
		white_tray_rect,
		white_in_tray,
		false
	)

	var white_active = (
		current == 2
		and phase != "gameover"
	)
	if white_active and not (
		vs_computer
		and computer_color == 2
	):
		var ratio2 = turn_time / TURN_LIMIT
		ratio2 = max(ratio2, 0)
		var timer_color2 = _theme_accent()
		if turn_time <= 10.0:
			timer_color2 = Color("#D9544D")
		_draw_timer_border(
			white_tray_rect,
			ratio2,
			timer_color2
		)
	elif white_active and vs_computer \
	and computer_color == 2:
		_draw_timer_border(
			white_tray_rect,
			1.0,
			Color("#65C98A")
		)

	_draw_counter(
		white_counter_rect,
		2,
		"WHITE",
		white_count
	)

	if (
		vs_computer
		and current == computer_color
		and phase != "gameover"
		and not menu_open
		and not side_open
		and not store_open
		and not help_open
		and not anim_active
	):
		draw_string(
			ThemeDB.fallback_font,
			Vector2(
				30,
				black_counter_rect.position.y + 32
			),
			"AI IS THINKING...",
			HORIZONTAL_ALIGNMENT_LEFT,
			-1,
			15,
			Color("#65C98A")
		)

	if phase == "gameover" and not side_open:
		var pw2 = min(
			screen_size.x * 0.75,
			380.0
		)
		var ph2 = 165.0
		var ppos = Vector2(
			screen_size.x / 2.0 - pw2 / 2.0,
			screen_size.y / 2.0 - ph2 / 2.0
		)
		var prect = Rect2(
			ppos,
			Vector2(pw2, ph2)
		)
		_draw_shadow_rect(
			prect,
			20.0,
			0.65,
			Vector2(7, 9)
		)
		draw_style_box(
			_make_box(
				Color("#1A1410"),
				_theme_accent(),
				20,
				2
			),
			prect
		)
		_draw_centered_text(
			debug_text,
			Rect2(
				ppos.x,
				ppos.y + 20,
				pw2,
				45
			),
			30,
			_theme_accent()
		)
		_draw_centered_text(
			"+50 COINS",
			Rect2(
				ppos.x,
				ppos.y + 65,
				pw2,
				25
			),
			15,
			Color("#E6C56D")
		)
		_draw_centered_text(
			"OPEN MENU TO RESTART",
			Rect2(
				ppos.x,
				ppos.y + 105,
				pw2,
				30
			),
			15,
			Color("#B5A596")
		)

	if menu_open:
		draw_rect(
			Rect2(
				0,
				0,
				screen_size.x,
				screen_size.y
			),
			Color(0, 0, 0, 0.78)
		)
		draw_circle(
			Vector2(
				screen_size.x / 2.0,
				screen_size.y / 2.0
			),
			panel_rect.size.y * 0.75,
			Color(0.6, 0.4, 0.18, 0.035)
		)
		_draw_shadow_rect(
			panel_rect,
			22.0,
			0.70,
			Vector2(8, 10)
		)
		draw_style_box(
			_make_box(
				Color("#17130F"),
				_theme_accent(),
				22,
				2
			),
			panel_rect
		)
		var panel_inner = Rect2(
			panel_rect.position + Vector2(5, 5),
			panel_rect.size - Vector2(10, 10)
		)
		draw_style_box(
			_make_box(
				Color("#211A14"),
				Color("#5A432D"),
				18,
				1
			),
			panel_inner
		)
		var px2 = panel_rect.position.x
		var py2 = panel_rect.position.y
		var pw3 = panel_rect.size.x
		_draw_centered_text(
			"MENU",
			Rect2(
				px2,
				py2 + 15,
				pw3,
				45
			),
			30,
			_theme_accent()
		)

		_draw_shadow_rect(
			resume_rect,
			10.0,
			0.25,
			Vector2(2, 3)
		)
		draw_style_box(
			_make_box(
				Color("#30271E"),
				Color("#876B49"),
				10,
				1
			),
			resume_rect
		)
		_draw_icon_play(resume_rect, Color("#F0E4D1"))

		_draw_shadow_rect(
			newgame_rect,
			10.0,
			0.25,
			Vector2(2, 3)
		)
		draw_style_box(
			_make_box(
				Color("#43251F"),
				Color("#9D5A48"),
				10,
				1
			),
			newgame_rect
		)
		_draw_icon_refresh(newgame_rect, Color("#F4DDD5"))

		if sound_enabled:
			draw_style_box(
				_make_box(
					Color("#20372A"),
					Color("#5BAA79"),
					10,
					2
				),
				sound_rect
			)
			_draw_icon_sound_on(sound_rect, Color("#D8F1E0"))
		else:
			draw_style_box(
				_make_box(
					Color("#382321"),
					Color("#80524C"),
					10,
					1
				),
				sound_rect
			)
			_draw_icon_sound_off(sound_rect, Color("#A99C96"))

		var mode_label_y = mode_2p_rect.position.y - 30
		_draw_centered_text(
			"GAME MODE",
			Rect2(
				px2,
				mode_label_y,
				pw3,
				25
			),
			16,
			Color("#9D8A76")
		)
		var p2_active = not vs_computer
		draw_style_box(
			_make_box(
				Color("#253A2C") if p2_active \
					else Color("#29241F"),
				Color("#63B47F") if p2_active \
					else Color("#5A4C3D"),
				10,
				2 if p2_active else 1
			),
			mode_2p_rect
		)
		_draw_icon_2players(
			mode_2p_rect,
			Color("#F0E4D1") if p2_active \
				else Color("#9E9184")
		)
		var ai_active = vs_computer
		draw_style_box(
			_make_box(
				Color("#253447") if ai_active \
					else Color("#29241F"),
				Color("#6B9BC7") if ai_active \
					else Color("#5A4C3D"),
				10,
				2 if ai_active else 1
			),
			mode_ai_rect
		)
		_draw_icon_ai(
			mode_ai_rect,
			Color("#E0EBF5") if ai_active \
				else Color("#9E9184")
		)
		if vs_computer:
			var diff_label_y = \
				diff_easy_rect.position.y - 30
			_draw_centered_text(
				"DIFFICULTY",
				Rect2(
					px2,
					diff_label_y,
					pw3,
					25
				),
				16,
				Color("#9D8A76")
			)
			var e_active = difficulty == 0
			draw_style_box(
				_make_box(
					Color("#243A2A") if e_active \
						else Color("#29241F"),
					Color("#63B47F") if e_active \
						else Color("#5A4C3D"),
					10,
					2 if e_active else 1
				),
				diff_easy_rect
			)
			_draw_icon_difficulty(
				diff_easy_rect,
				1,
				Color("#E4F0E7") if e_active \
					else Color("#9E9184")
			)
			var m_active = difficulty == 1
			draw_style_box(
				_make_box(
					Color("#46391F") if m_active \
						else Color("#29241F"),
					Color("#D2A952") if m_active \
						else Color("#5A4C3D"),
					10,
					2 if m_active else 1
				),
				diff_med_rect
			)
			_draw_icon_difficulty(
				diff_med_rect,
				2,
				Color("#F4E5BF") if m_active \
					else Color("#9E9184")
			)
			var h_active = difficulty == 2
			draw_style_box(
				_make_box(
					Color("#432522") if h_active \
						else Color("#29241F"),
					Color("#B75B51") if h_active \
						else Color("#5A4C3D"),
					10,
					2 if h_active else 1
				),
				diff_hard_rect
			)
			_draw_icon_difficulty(
				diff_hard_rect,
				3,
				Color("#F0D6D2") if h_active \
					else Color("#9E9184")
			)

	if side_open:
		_draw_side_chooser()

	if store_open:
		_draw_store()

	if help_open:
		_draw_help()
